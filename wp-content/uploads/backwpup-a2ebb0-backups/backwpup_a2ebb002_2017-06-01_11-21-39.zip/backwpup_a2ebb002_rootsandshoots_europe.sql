-- ---------------------------------------------------------
-- Backup with BackWPup ver.: 3.4.0
-- http://backwpup.com/
-- Blog Name: Jane Goodall&#039;s Roots&amp;Shoots Europe
-- Blog URL: http://localhost:8080/rootsandshootseurope/
-- Blog ABSPATH: C:/wamp64/www/rootsandshootseurope/
-- Blog Charset: UTF-8
-- Table Prefix: wor1677_
-- Database Name: rootsandshoots_europe
-- Backup on: 2017-06-01 11:21.39
-- ---------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='SYSTEM' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


--
-- Table structure for `rs_countries`
--

DROP TABLE IF EXISTS `rs_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_countries` (
  `CountryId` int(11) NOT NULL AUTO_INCREMENT,
  `Country` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CountryId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_countries`
--

LOCK TABLES `rs_countries` WRITE;
/*!40000 ALTER TABLE `rs_countries` DISABLE KEYS */;
INSERT INTO `rs_countries` (`CountryId`, `Country`) VALUES 
(1, 'Belgium'),
(2, 'France'),
(3, 'Germany'),
(4, 'Italy'),
(5, 'Netherlands'),
(6, 'Spain');
/*!40000 ALTER TABLE `rs_countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_languages`
--

DROP TABLE IF EXISTS `rs_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_languages` (
  `LanguageId` int(11) NOT NULL AUTO_INCREMENT,
  `Language` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`LanguageId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_languages`
--

LOCK TABLES `rs_languages` WRITE;
/*!40000 ALTER TABLE `rs_languages` DISABLE KEYS */;
INSERT INTO `rs_languages` (`LanguageId`, `Language`) VALUES 
(1, 'English'),
(2, 'Dutch'),
(3, 'French'),
(4, 'German'),
(5, 'Spanish'),
(6, 'Italian'),
(7, 'Other');
/*!40000 ALTER TABLE `rs_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_members`
--

DROP TABLE IF EXISTS `rs_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_members` (
  `MemberId` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `BirthDate` date NOT NULL,
  `Email` varchar(255) NOT NULL,
  `LanguageId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `CountryId` int(11) NOT NULL,
  `InsertedBy` varchar(255) DEFAULT NULL,
  `InsertedOn` timestamp NULL DEFAULT NULL,
  `ModifiedBy` varchar(255) DEFAULT NULL,
  `ModifiedOn` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`MemberId`),
  UNIQUE KEY `uc_UserName` (`UserName`),
  UNIQUE KEY `uc_Password` (`Password`),
  KEY `fkc_members_languages` (`LanguageId`),
  KEY `fkc_members_roles` (`RoleId`),
  KEY `fkc_members_countries` (`CountryId`),
  CONSTRAINT `fkc_members_countries` FOREIGN KEY (`CountryId`) REFERENCES `rs_countries` (`CountryId`) ON UPDATE CASCADE,
  CONSTRAINT `fkc_members_languages` FOREIGN KEY (`LanguageId`) REFERENCES `rs_languages` (`LanguageId`) ON UPDATE CASCADE,
  CONSTRAINT `fkc_members_roles` FOREIGN KEY (`RoleId`) REFERENCES `rs_roles` (`RoleId`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_members`
--

LOCK TABLES `rs_members` WRITE;
/*!40000 ALTER TABLE `rs_members` DISABLE KEYS */;
INSERT INTO `rs_members` (`MemberId`, `UserName`, `Password`, `FirstName`, `LastName`, `BirthDate`, `Email`, `LanguageId`, `RoleId`, `CountryId`, `InsertedBy`, `InsertedOn`, `ModifiedBy`, `ModifiedOn`) VALUES 
(1, 'Tania', 'Tania123', 'Tania', 'Parys', 0x313938302d30322d3035, 'taniaparys@yahoo.com', 1, 3, 1, NULL, NULL, NULL, NULL),
(2, 'Alicia', 'Alicia123', 'Alicia', 'Van der Stighelen', 0x313939372d31302d3135, 'aliciavds@live.be', 1, 3, 1, NULL, NULL, NULL, NULL),
(3, 'Chris', 'Chris123', 'Christian', 'Michel', 0x313938362d30342d3037, 'chris@janegoodall.be', 2, 3, 1, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `rs_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_projectmembers`
--

DROP TABLE IF EXISTS `rs_projectmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_projectmembers` (
  `ProjectMemberId` int(11) NOT NULL AUTO_INCREMENT,
  `ProjectId` int(11) NOT NULL,
  `MemberId` int(11) DEFAULT NULL,
  `Pending` tinyint(1) NOT NULL,
  `InsertedBy` varchar(255) DEFAULT NULL,
  `InsertedOn` timestamp NULL DEFAULT NULL,
  `ModifiedBy` varchar(255) DEFAULT NULL,
  `ModifiedOn` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ProjectMemberId`),
  KEY `fkc_projects_projectmembers` (`ProjectId`),
  KEY `fkc_members_projectmembers` (`MemberId`),
  CONSTRAINT `fkc_members_projectmembers` FOREIGN KEY (`MemberId`) REFERENCES `rs_members` (`MemberId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fkc_projects_projectmembers` FOREIGN KEY (`ProjectId`) REFERENCES `rs_projects` (`ProjectId`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_projectmembers`
--

LOCK TABLES `rs_projectmembers` WRITE;
/*!40000 ALTER TABLE `rs_projectmembers` DISABLE KEYS */;
INSERT INTO `rs_projectmembers` (`ProjectMemberId`, `ProjectId`, `MemberId`, `Pending`, `InsertedBy`, `InsertedOn`, `ModifiedBy`, `ModifiedOn`) VALUES 
(1, 1, 2, 0, NULL, NULL, NULL, NULL),
(2, 2, 2, 1, NULL, NULL, NULL, NULL),
(3, 2, 3, 0, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `rs_projectmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_projectprojecttypes`
--

DROP TABLE IF EXISTS `rs_projectprojecttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_projectprojecttypes` (
  `ProjectProjectTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `ProjectId` int(11) NOT NULL,
  `ProjectTypeId` int(11) NOT NULL,
  `InsertedBy` varchar(255) DEFAULT NULL,
  `InsertedOn` timestamp NULL DEFAULT NULL,
  `ModifiedBy` varchar(255) DEFAULT NULL,
  `ModifiedOn` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ProjectProjectTypeId`),
  KEY `fkc_projecttypes_projectprojecttypes` (`ProjectTypeId`),
  KEY `fkc_projects_projecttypes` (`ProjectId`),
  CONSTRAINT `fkc_projects_projecttypes` FOREIGN KEY (`ProjectId`) REFERENCES `rs_projects` (`ProjectId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fkc_projecttypes_projectprojecttypes` FOREIGN KEY (`ProjectTypeId`) REFERENCES `rs_projecttypes` (`ProjectTypeId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_projectprojecttypes`
--

LOCK TABLES `rs_projectprojecttypes` WRITE;
/*!40000 ALTER TABLE `rs_projectprojecttypes` DISABLE KEYS */;
INSERT INTO `rs_projectprojecttypes` (`ProjectProjectTypeId`, `ProjectId`, `ProjectTypeId`, `InsertedBy`, `InsertedOn`, `ModifiedBy`, `ModifiedOn`) VALUES 
(1, 1, 2, NULL, NULL, NULL, NULL),
(2, 1, 3, NULL, NULL, NULL, NULL),
(3, 2, 6, NULL, NULL, NULL, NULL),
(4, 3, 10, 'admin', 0x323031362d30392d30312031353a35323a3535, NULL, NULL);
/*!40000 ALTER TABLE `rs_projectprojecttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_projects`
--

DROP TABLE IF EXISTS `rs_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_projects` (
  `ProjectId` int(11) NOT NULL AUTO_INCREMENT,
  `ProjectTitle` varchar(255) NOT NULL,
  `GroupName` varchar(255) DEFAULT NULL,
  `PplEstimated` int(11) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Objective` text NOT NULL,
  `Means` text,
  `StartDate` date DEFAULT NULL,
  `TimeFrameId` int(11) NOT NULL,
  `LanguageId` int(11) NOT NULL,
  `CountryId` int(11) NOT NULL,
  `ProjectStatusId` int(11) NOT NULL,
  `HoursSpent` int(11) DEFAULT NULL,
  `PplParticipated` int(11) DEFAULT NULL,
  `PplServed` int(11) DEFAULT NULL,
  `Report` text,
  `EndDate` date DEFAULT NULL,
  `InsertedBy` varchar(255) DEFAULT NULL,
  `InsertedOn` timestamp NULL DEFAULT NULL,
  `ModifiedBy` varchar(255) DEFAULT NULL,
  `ModifiedOn` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ProjectId`),
  KEY `fkc_projects_timeframes` (`TimeFrameId`),
  KEY `fkc_projects_languages` (`LanguageId`),
  KEY `fkc_projects_countries` (`CountryId`),
  KEY `fkc_projects_projectstatuses` (`ProjectStatusId`),
  CONSTRAINT `fkc_projects_countries` FOREIGN KEY (`CountryId`) REFERENCES `rs_countries` (`CountryId`) ON UPDATE CASCADE,
  CONSTRAINT `fkc_projects_languages` FOREIGN KEY (`LanguageId`) REFERENCES `rs_languages` (`LanguageId`) ON UPDATE CASCADE,
  CONSTRAINT `fkc_projects_projectstatuses` FOREIGN KEY (`ProjectStatusId`) REFERENCES `rs_projectstatuses` (`ProjectStatusId`) ON UPDATE CASCADE,
  CONSTRAINT `fkc_projects_timeframes` FOREIGN KEY (`TimeFrameId`) REFERENCES `rs_timeframes` (`TimeFrameId`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_projects`
--

LOCK TABLES `rs_projects` WRITE;
/*!40000 ALTER TABLE `rs_projects` DISABLE KEYS */;
INSERT INTO `rs_projects` (`ProjectId`, `ProjectTitle`, `GroupName`, `PplEstimated`, `Location`, `Objective`, `Means`, `StartDate`, `TimeFrameId`, `LanguageId`, `CountryId`, `ProjectStatusId`, `HoursSpent`, `PplParticipated`, `PplServed`, `Report`, `EndDate`, `InsertedBy`, `InsertedOn`, `ModifiedBy`, `ModifiedOn`) VALUES 
(1, 'Happy seeds for happy needs', 'Freinetschool', NULL, 'Mechelen', 0x506c616e74696e67207365656420626f6d627320696e20616e642061726f756e6420746865207363686f6f6c20746f20696e6372656173652077696c6420666c6f7765727320666f722074686520706f6c6c696e61746f7273, NULL, 0x323031362d31302d3130, 5, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, 'admin', 0x323031362d30382d31322031353a32363a3139, NULL, NULL),
(2, 'Friday the 13th challenge', 'Roots & Shoots STJ', NULL, 'Aalst', 0x486176652070656f706c6520646f20736d616c6c20656e7669726f6e6d656e74616c206368616e676573206f6e20657665727920667269646179207468652031337468, NULL, 0x323031362d30372d3130, 6, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, 'admin', 0x323031362d30382d31322031353a32363a3139, NULL, NULL),
(3, 'Propreté et tri des déchets aux Collège', 'Roots & Shoots CSCG', NULL, 'Ganshoren', 0x436c65616e2d757020616e642072656379636c696e672070726f6a65637420666f72207468652077686f6c65207363686f6f6c, NULL, 0x323031352d30312d3230, 5, 2, 1, 1, NULL, NULL, NULL, NULL, NULL, 'admin', 0x323031362d30382d31322031353a32363a3139, NULL, NULL),
(4, 'éliminer déchêts', 'Nettoyage sans frontières', 20, 'Louvain-la-neuve', 0x31686120, 0x4d616e75656c656d656e74, 0x323031362d31302d3130, 1, 1, 1, 1, NULL, NULL, NULL, NULL, 0x323031362d31302d3130, 'admin', 0x323031362d30382d33312032303a35303a3130, NULL, NULL);
/*!40000 ALTER TABLE `rs_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_projectstatuses`
--

DROP TABLE IF EXISTS `rs_projectstatuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_projectstatuses` (
  `ProjectStatusId` int(11) NOT NULL AUTO_INCREMENT,
  `ProjectStatus` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ProjectStatusId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_projectstatuses`
--

LOCK TABLES `rs_projectstatuses` WRITE;
/*!40000 ALTER TABLE `rs_projectstatuses` DISABLE KEYS */;
INSERT INTO `rs_projectstatuses` (`ProjectStatusId`, `ProjectStatus`) VALUES 
(1, 'Waiting for approval'),
(2, 'Approved'),
(3, 'Denied'),
(4, 'In progress'),
(5, 'Finished');
/*!40000 ALTER TABLE `rs_projectstatuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_projecttargetgroups`
--

DROP TABLE IF EXISTS `rs_projecttargetgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_projecttargetgroups` (
  `ProjectTargetGroupId` int(11) NOT NULL AUTO_INCREMENT,
  `ProjectId` int(11) NOT NULL,
  `TargetGroupId` int(11) NOT NULL,
  `InsertedBy` varchar(255) DEFAULT NULL,
  `InsertedOn` timestamp NULL DEFAULT NULL,
  `ModifiedBy` varchar(255) DEFAULT NULL,
  `ModifiedOn` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ProjectTargetGroupId`),
  KEY `fkc_projects_projecttargetgroups` (`ProjectId`),
  KEY `fkc_targetgroups_projecttargetgroups` (`TargetGroupId`),
  CONSTRAINT `fkc_projects_projecttargetgroups` FOREIGN KEY (`ProjectId`) REFERENCES `rs_projects` (`ProjectId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fkc_targetgroups_projecttargetgroups` FOREIGN KEY (`TargetGroupId`) REFERENCES `rs_targetgroups` (`TargetGroupId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_projecttargetgroups`
--

LOCK TABLES `rs_projecttargetgroups` WRITE;
/*!40000 ALTER TABLE `rs_projecttargetgroups` DISABLE KEYS */;
INSERT INTO `rs_projecttargetgroups` (`ProjectTargetGroupId`, `ProjectId`, `TargetGroupId`, `InsertedBy`, `InsertedOn`, `ModifiedBy`, `ModifiedOn`) VALUES 
(1, 1, 1, NULL, NULL, NULL, NULL),
(2, 1, 4, NULL, NULL, NULL, NULL),
(3, 1, 2, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `rs_projecttargetgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_projecttypes`
--

DROP TABLE IF EXISTS `rs_projecttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_projecttypes` (
  `ProjectTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `ProjectType` varchar(255) NOT NULL,
  `ProjectTypeInfo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ProjectTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_projecttypes`
--

LOCK TABLES `rs_projecttypes` WRITE;
/*!40000 ALTER TABLE `rs_projecttypes` DISABLE KEYS */;
INSERT INTO `rs_projecttypes` (`ProjectTypeId`, `ProjectType`, `ProjectTypeInfo`) VALUES 
(1, 'Air', 'Inspired by US'),
(2, 'Beautification', 'Inspired by US'),
(3, 'Climate actions', 'Comes from JGIE'),
(4, 'Energy', 'Inspired by USA'),
(5, 'Food and Health', 'Inspired by US'),
(6, 'Human Community and Human Condition', 'Inspired by US'),
(7, 'Landscapes, Trees and Plants', 'Inspired by US'),
(8, 'Peace', 'Inspired by US'),
(9, 'Pets and Domestic Animals', 'Inspired by US'),
(10, 'Reduce, Reuse, Recycle', 'Comes from JGIE'),
(11, 'Sustainable development goals', 'Comes from JGIE'),
(12, 'Water', 'Inspired by US'),
(13, 'Wildlife', 'Inspired by US');
/*!40000 ALTER TABLE `rs_projecttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_roles`
--

DROP TABLE IF EXISTS `rs_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_roles` (
  `RoleId` int(11) NOT NULL AUTO_INCREMENT,
  `Role` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_roles`
--

LOCK TABLES `rs_roles` WRITE;
/*!40000 ALTER TABLE `rs_roles` DISABLE KEYS */;
INSERT INTO `rs_roles` (`RoleId`, `Role`) VALUES 
(1, 'None'),
(2, 'Project member'),
(3, 'Project head'),
(4, 'Coordinator');
/*!40000 ALTER TABLE `rs_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_stuffs`
--

DROP TABLE IF EXISTS `rs_stuffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_stuffs` (
  `StuffId` int(11) NOT NULL AUTO_INCREMENT,
  `StuffTitle` varchar(255) NOT NULL,
  `ProjectId` int(11) NOT NULL,
  `MemberId` int(11) DEFAULT NULL,
  `StuffTypeId` int(11) NOT NULL,
  `InsertedBy` varchar(255) DEFAULT NULL,
  `InsertedOn` timestamp NULL DEFAULT NULL,
  `ModifiedBy` varchar(255) DEFAULT NULL,
  `ModifiedOn` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`StuffId`),
  KEY `fkc_projects_stuffs` (`ProjectId`),
  KEY `fkc_members_stuffs` (`MemberId`),
  KEY `fkc_stufftypes_stuffs` (`StuffTypeId`),
  CONSTRAINT `fkc_members_stuffs` FOREIGN KEY (`MemberId`) REFERENCES `rs_members` (`MemberId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fkc_projects_stuffs` FOREIGN KEY (`ProjectId`) REFERENCES `rs_projects` (`ProjectId`) ON UPDATE CASCADE,
  CONSTRAINT `fkc_stufftypes_stuffs` FOREIGN KEY (`StuffTypeId`) REFERENCES `rs_stufftypes` (`StuffTypeId`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_stuffs`
--

LOCK TABLES `rs_stuffs` WRITE;
/*!40000 ALTER TABLE `rs_stuffs` DISABLE KEYS */;
INSERT INTO `rs_stuffs` (`StuffId`, `StuffTitle`, `ProjectId`, `MemberId`, `StuffTypeId`, `InsertedBy`, `InsertedOn`, `ModifiedBy`, `ModifiedOn`) VALUES 
(1, 'Animals.jpg', 1, 1, 1, NULL, NULL, NULL, NULL),
(2, 'People.doc', 1, 2, 2, NULL, NULL, NULL, NULL),
(3, 'Environment', 1, 1, 3, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `rs_stuffs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_stufftypes`
--

DROP TABLE IF EXISTS `rs_stufftypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_stufftypes` (
  `StuffTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `StuffType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`StuffTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_stufftypes`
--

LOCK TABLES `rs_stufftypes` WRITE;
/*!40000 ALTER TABLE `rs_stufftypes` DISABLE KEYS */;
INSERT INTO `rs_stufftypes` (`StuffTypeId`, `StuffType`) VALUES 
(1, 'Document'),
(2, 'Image'),
(3, 'Video');
/*!40000 ALTER TABLE `rs_stufftypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_targetgroups`
--

DROP TABLE IF EXISTS `rs_targetgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_targetgroups` (
  `TargetGroupId` int(11) NOT NULL AUTO_INCREMENT,
  `TargetGroup` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`TargetGroupId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_targetgroups`
--

LOCK TABLES `rs_targetgroups` WRITE;
/*!40000 ALTER TABLE `rs_targetgroups` DISABLE KEYS */;
INSERT INTO `rs_targetgroups` (`TargetGroupId`, `TargetGroup`) VALUES 
(1, '0 - 6 years'),
(2, '6 - 12 years'),
(3, '12 - 18 years'),
(4, '18 - 25 years');
/*!40000 ALTER TABLE `rs_targetgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `rs_timeframes`
--

DROP TABLE IF EXISTS `rs_timeframes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `rs_timeframes` (
  `TimeFrameId` int(11) NOT NULL AUTO_INCREMENT,
  `TimeFrame` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`TimeFrameId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `rs_timeframes`
--

LOCK TABLES `rs_timeframes` WRITE;
/*!40000 ALTER TABLE `rs_timeframes` DISABLE KEYS */;
INSERT INTO `rs_timeframes` (`TimeFrameId`, `TimeFrame`) VALUES 
(1, '1 week'),
(2, '1 month'),
(3, '3 months'),
(4, '6 months'),
(5, '1 year'),
(6, '> 1 year');
/*!40000 ALTER TABLE `rs_timeframes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_commentmeta`
--

DROP TABLE IF EXISTS `wor1677_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_commentmeta`
--

LOCK TABLES `wor1677_commentmeta` WRITE;
/*!40000 ALTER TABLE `wor1677_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wor1677_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_comments`
--

DROP TABLE IF EXISTS `wor1677_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_comments`
--

LOCK TABLES `wor1677_comments` WRITE;
/*!40000 ALTER TABLE `wor1677_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `wor1677_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_links`
--

DROP TABLE IF EXISTS `wor1677_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_links`
--

LOCK TABLES `wor1677_links` WRITE;
/*!40000 ALTER TABLE `wor1677_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wor1677_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_options`
--

DROP TABLE IF EXISTS `wor1677_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=43716 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_options`
--

LOCK TABLES `wor1677_options` WRITE;
/*!40000 ALTER TABLE `wor1677_options` DISABLE KEYS */;
INSERT INTO `wor1677_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES 
(1, 'siteurl', 0x687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f, 'yes'),
(2, 'home', 0x687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f, 'yes'),
(3, 'blogname', 0x4a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065, 'yes'),
(4, 'blogdescription', 0x4a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65, 'yes'),
(5, 'users_can_register', '', 'yes'),
(6, 'admin_email', 0x696374406a616e65676f6f64616c6c2e6265, 'yes'),
(7, 'start_of_week', 0x31, 'yes'),
(8, 'use_balanceTags', '', 'yes'),
(9, 'use_smilies', 0x31, 'yes'),
(10, 'require_name_email', 0x31, 'yes'),
(11, 'comments_notify', 0x31, 'yes'),
(12, 'posts_per_rss', 0x3130, 'yes'),
(13, 'rss_use_excerpt', 0x31, 'yes'),
(14, 'mailserver_url', 0x6d61696c2e6578616d706c652e636f6d, 'yes'),
(15, 'mailserver_login', 0x6c6f67696e406578616d706c652e636f6d, 'yes'),
(16, 'mailserver_pass', 0x70617373776f7264, 'yes'),
(17, 'mailserver_port', 0x313130, 'yes'),
(18, 'default_category', 0x31, 'yes'),
(19, 'default_comment_status', 0x6f70656e, 'yes'),
(20, 'default_ping_status', 0x6f70656e, 'yes'),
(21, 'default_pingback_flag', 0x31, 'yes'),
(22, 'posts_per_page', 0x3130, 'yes'),
(23, 'date_format', 0x642f6d2f59, 'yes'),
(24, 'time_format', 0x673a692061, 'yes'),
(25, 'links_updated_date_format', 0x46206a2c205920673a692061, 'yes'),
(26, 'comment_moderation', '', 'yes'),
(27, 'moderation_notify', 0x31, 'yes'),
(28, 'permalink_structure', 0x2f25706f73746e616d65252f, 'yes'),
(30, 'hack_file', '', 'yes'),
(31, 'blog_charset', 0x5554462d38, 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 0x613a31323a7b693a303b733a32313a22706f6c796c616e672f706f6c796c616e672e706870223b693a313b733a32353a226163636f7264696f6e732f6163636f7264696f6e732e706870223b693a323b733a35313a22616c6c2d696e2d6f6e652d77702d73656375726974792d616e642d6669726577616c6c2f77702d73656375726974792e706870223b693a333b733a32313a226261636b777075702f6261636b777075702e706870223b693a343b733a33363a22636f6e746163742d666f726d2d372f77702d636f6e746163742d666f726d2d372e706870223b693a353b733a33343a2269666561747572652d736c696465722f6966656174757265736c696465722e706870223b693a363b733a31373a22696e667573652f696e667573652e706870223b693a373b733a33333a226e61762d6d656e752d726f6c65732f6e61762d6d656e752d726f6c65732e706870223b693a383b733a33303a22726f6f7473616e6473686f6f74732f696e666f5f706c7567696e2e706870223b693a393b733a34393a227365727665722d69702d6d656d6f72792d75736167652f7365727665722d69702d6d656d6f72792d75736167652e706870223b693a31303b733a32373a227376672d737570706f72742f7376672d737570706f72742e706870223b693a31313b733a34313a22776f726470726573732d696d706f727465722f776f726470726573732d696d706f727465722e706870223b7d, 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 0x687474703a2f2f7270632e70696e676f6d617469632e636f6d2f, 'yes'),
(36, 'comment_max_links', 0x32, 'yes'),
(37, 'gmt_offset', 0x32, 'yes'),
(38, 'default_email_category', 0x31, 'yes'),
(39, 'recently_edited', 0x613a353a7b693a303b733a37323a222f686f6d652f726f6f7473616e6476742f7777772f77702d636f6e74656e742f7468656d65732f696e74756974696f6e5f70726f2d6368696c642f66756e6374696f6e732e706870223b693a313b733a36393a222f686f6d652f726f6f7473616e6476742f7777772f77702d636f6e74656e742f7468656d65732f696e74756974696f6e5f70726f2d6368696c642f6865616465722e706870223b693a323b733a36383a222f686f6d652f726f6f7473616e6476742f7777772f77702d636f6e74656e742f7468656d65732f696e74756974696f6e5f70726f2d6368696c642f7374796c652e637373223b693a333b733a36353a222f686f6d652f726f6f7473616e6476742f7777772f77702d636f6e74656e742f7468656d65732f6164616d6f732d6368696c642f66756e6374696f6e732e706870223b693a343b733a36313a222f686f6d652f726f6f7473616e6476742f7777772f77702d636f6e74656e742f7468656d65732f6164616d6f732d6368696c642f7374796c652e637373223b7d, 'no'),
(40, 'template', 0x696e74756974696f6e5f70726f, 'yes'),
(41, 'stylesheet', 0x696e74756974696f6e5f70726f2d6368696c64, 'yes'),
(42, 'comment_whitelist', 0x31, 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '', 'yes'),
(45, 'html_type', 0x746578742f68746d6c, 'yes'),
(46, 'use_trackback', '', 'yes'),
(47, 'default_role', 0x73756273637269626572, 'yes'),
(48, 'db_version', 0x3338353930, 'yes'),
(49, 'uploads_use_yearmonth_folders', 0x31, 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', 0x31, 'yes'),
(52, 'default_link_category', 0x32, 'yes'),
(53, 'show_on_front', 0x70616765, 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', 0x31, 'yes'),
(56, 'avatar_rating', 0x47, 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', 0x323030, 'yes'),
(59, 'thumbnail_size_h', 0x323030, 'yes'),
(60, 'thumbnail_crop', 0x31, 'yes'),
(61, 'medium_size_w', '', 'yes'),
(62, 'medium_size_h', '', 'yes'),
(63, 'avatar_default', 0x6d797374657279, 'yes'),
(64, 'large_size_w', '', 'yes'),
(65, 'large_size_h', '', 'yes'),
(66, 'image_default_link_type', '', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '', 'yes'),
(70, 'close_comments_days_old', 0x3134, 'yes'),
(71, 'thread_comments', 0x31, 'yes'),
(72, 'thread_comments_depth', 0x35, 'yes'),
(73, 'page_comments', '', 'yes'),
(74, 'comments_per_page', 0x3530, 'yes'),
(75, 'default_comments_page', 0x6e6577657374, 'yes'),
(76, 'comment_order', 0x617363, 'yes'),
(77, 'sticky_posts', 0x613a303a7b7d, 'yes'),
(78, 'widget_categories', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(79, 'widget_text', 0x613a343a7b693a313b613a303a7b7d693a323b613a333a7b733a353a227469746c65223b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b733a343a2274657874223b733a31383a22756e64657220636f6e737472756374696f6e223b733a363a2266696c746572223b623a303b7d693a333b613a333a7b733a353a227469746c65223b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b733a343a2274657874223b733a31383a22756e64657220636f6e737472756374696f6e223b733a363a2266696c746572223b623a303b7d733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(80, 'widget_rss', 0x613a323a7b693a313b613a303a7b7d733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(81, 'uninstall_plugins', 0x613a313a7b733a32373a227376672d737570706f72742f7376672d737570706f72742e706870223b733a32323a22626f6468695f737667735f6465616374697661746564223b7d, 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '', 'yes'),
(84, 'page_on_front', 0x3939, 'yes'),
(85, 'default_post_format', '', 'yes'),
(86, 'link_manager_enabled', '', 'yes'),
(87, 'finished_splitting_shared_terms', 0x31, 'yes'),
(88, 'site_icon', '', 'yes'),
(89, 'medium_large_size_w', '', 'yes'),
(90, 'medium_large_size_h', '', 'yes'),
(91, 'initial_db_version', 0x3336363836, 'yes'),
(92, 'wor1677_user_roles', 0x613a383a7b733a31333a2261646d696e6973747261746f72223b613a323a7b733a343a226e616d65223b733a31333a2241646d696e6973747261746f72223b733a31323a226361706162696c6974696573223b613a37313a7b733a31333a227377697463685f7468656d6573223b623a313b733a31313a22656469745f7468656d6573223b623a313b733a31363a2261637469766174655f706c7567696e73223b623a313b733a31323a22656469745f706c7567696e73223b623a313b733a31303a22656469745f7573657273223b623a313b733a31303a22656469745f66696c6573223b623a313b733a31343a226d616e6167655f6f7074696f6e73223b623a313b733a31373a226d6f6465726174655f636f6d6d656e7473223b623a313b733a31373a226d616e6167655f63617465676f72696573223b623a313b733a31323a226d616e6167655f6c696e6b73223b623a313b733a31323a2275706c6f61645f66696c6573223b623a313b733a363a22696d706f7274223b623a313b733a31353a22756e66696c74657265645f68746d6c223b623a313b733a31303a22656469745f706f737473223b623a313b733a31373a22656469745f6f74686572735f706f737473223b623a313b733a32303a22656469745f7075626c69736865645f706f737473223b623a313b733a31333a227075626c6973685f706f737473223b623a313b733a31303a22656469745f7061676573223b623a313b733a343a2272656164223b623a313b733a383a226c6576656c5f3130223b623a313b733a373a226c6576656c5f39223b623a313b733a373a226c6576656c5f38223b623a313b733a373a226c6576656c5f37223b623a313b733a373a226c6576656c5f36223b623a313b733a373a226c6576656c5f35223b623a313b733a373a226c6576656c5f34223b623a313b733a373a226c6576656c5f33223b623a313b733a373a226c6576656c5f32223b623a313b733a373a226c6576656c5f31223b623a313b733a373a226c6576656c5f30223b623a313b733a31373a22656469745f6f74686572735f7061676573223b623a313b733a32303a22656469745f7075626c69736865645f7061676573223b623a313b733a31333a227075626c6973685f7061676573223b623a313b733a31323a2264656c6574655f7061676573223b623a313b733a31393a2264656c6574655f6f74686572735f7061676573223b623a313b733a32323a2264656c6574655f7075626c69736865645f7061676573223b623a313b733a31323a2264656c6574655f706f737473223b623a313b733a31393a2264656c6574655f6f74686572735f706f737473223b623a313b733a32323a2264656c6574655f7075626c69736865645f706f737473223b623a313b733a32303a2264656c6574655f707269766174655f706f737473223b623a313b733a31383a22656469745f707269766174655f706f737473223b623a313b733a31383a22726561645f707269766174655f706f737473223b623a313b733a32303a2264656c6574655f707269766174655f7061676573223b623a313b733a31383a22656469745f707269766174655f7061676573223b623a313b733a31383a22726561645f707269766174655f7061676573223b623a313b733a31323a2264656c6574655f7573657273223b623a313b733a31323a226372656174655f7573657273223b623a313b733a31373a22756e66696c74657265645f75706c6f6164223b623a313b733a31343a22656469745f64617368626f617264223b623a313b733a31343a227570646174655f706c7567696e73223b623a313b733a31343a2264656c6574655f706c7567696e73223b623a313b733a31353a22696e7374616c6c5f706c7567696e73223b623a313b733a31333a227570646174655f7468656d6573223b623a313b733a31343a22696e7374616c6c5f7468656d6573223b623a313b733a31313a227570646174655f636f7265223b623a313b733a31303a226c6973745f7573657273223b623a313b733a31323a2272656d6f76655f7573657273223b623a313b733a31333a2270726f6d6f74655f7573657273223b623a313b733a31383a22656469745f7468656d655f6f7074696f6e73223b623a313b733a31333a2264656c6574655f7468656d6573223b623a313b733a363a226578706f7274223b623a313b733a383a226261636b77707570223b623a313b733a31333a226261636b777075705f6a6f6273223b623a313b733a31383a226261636b777075705f6a6f62735f65646974223b623a313b733a31393a226261636b777075705f6a6f62735f7374617274223b623a313b733a31363a226261636b777075705f6261636b757073223b623a313b733a32353a226261636b777075705f6261636b7570735f646f776e6c6f6164223b623a313b733a32333a226261636b777075705f6261636b7570735f64656c657465223b623a313b733a31333a226261636b777075705f6c6f6773223b623a313b733a32303a226261636b777075705f6c6f67735f64656c657465223b623a313b733a31373a226261636b777075705f73657474696e6773223b623a313b7d7d733a363a22656469746f72223b613a323a7b733a343a226e616d65223b733a363a22456469746f72223b733a31323a226361706162696c6974696573223b613a33343a7b733a31373a226d6f6465726174655f636f6d6d656e7473223b623a313b733a31373a226d616e6167655f63617465676f72696573223b623a313b733a31323a226d616e6167655f6c696e6b73223b623a313b733a31323a2275706c6f61645f66696c6573223b623a313b733a31353a22756e66696c74657265645f68746d6c223b623a313b733a31303a22656469745f706f737473223b623a313b733a31373a22656469745f6f74686572735f706f737473223b623a313b733a32303a22656469745f7075626c69736865645f706f737473223b623a313b733a31333a227075626c6973685f706f737473223b623a313b733a31303a22656469745f7061676573223b623a313b733a343a2272656164223b623a313b733a373a226c6576656c5f37223b623a313b733a373a226c6576656c5f36223b623a313b733a373a226c6576656c5f35223b623a313b733a373a226c6576656c5f34223b623a313b733a373a226c6576656c5f33223b623a313b733a373a226c6576656c5f32223b623a313b733a373a226c6576656c5f31223b623a313b733a373a226c6576656c5f30223b623a313b733a31373a22656469745f6f74686572735f7061676573223b623a313b733a32303a22656469745f7075626c69736865645f7061676573223b623a313b733a31333a227075626c6973685f7061676573223b623a313b733a31323a2264656c6574655f7061676573223b623a313b733a31393a2264656c6574655f6f74686572735f7061676573223b623a313b733a32323a2264656c6574655f7075626c69736865645f7061676573223b623a313b733a31323a2264656c6574655f706f737473223b623a313b733a31393a2264656c6574655f6f74686572735f706f737473223b623a313b733a32323a2264656c6574655f7075626c69736865645f706f737473223b623a313b733a32303a2264656c6574655f707269766174655f706f737473223b623a313b733a31383a22656469745f707269766174655f706f737473223b623a313b733a31383a22726561645f707269766174655f706f737473223b623a313b733a32303a2264656c6574655f707269766174655f7061676573223b623a313b733a31383a22656469745f707269766174655f7061676573223b623a313b733a31383a22726561645f707269766174655f7061676573223b623a313b7d7d733a363a22617574686f72223b613a323a7b733a343a226e616d65223b733a363a22417574686f72223b733a31323a226361706162696c6974696573223b613a31303a7b733a31323a2275706c6f61645f66696c6573223b623a313b733a31303a22656469745f706f737473223b623a313b733a32303a22656469745f7075626c69736865645f706f737473223b623a313b733a31333a227075626c6973685f706f737473223b623a313b733a343a2272656164223b623a313b733a373a226c6576656c5f32223b623a313b733a373a226c6576656c5f31223b623a313b733a373a226c6576656c5f30223b623a313b733a31323a2264656c6574655f706f737473223b623a313b733a32323a2264656c6574655f7075626c69736865645f706f737473223b623a313b7d7d733a31313a22636f6e7472696275746f72223b613a323a7b733a343a226e616d65223b733a31313a22436f6e7472696275746f72223b733a31323a226361706162696c6974696573223b613a353a7b733a31303a22656469745f706f737473223b623a313b733a343a2272656164223b623a313b733a373a226c6576656c5f31223b623a313b733a373a226c6576656c5f30223b623a313b733a31323a2264656c6574655f706f737473223b623a313b7d7d733a31303a2273756273637269626572223b613a323a7b733a343a226e616d65223b733a31303a2253756273637269626572223b733a31323a226361706162696c6974696573223b613a323a7b733a343a2272656164223b623a313b733a373a226c6576656c5f30223b623a313b7d7d733a31343a226261636b777075705f61646d696e223b613a323a7b733a343a226e616d65223b733a31343a224261636b575075702041646d696e223b733a31323a226361706162696c6974696573223b613a31313a7b733a343a2272656164223b623a313b733a383a226261636b77707570223b623a313b733a31333a226261636b777075705f6a6f6273223b623a313b733a31383a226261636b777075705f6a6f62735f65646974223b623a313b733a31393a226261636b777075705f6a6f62735f7374617274223b623a313b733a31363a226261636b777075705f6261636b757073223b623a313b733a32353a226261636b777075705f6261636b7570735f646f776e6c6f6164223b623a313b733a32333a226261636b777075705f6261636b7570735f64656c657465223b623a313b733a31333a226261636b777075705f6c6f6773223b623a313b733a32303a226261636b777075705f6c6f67735f64656c657465223b623a313b733a31373a226261636b777075705f73657474696e6773223b623a313b7d7d733a31343a226261636b777075705f636865636b223b613a323a7b733a343a226e616d65223b733a32313a224261636b57507570206a6f627320636865636b6572223b733a31323a226361706162696c6974696573223b613a31313a7b733a343a2272656164223b623a313b733a383a226261636b77707570223b623a313b733a31333a226261636b777075705f6a6f6273223b623a313b733a31383a226261636b777075705f6a6f62735f65646974223b623a303b733a31393a226261636b777075705f6a6f62735f7374617274223b623a303b733a31363a226261636b777075705f6261636b757073223b623a313b733a32353a226261636b777075705f6261636b7570735f646f776e6c6f6164223b623a303b733a32333a226261636b777075705f6261636b7570735f64656c657465223b623a303b733a31333a226261636b777075705f6c6f6773223b623a313b733a32303a226261636b777075705f6c6f67735f64656c657465223b623a303b733a31373a226261636b777075705f73657474696e6773223b623a303b7d7d733a31353a226261636b777075705f68656c706572223b613a323a7b733a343a226e616d65223b733a32303a224261636b57507570206a6f62732068656c706572223b733a31323a226361706162696c6974696573223b613a31313a7b733a343a2272656164223b623a313b733a383a226261636b77707570223b623a313b733a31333a226261636b777075705f6a6f6273223b623a313b733a31383a226261636b777075705f6a6f62735f65646974223b623a303b733a31393a226261636b777075705f6a6f62735f7374617274223b623a313b733a31363a226261636b777075705f6261636b757073223b623a313b733a32353a226261636b777075705f6261636b7570735f646f776e6c6f6164223b623a313b733a32333a226261636b777075705f6261636b7570735f64656c657465223b623a313b733a31333a226261636b777075705f6c6f6773223b623a313b733a32303a226261636b777075705f6c6f67735f64656c657465223b623a313b733a31373a226261636b777075705f73657474696e6773223b623a303b7d7d7d, 'yes'),
(93, 'widget_search', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(94, 'widget_recent-posts', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(95, 'widget_recent-comments', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(96, 'widget_archives', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(97, 'widget_meta', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(98, 'sidebars_widgets', 0x613a373a7b733a31393a2277705f696e6163746976655f77696467657473223b613a303a7b7d733a31353a227072696d6172792d77696467657473223b613a303a7b7d733a31373a227365636f6e646172792d77696467657473223b613a303a7b7d733a31363a22666f6f7465722d776964676574732d31223b613a313a7b693a303b733a363a22746578742d32223b7d733a31363a22666f6f7465722d776964676574732d32223b613a313a7b693a303b733a363a22746578742d33223b7d733a31363a22666f6f7465722d776964676574732d33223b613a313a7b693a303b733a31303a2263616c656e6461722d32223b7d733a31333a2261727261795f76657273696f6e223b693a333b7d, 'yes'),
(2722, 'widget_polylang', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(30464, '_site_transient_timeout_available_translations', 0x31343931383437383536, 'no'),
(30465, '_site_transient_available_translations', 0x613a3130383a7b733a323a226166223b613a383a7b733a383a226c616e6775616765223b733a323a226166223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32372030343a33323a3439223b733a31323a22656e676c6973685f6e616d65223b733a393a22416672696b61616e73223b733a31313a226e61746976655f6e616d65223b733a393a22416672696b61616e73223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f61662e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226166223b693a323b733a333a22616672223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31303a224761616e20766f6f7274223b7d7d733a333a22617279223b613a383a7b733a383a226c616e6775616765223b733a333a22617279223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34323a3335223b733a31323a22656e676c6973685f6e616d65223b733a31353a224d6f726f6363616e20417261626963223b733a31313a226e61746976655f6e616d65223b733a33313a22d8a7d984d8b9d8b1d8a8d98ad8a920d8a7d984d985d8bad8b1d8a8d98ad8a9223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6172792e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226172223b693a333b733a333a22617279223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31363a22d8a7d984d985d8aad8a7d8a8d8b9d8a9223b7d7d733a323a226172223b613a383a7b733a383a226c616e6775616765223b733a323a226172223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34393a3038223b733a31323a22656e676c6973685f6e616d65223b733a363a22417261626963223b733a31313a226e61746976655f6e616d65223b733a31343a22d8a7d984d8b9d8b1d8a8d98ad8a9223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f61722e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226172223b693a323b733a333a22617261223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31363a22d8a7d984d985d8aad8a7d8a8d8b9d8a9223b7d7d733a323a226173223b613a383a7b733a383a226c616e6775616765223b733a323a226173223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31312d32322031383a35393a3037223b733a31323a22656e676c6973685f6e616d65223b733a383a22417373616d657365223b733a31313a226e61746976655f6e616d65223b733a32313a22e0a685e0a6b8e0a6aee0a780e0a6afe0a6bce0a6be223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f61732e7a6970223b733a333a2269736f223b613a333a7b693a313b733a323a226173223b693a323b733a333a2261736d223b693a333b733a333a2261736d223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a303a22223b7d7d733a333a22617a62223b613a383a7b733a383a226c616e6775616765223b733a333a22617a62223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30392d31322032303a33343a3331223b733a31323a22656e676c6973685f6e616d65223b733a31373a22536f75746820417a65726261696a616e69223b733a31313a226e61746976655f6e616d65223b733a32393a22daafd8a4d986d8a6db8c20d8a2d8b0d8b1d8a8d8a7db8cd8acd8a7d986223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f617a622e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22617a223b693a333b733a333a22617a62223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22436f6e74696e7565223b7d7d733a323a22617a223b613a383a7b733a383a226c616e6775616765223b733a323a22617a223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31312d30362030303a30393a3237223b733a31323a22656e676c6973685f6e616d65223b733a31313a22417a65726261696a616e69223b733a31313a226e61746976655f6e616d65223b733a31363a22417ac9997262617963616e2064696c69223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f617a2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22617a223b693a323b733a333a22617a65223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a353a22446176616d223b7d7d733a333a2262656c223b613a383a7b733a383a226c616e6775616765223b733a333a2262656c223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32332030343a33363a3532223b733a31323a22656e676c6973685f6e616d65223b733a31303a2242656c6172757369616e223b733a31313a226e61746976655f6e616d65223b733a32393a22d091d0b5d0bbd0b0d180d183d181d0bad0b0d18f20d0bcd0bed0b2d0b0223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f62656c2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226265223b693a323b733a333a2262656c223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32303a22d09fd180d0b0d186d18fd0b3d0bdd183d186d18c223b7d7d733a353a2262675f4247223b613a383a7b733a383a226c616e6775616765223b733a353a2262675f4247223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d30362030393a31383a3537223b733a31323a22656e676c6973685f6e616d65223b733a393a2242756c67617269616e223b733a31313a226e61746976655f6e616d65223b733a31383a22d091d18ad0bbd0b3d0b0d180d181d0bad0b8223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f62675f42472e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226267223b693a323b733a333a2262756c223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31323a22d09dd0b0d0bfd180d0b5d0b4223b7d7d733a353a22626e5f4244223b613a383a7b733a383a226c616e6775616765223b733a353a22626e5f4244223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d30342031363a35383a3433223b733a31323a22656e676c6973685f6e616d65223b733a373a2242656e67616c69223b733a31313a226e61746976655f6e616d65223b733a31353a22e0a6ace0a6bee0a682e0a6b2e0a6be223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f626e5f42442e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a22626e223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32333a22e0a68fe0a697e0a6bfe0a79fe0a78720e0a69ae0a6b22e223b7d7d733a323a22626f223b613a383a7b733a383a226c616e6775616765223b733a323a22626f223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30392d30352030393a34343a3132223b733a31323a22656e676c6973685f6e616d65223b733a373a225469626574616e223b733a31313a226e61746976655f6e616d65223b733a32313a22e0bd96e0bdbce0bd91e0bc8be0bda1e0bdb2e0bd82223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f626f2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22626f223b693a323b733a333a22746962223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32343a22e0bd98e0bdb4e0bc8be0bd98e0bd90e0bdb4e0bd91e0bc8d223b7d7d733a353a2262735f4241223b613a383a7b733a383a226c616e6775616765223b733a353a2262735f4241223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30392d30342032303a32303a3238223b733a31323a22656e676c6973685f6e616d65223b733a373a22426f736e69616e223b733a31313a226e61746976655f6e616d65223b733a383a22426f73616e736b69223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f62735f42412e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226273223b693a323b733a333a22626f73223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a373a224e617374617669223b7d7d733a323a226361223b613a383a7b733a383a226c616e6775616765223b733a323a226361223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d30352031313a33343a3437223b733a31323a22656e676c6973685f6e616d65223b733a373a22436174616c616e223b733a31313a226e61746976655f6e616d65223b733a373a22436174616cc3a0223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f63612e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226361223b693a323b733a333a22636174223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22436f6e74696e7561223b7d7d733a333a22636562223b613a383a7b733a383a226c616e6775616765223b733a333a22636562223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30332d30322031373a32353a3531223b733a31323a22656e676c6973685f6e616d65223b733a373a2243656275616e6f223b733a31313a226e61746976655f6e616d65223b733a373a2243656275616e6f223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f6365622e7a6970223b733a333a2269736f223b613a323a7b693a323b733a333a22636562223b693a333b733a333a22636562223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a373a225061646179756e223b7d7d733a353a2263735f435a223b613a383a7b733a383a226c616e6775616765223b733a353a2263735f435a223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d31322030383a34363a3236223b733a31323a22656e676c6973685f6e616d65223b733a353a22437a656368223b733a31313a226e61746976655f6e616d65223b733a31323a22c48c65c5a174696e61e2808e223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f63735f435a2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226373223b693a323b733a333a22636573223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31313a22506f6b7261c48d6f766174223b7d7d733a323a226379223b613a383a7b733a383a226c616e6775616765223b733a323a226379223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34393a3239223b733a31323a22656e676c6973685f6e616d65223b733a353a2257656c7368223b733a31313a226e61746976655f6e616d65223b733a373a2243796d72616567223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f63792e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226379223b693a323b733a333a2263796d223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22506172686175223b7d7d733a353a2264615f444b223b613a383a7b733a383a226c616e6775616765223b733a353a2264615f444b223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30352030393a35303a3036223b733a31323a22656e676c6973685f6e616d65223b733a363a2244616e697368223b733a31313a226e61746976655f6e616d65223b733a353a2244616e736b223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f64615f444b2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226461223b693a323b733a333a2264616e223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31323a22466f72747326233233303b74223b7d7d733a353a2264655f4445223b613a383a7b733a383a226c616e6775616765223b733a353a2264655f4445223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d31382031333a35373a3432223b733a31323a22656e676c6973685f6e616d65223b733a363a224765726d616e223b733a31313a226e61746976655f6e616d65223b733a373a2244657574736368223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f64655f44452e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a226465223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22576569746572223b7d7d733a353a2264655f4348223b613a383a7b733a383a226c616e6775616765223b733a353a2264655f4348223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34303a3033223b733a31323a22656e676c6973685f6e616d65223b733a32303a224765726d616e2028537769747a65726c616e6429223b733a31313a226e61746976655f6e616d65223b733a31373a224465757473636820285363687765697a29223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f64655f43482e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a226465223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22576569746572223b7d7d733a31323a2264655f44455f666f726d616c223b613a383a7b733a383a226c616e6775616765223b733a31323a2264655f44455f666f726d616c223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d31382031333a35373a3533223b733a31323a22656e676c6973685f6e616d65223b733a31353a224765726d616e2028466f726d616c29223b733a31313a226e61746976655f6e616d65223b733a31333a2244657574736368202853696529223b733a373a227061636b616765223b733a37313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f64655f44455f666f726d616c2e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a226465223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22576569746572223b7d7d733a31343a2264655f43485f696e666f726d616c223b613a383a7b733a383a226c616e6775616765223b733a31343a2264655f43485f696e666f726d616c223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a33393a3539223b733a31323a22656e676c6973685f6e616d65223b733a33303a224765726d616e2028537769747a65726c616e642c20496e666f726d616c29223b733a31313a226e61746976655f6e616d65223b733a32313a224465757473636820285363687765697a2c20447529223b733a373a227061636b616765223b733a37333a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f64655f43485f696e666f726d616c2e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a226465223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22576569746572223b7d7d733a333a22647a6f223b613a383a7b733a383a226c616e6775616765223b733a333a22647a6f223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30362d32392030383a35393a3033223b733a31323a22656e676c6973685f6e616d65223b733a383a22447a6f6e676b6861223b733a31313a226e61746976655f6e616d65223b733a31383a22e0bda2e0beabe0bdbce0bd84e0bc8be0bd81223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f647a6f2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22647a223b693a323b733a333a22647a6f223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a303a22223b7d7d733a323a22656c223b613a383a7b733a383a226c616e6775616765223b733a323a22656c223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d33302030303a30383a3039223b733a31323a22656e676c6973685f6e616d65223b733a353a22477265656b223b733a31313a226e61746976655f6e616d65223b733a31363a22ce95cebbcebbceb7cebdceb9cebaceac223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f656c2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22656c223b693a323b733a333a22656c6c223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31363a22cea3cf85cebdceadcf87ceb5ceb9ceb1223b7d7d733a353a22656e5f4742223b613a383a7b733a383a226c616e6775616765223b733a353a22656e5f4742223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32382030333a31303a3235223b733a31323a22656e676c6973685f6e616d65223b733a31323a22456e676c6973682028554b29223b733a31313a226e61746976655f6e616d65223b733a31323a22456e676c6973682028554b29223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f656e5f47422e7a6970223b733a333a2269736f223b613a333a7b693a313b733a323a22656e223b693a323b733a333a22656e67223b693a333b733a333a22656e67223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22436f6e74696e7565223b7d7d733a353a22656e5f5a41223b613a383a7b733a383a226c616e6775616765223b733a353a22656e5f5a41223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a35333a3433223b733a31323a22656e676c6973685f6e616d65223b733a32323a22456e676c6973682028536f7574682041667269636129223b733a31313a226e61746976655f6e616d65223b733a32323a22456e676c6973682028536f7574682041667269636129223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f656e5f5a412e7a6970223b733a333a2269736f223b613a333a7b693a313b733a323a22656e223b693a323b733a333a22656e67223b693a333b733a333a22656e67223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22436f6e74696e7565223b7d7d733a353a22656e5f4155223b613a383a7b733a383a226c616e6775616765223b733a353a22656e5f4155223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32372030303a34303a3238223b733a31323a22656e676c6973685f6e616d65223b733a31393a22456e676c69736820284175737472616c696129223b733a31313a226e61746976655f6e616d65223b733a31393a22456e676c69736820284175737472616c696129223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f656e5f41552e7a6970223b733a333a2269736f223b613a333a7b693a313b733a323a22656e223b693a323b733a333a22656e67223b693a333b733a333a22656e67223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22436f6e74696e7565223b7d7d733a353a22656e5f4341223b613a383a7b733a383a226c616e6775616765223b733a353a22656e5f4341223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34393a3334223b733a31323a22656e676c6973685f6e616d65223b733a31363a22456e676c697368202843616e61646129223b733a31313a226e61746976655f6e616d65223b733a31363a22456e676c697368202843616e61646129223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f656e5f43412e7a6970223b733a333a2269736f223b613a333a7b693a313b733a323a22656e223b693a323b733a333a22656e67223b693a333b733a333a22656e67223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22436f6e74696e7565223b7d7d733a353a22656e5f4e5a223b613a383a7b733a383a226c616e6775616765223b733a353a22656e5f4e5a223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a35343a3330223b733a31323a22656e676c6973685f6e616d65223b733a32313a22456e676c69736820284e6577205a65616c616e6429223b733a31313a226e61746976655f6e616d65223b733a32313a22456e676c69736820284e6577205a65616c616e6429223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f656e5f4e5a2e7a6970223b733a333a2269736f223b613a333a7b693a313b733a323a22656e223b693a323b733a333a22656e67223b693a333b733a333a22656e67223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22436f6e74696e7565223b7d7d733a323a22656f223b613a383a7b733a383a226c616e6775616765223b733a323a22656f223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34373a3037223b733a31323a22656e676c6973685f6e616d65223b733a393a224573706572616e746f223b733a31313a226e61746976655f6e616d65223b733a393a224573706572616e746f223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f656f2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22656f223b693a323b733a333a2265706f223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a224461c5ad72696769223b7d7d733a353a2265735f4553223b613a383a7b733a383a226c616e6775616765223b733a353a2265735f4553223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d31352031323a35333a3137223b733a31323a22656e676c6973685f6e616d65223b733a31353a225370616e6973682028537061696e29223b733a31313a226e61746976655f6e616d65223b733a383a2245737061c3b16f6c223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f65735f45532e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a226573223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a353a2265735f5645223b613a383a7b733a383a226c616e6775616765223b733a353a2265735f5645223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a35333a3536223b733a31323a22656e676c6973685f6e616d65223b733a31393a225370616e697368202856656e657a75656c6129223b733a31313a226e61746976655f6e616d65223b733a32313a2245737061c3b16f6c2064652056656e657a75656c61223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f65735f56452e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226573223b693a323b733a333a22737061223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a353a2265735f5045223b613a383a7b733a383a226c616e6775616765223b733a353a2265735f5045223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30392d30392030393a33363a3232223b733a31323a22656e676c6973685f6e616d65223b733a31343a225370616e69736820285065727529223b733a31313a226e61746976655f6e616d65223b733a31373a2245737061c3b16f6c20646520506572c3ba223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f65735f50452e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226573223b693a323b733a333a22737061223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a353a2265735f434c223b613a383a7b733a383a226c616e6775616765223b733a353a2265735f434c223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31312d32382032303a30393a3439223b733a31323a22656e676c6973685f6e616d65223b733a31353a225370616e69736820284368696c6529223b733a31313a226e61746976655f6e616d65223b733a31373a2245737061c3b16f6c206465204368696c65223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f65735f434c2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226573223b693a323b733a333a22737061223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a353a2265735f4152223b613a383a7b733a383a226c616e6775616765223b733a353a2265735f4152223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34313a3331223b733a31323a22656e676c6973685f6e616d65223b733a31393a225370616e6973682028417267656e74696e6129223b733a31313a226e61746976655f6e616d65223b733a32313a2245737061c3b16f6c20646520417267656e74696e61223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f65735f41522e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226573223b693a323b733a333a22737061223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a353a2265735f434f223b613a383a7b733a383a226c616e6775616765223b733a353a2265735f434f223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a35343a3337223b733a31323a22656e676c6973685f6e616d65223b733a31383a225370616e6973682028436f6c6f6d62696129223b733a31313a226e61746976655f6e616d65223b733a32303a2245737061c3b16f6c20646520436f6c6f6d626961223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f65735f434f2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226573223b693a323b733a333a22737061223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a353a2265735f4754223b613a383a7b733a383a226c616e6775616765223b733a353a2265735f4754223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a35343a3337223b733a31323a22656e676c6973685f6e616d65223b733a31393a225370616e697368202847756174656d616c6129223b733a31313a226e61746976655f6e616d65223b733a32313a2245737061c3b16f6c2064652047756174656d616c61223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f65735f47542e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226573223b693a323b733a333a22737061223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a353a2265735f4d58223b613a383a7b733a383a226c616e6775616765223b733a353a2265735f4d58223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34323a3238223b733a31323a22656e676c6973685f6e616d65223b733a31363a225370616e69736820284d657869636f29223b733a31313a226e61746976655f6e616d65223b733a31393a2245737061c3b16f6c206465204dc3a97869636f223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f65735f4d582e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226573223b693a323b733a333a22737061223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a323a226574223b613a383a7b733a383a226c616e6775616765223b733a323a226574223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32372031363a33373a3131223b733a31323a22656e676c6973685f6e616d65223b733a383a224573746f6e69616e223b733a31313a226e61746976655f6e616d65223b733a353a224565737469223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f65742e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226574223b693a323b733a333a22657374223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a224ac3a4746b61223b7d7d733a323a226575223b613a383a7b733a383a226c616e6775616765223b733a323a226575223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a35343a3333223b733a31323a22656e676c6973685f6e616d65223b733a363a22426173717565223b733a31313a226e61746976655f6e616d65223b733a373a224575736b617261223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f65752e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226575223b693a323b733a333a22657573223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a224a61727261697475223b7d7d733a353a2266615f4952223b613a383a7b733a383a226c616e6775616765223b733a353a2266615f4952223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30322d30322031353a32313a3033223b733a31323a22656e676c6973685f6e616d65223b733a373a225065727369616e223b733a31313a226e61746976655f6e616d65223b733a31303a22d981d8a7d8b1d8b3db8c223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f66615f49522e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226661223b693a323b733a333a22666173223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31303a22d8a7d8afd8a7d985d987223b7d7d733a323a226669223b613a383a7b733a383a226c616e6775616765223b733a323a226669223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34323a3235223b733a31323a22656e676c6973685f6e616d65223b733a373a2246696e6e697368223b733a31313a226e61746976655f6e616d65223b733a353a2253756f6d69223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f66692e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226669223b693a323b733a333a2266696e223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a353a224a61746b61223b7d7d733a353a2266725f4652223b613a383a7b733a383a226c616e6775616765223b733a353a2266725f4652223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d31382031363a30353a3039223b733a31323a22656e676c6973685f6e616d65223b733a31353a224672656e636820284672616e636529223b733a31313a226e61746976655f6e616d65223b733a393a224672616ec3a7616973223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f66725f46522e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a226672223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756572223b7d7d733a353a2266725f4245223b613a383a7b733a383a226c616e6775616765223b733a353a2266725f4245223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34303a3332223b733a31323a22656e676c6973685f6e616d65223b733a31363a224672656e6368202842656c6769756d29223b733a31313a226e61746976655f6e616d65223b733a32313a224672616ec3a76169732064652042656c6769717565223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f66725f42452e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226672223b693a323b733a333a22667261223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756572223b7d7d733a353a2266725f4341223b613a383a7b733a383a226c616e6775616765223b733a353a2266725f4341223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30322d30332032313a30383a3235223b733a31323a22656e676c6973685f6e616d65223b733a31353a224672656e6368202843616e61646129223b733a31313a226e61746976655f6e616d65223b733a31393a224672616ec3a76169732064752043616e616461223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f66725f43412e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226672223b693a323b733a333a22667261223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756572223b7d7d733a323a226764223b613a383a7b733a383a226c616e6775616765223b733a323a226764223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30382d32332031373a34313a3337223b733a31323a22656e676c6973685f6e616d65223b733a31353a2253636f7474697368204761656c6963223b733a31313a226e61746976655f6e616d65223b733a393a2247c3a06964686c6967223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f67642e7a6970223b733a333a2269736f223b613a333a7b693a313b733a323a226764223b693a323b733a333a22676c61223b693a333b733a333a22676c61223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31353a224c65616e2061697220616468617274223b7d7d733a353a22676c5f4553223b613a383a7b733a383a226c616e6775616765223b733a353a22676c5f4553223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34303a3237223b733a31323a22656e676c6973685f6e616d65223b733a383a2247616c696369616e223b733a31313a226e61746976655f6e616d65223b733a363a2247616c65676f223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f676c5f45532e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22676c223b693a323b733a333a22676c67223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a323a226775223b613a383a7b733a383a226c616e6775616765223b733a323a226775223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30352030363a35393a3538223b733a31323a22656e676c6973685f6e616d65223b733a383a2247756a6172617469223b733a31313a226e61746976655f6e616d65223b733a32313a22e0aa97e0ab81e0aa9ce0aab0e0aabee0aaa4e0ab80223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f67752e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226775223b693a323b733a333a2267756a223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a33313a22e0aa9ae0aabee0aab2e0ab8120e0aab0e0aabee0aa96e0aab5e0ab81e0aa82223b7d7d733a333a2268617a223b613a383a7b733a383a226c616e6775616765223b733a333a2268617a223b733a373a2276657273696f6e223b733a353a22342e342e32223b733a373a2275706461746564223b733a31393a22323031352d31322d30352030303a35393a3039223b733a31323a22656e676c6973685f6e616d65223b733a383a2248617a6172616769223b733a31313a226e61746976655f6e616d65223b733a31353a22d987d8b2d8a7d8b1d98720daafdb8c223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e342e322f68617a2e7a6970223b733a333a2269736f223b613a313a7b693a333b733a333a2268617a223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31303a22d8a7d8afd8a7d985d987223b7d7d733a353a2268655f494c223b613a383a7b733a383a226c616e6775616765223b733a353a2268655f494c223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32392032313a32313a3130223b733a31323a22656e676c6973685f6e616d65223b733a363a22486562726577223b733a31313a226e61746976655f6e616d65223b733a31363a22d7a2d6b4d791d6b0d7a8d6b4d799d7aa223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f68655f494c2e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a226865223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22d794d79ed7a9d79a223b7d7d733a353a2268695f494e223b613a383a7b733a383a226c616e6775616765223b733a353a2268695f494e223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d30332031323a31383a3235223b733a31323a22656e676c6973685f6e616d65223b733a353a2248696e6469223b733a31313a226e61746976655f6e616d65223b733a31383a22e0a4b9e0a4bfe0a4a8e0a58de0a4a6e0a580223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f68695f494e2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226869223b693a323b733a333a2268696e223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31323a22e0a49ce0a4bee0a4b0e0a580223b7d7d733a323a226872223b613a383a7b733a383a226c616e6775616765223b733a323a226872223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32382031333a33343a3232223b733a31323a22656e676c6973685f6e616d65223b733a383a2243726f617469616e223b733a31313a226e61746976655f6e616d65223b733a383a224872766174736b69223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f68722e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226872223b693a323b733a333a22687276223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a373a224e617374617669223b7d7d733a353a2268755f4855223b613a383a7b733a383a226c616e6775616765223b733a353a2268755f4855223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34383a3339223b733a31323a22656e676c6973685f6e616d65223b733a393a2248756e67617269616e223b733a31313a226e61746976655f6e616d65223b733a363a224d6167796172223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f68755f48552e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226875223b693a323b733a333a2268756e223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31303a22466f6c79746174c3a173223b7d7d733a323a226879223b613a383a7b733a383a226c616e6775616765223b733a323a226879223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31322d30332031363a32313a3130223b733a31323a22656e676c6973685f6e616d65223b733a383a2241726d656e69616e223b733a31313a226e61746976655f6e616d65223b733a31343a22d580d5a1d5b5d5a5d680d5a5d5b6223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f68792e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226879223b693a323b733a333a22687965223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32303a22d587d5a1d680d5b8d682d5b6d5a1d5afd5a5d5ac223b7d7d733a353a2269645f4944223b613a383a7b733a383a226c616e6775616765223b733a353a2269645f4944223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30332030323a32373a3435223b733a31323a22656e676c6973685f6e616d65223b733a31303a22496e646f6e657369616e223b733a31313a226e61746976655f6e616d65223b733a31363a2242616861736120496e646f6e65736961223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f69645f49442e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226964223b693a323b733a333a22696e64223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a224c616e6a75746b616e223b7d7d733a353a2269735f4953223b613a383a7b733a383a226c616e6775616765223b733a353a2269735f4953223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30322d31362031333a33363a3436223b733a31323a22656e676c6973685f6e616d65223b733a393a224963656c616e646963223b733a31313a226e61746976655f6e616d65223b733a393a22c38d736c656e736b61223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f69735f49532e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226973223b693a323b733a333a2269736c223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22c3816672616d223b7d7d733a353a2269745f4954223b613a383a7b733a383a226c616e6775616765223b733a353a2269745f4954223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30382030343a35373a3534223b733a31323a22656e676c6973685f6e616d65223b733a373a224974616c69616e223b733a31313a226e61746976655f6e616d65223b733a383a224974616c69616e6f223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f69745f49542e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226974223b693a323b733a333a22697461223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22436f6e74696e7561223b7d7d733a323a226a61223b613a383a7b733a383a226c616e6775616765223b733a323a226a61223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32392031343a32333a3036223b733a31323a22656e676c6973685f6e616d65223b733a383a224a6170616e657365223b733a31313a226e61746976655f6e616d65223b733a393a22e697a5e69cace8aa9e223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6a612e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a226a61223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22e7b69ae38191e3828b223b7d7d733a353a226b615f4745223b613a383a7b733a383a226c616e6775616765223b733a353a226b615f4745223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30352030363a31373a3030223b733a31323a22656e676c6973685f6e616d65223b733a383a2247656f726769616e223b733a31313a226e61746976655f6e616d65223b733a32313a22e183a5e18390e183a0e18397e183a3e1839ae18398223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6b615f47452e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226b61223b693a323b733a333a226b6174223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a33303a22e18392e18390e18392e183a0e183abe18394e1839ae18394e18391e18390223b7d7d733a333a226b6162223b613a383a7b733a383a226c616e6775616765223b733a333a226b6162223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a33393a3133223b733a31323a22656e676c6973685f6e616d65223b733a363a224b6162796c65223b733a31313a226e61746976655f6e616d65223b733a393a225461716261796c6974223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f6b61622e7a6970223b733a333a2269736f223b613a323a7b693a323b733a333a226b6162223b693a333b733a333a226b6162223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a224b656d6d656c223b7d7d733a323a226b6d223b613a383a7b733a383a226c616e6775616765223b733a323a226b6d223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31322d30372030323a30373a3539223b733a31323a22656e676c6973685f6e616d65223b733a353a224b686d6572223b733a31313a226e61746976655f6e616d65223b733a32373a22e19e97e19eb6e19e9fe19eb6e19e81e19f92e19e98e19f82e19e9a223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f6b6d2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226b6d223b693a323b733a333a226b686d223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31323a22e19e94e19e93e19f92e19e8f223b7d7d733a353a226b6f5f4b52223b613a383a7b733a383a226c616e6775616765223b733a353a226b6f5f4b52223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30342030353a34333a3531223b733a31323a22656e676c6973685f6e616d65223b733a363a224b6f7265616e223b733a31313a226e61746976655f6e616d65223b733a393a22ed959ceab5adec96b4223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6b6f5f4b522e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226b6f223b693a323b733a333a226b6f72223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22eab384ec868d223b7d7d733a333a22636b62223b613a383a7b733a383a226c616e6775616765223b733a333a22636b62223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34383a3235223b733a31323a22656e676c6973685f6e616d65223b733a31363a224b7572646973682028536f72616e6929223b733a31313a226e61746976655f6e616d65223b733a31333a22d983d988d8b1d8afdb8ce2808e223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f636b622e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226b75223b693a333b733a333a22636b62223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a33303a22d8a8d987e2808cd8b1d8afd987e2808cd988d8a7d98520d8a8d987e2808c223b7d7d733a323a226c6f223b613a383a7b733a383a226c616e6775616765223b733a323a226c6f223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31312d31322030393a35393a3233223b733a31323a22656e676c6973685f6e616d65223b733a333a224c616f223b733a31313a226e61746976655f6e616d65223b733a32313a22e0ba9ee0bab2e0baaae0bab2e0baa5e0bab2e0baa7223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f6c6f2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226c6f223b693a323b733a333a226c616f223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31383a22e0ba95e0bb8de0bb88e2808be0bb84e0ba9b223b7d7d733a353a226c745f4c54223b613a383a7b733a383a226c616e6775616765223b733a353a226c745f4c54223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d33302030393a34363a3133223b733a31323a22656e676c6973685f6e616d65223b733a31303a224c69746875616e69616e223b733a31313a226e61746976655f6e616d65223b733a31353a224c696574757669c5b3206b616c6261223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6c745f4c542e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226c74223b693a323b733a333a226c6974223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a2254c499737469223b7d7d733a323a226c76223b613a383a7b733a383a226c616e6775616765223b733a323a226c76223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d31372032303a34303a3430223b733a31323a22656e676c6973685f6e616d65223b733a373a224c61747669616e223b733a31313a226e61746976655f6e616d65223b733a31363a224c6174766965c5a1752076616c6f6461223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6c762e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226c76223b693a323b733a333a226c6176223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a2254757270696ec48174223b7d7d733a353a226d6b5f4d4b223b613a383a7b733a383a226c616e6775616765223b733a353a226d6b5f4d4b223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a35343a3431223b733a31323a22656e676c6973685f6e616d65223b733a31303a224d616365646f6e69616e223b733a31313a226e61746976655f6e616d65223b733a33313a22d09cd0b0d0bad0b5d0b4d0bed0bdd181d0bad0b820d198d0b0d0b7d0b8d0ba223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6d6b5f4d4b2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226d6b223b693a323b733a333a226d6b64223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31363a22d09fd180d0bed0b4d0bed0bbd0b6d0b8223b7d7d733a353a226d6c5f494e223b613a383a7b733a383a226c616e6775616765223b733a353a226d6c5f494e223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32372030333a34333a3332223b733a31323a22656e676c6973685f6e616d65223b733a393a224d616c6179616c616d223b733a31313a226e61746976655f6e616d65223b733a31383a22e0b4aee0b4b2e0b4afe0b4bee0b4b3e0b482223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f6d6c5f494e2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226d6c223b693a323b733a333a226d616c223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31383a22e0b4a4e0b581e0b49fe0b4b0e0b581e0b495223b7d7d733a323a226d6e223b613a383a7b733a383a226c616e6775616765223b733a323a226d6e223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d31322030373a32393a3335223b733a31323a22656e676c6973685f6e616d65223b733a393a224d6f6e676f6c69616e223b733a31313a226e61746976655f6e616d65223b733a31323a22d09cd0bed0bdd0b3d0bed0bb223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f6d6e2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226d6e223b693a323b733a333a226d6f6e223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32343a22d2aed180d0b3d18dd0bbd0b6d0bbd2afd2afd0bbd18dd185223b7d7d733a323a226d72223b613a383a7b733a383a226c616e6775616765223b733a323a226d72223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32342030363a35323a3131223b733a31323a22656e676c6973685f6e616d65223b733a373a224d617261746869223b733a31313a226e61746976655f6e616d65223b733a31353a22e0a4aee0a4b0e0a4bee0a4a0e0a580223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6d722e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226d72223b693a323b733a333a226d6172223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32353a22e0a4b8e0a581e0a4b0e0a58120e0a4a0e0a587e0a4b5e0a4be223b7d7d733a353a226d735f4d59223b613a383a7b733a383a226c616e6775616765223b733a353a226d735f4d59223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d30352030393a34353a3130223b733a31323a22656e676c6973685f6e616d65223b733a353a224d616c6179223b733a31313a226e61746976655f6e616d65223b733a31333a22426168617361204d656c617975223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6d735f4d592e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226d73223b693a323b733a333a226d7361223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a2254657275736b616e223b7d7d733a353a226d795f4d4d223b613a383a7b733a383a226c616e6775616765223b733a353a226d795f4d4d223b733a373a2276657273696f6e223b733a363a22342e312e3136223b733a373a2275706461746564223b733a31393a22323031352d30332d32362031353a35373a3432223b733a31323a22656e676c6973685f6e616d65223b733a31373a224d79616e6d617220284275726d65736529223b733a31313a226e61746976655f6e616d65223b733a31353a22e18097e18099e180ace18085e180ac223b733a373a227061636b616765223b733a36353a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e312e31362f6d795f4d4d2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226d79223b693a323b733a333a226d7961223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a35343a22e18086e18080e180bae1809ce18080e180bae1809ce180afe18095e180bae18086e180b1e180ace18084e180bae18095e180abe1818b223b7d7d733a353a226e625f4e4f223b613a383a7b733a383a226c616e6775616765223b733a353a226e625f4e4f223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34323a3331223b733a31323a22656e676c6973685f6e616d65223b733a31393a224e6f7277656769616e2028426f6b6dc3a56c29223b733a31313a226e61746976655f6e616d65223b733a31333a224e6f72736b20626f6b6dc3a56c223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6e625f4e4f2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226e62223b693a323b733a333a226e6f62223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22466f727473657474223b7d7d733a353a226e655f4e50223b613a383a7b733a383a226c616e6775616765223b733a353a226e655f4e50223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34383a3331223b733a31323a22656e676c6973685f6e616d65223b733a363a224e6570616c69223b733a31313a226e61746976655f6e616d65223b733a31383a22e0a4a8e0a587e0a4aae0a4bee0a4b2e0a580223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f6e655f4e502e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226e65223b693a323b733a333a226e6570223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a34333a22e0a49ce0a4bee0a4b0e0a58020e0a4b0e0a4bee0a496e0a58de0a4a8e0a581e0a4b9e0a58be0a4b8e0a58d223b7d7d733a31323a226e6c5f4e4c5f666f726d616c223b613a383a7b733a383a226c616e6775616765223b733a31323a226e6c5f4e4c5f666f726d616c223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30322d31362031333a32343a3231223b733a31323a22656e676c6973685f6e616d65223b733a31343a2244757463682028466f726d616c29223b733a31313a226e61746976655f6e616d65223b733a32303a224e656465726c616e64732028466f726d65656c29223b733a373a227061636b616765223b733a37313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6e6c5f4e4c5f666f726d616c2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226e6c223b693a323b733a333a226e6c64223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22446f6f726761616e223b7d7d733a353a226e6c5f4e4c223b613a383a7b733a383a226c616e6775616765223b733a353a226e6c5f4e4c223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30332031343a30373a3231223b733a31323a22656e676c6973685f6e616d65223b733a353a224475746368223b733a31313a226e61746976655f6e616d65223b733a31303a224e656465726c616e6473223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6e6c5f4e4c2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226e6c223b693a323b733a333a226e6c64223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22446f6f726761616e223b7d7d733a353a226e6c5f4245223b613a383a7b733a383a226c616e6775616765223b733a353a226e6c5f4245223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32312031313a33393a3531223b733a31323a22656e676c6973685f6e616d65223b733a31353a224475746368202842656c6769756d29223b733a31313a226e61746976655f6e616d65223b733a32303a224e656465726c616e6473202842656c6769c3ab29223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6e6c5f42452e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226e6c223b693a323b733a333a226e6c64223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a22446f6f726761616e223b7d7d733a353a226e6e5f4e4f223b613a383a7b733a383a226c616e6775616765223b733a353a226e6e5f4e4f223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34303a3537223b733a31323a22656e676c6973685f6e616d65223b733a31393a224e6f7277656769616e20284e796e6f72736b29223b733a31313a226e61746976655f6e616d65223b733a31333a224e6f72736b206e796e6f72736b223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f6e6e5f4e4f2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226e6e223b693a323b733a333a226e6e6f223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a2248616c64206672616d223b7d7d733a333a226f6369223b613a383a7b733a383a226c616e6775616765223b733a333a226f6369223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d30322031333a34373a3338223b733a31323a22656e676c6973685f6e616d65223b733a373a224f63636974616e223b733a31313a226e61746976655f6e616d65223b733a373a224f63636974616e223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f6f63692e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a226f63223b693a323b733a333a226f6369223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74756e686172223b7d7d733a353a2270615f494e223b613a383a7b733a383a226c616e6775616765223b733a353a2270615f494e223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d31362030353a31393a3433223b733a31323a22656e676c6973685f6e616d65223b733a373a2250756e6a616269223b733a31313a226e61746976655f6e616d65223b733a31383a22e0a8aae0a9b0e0a89ce0a8bee0a8ace0a980223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f70615f494e2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227061223b693a323b733a333a2270616e223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32353a22e0a89ce0a8bee0a8b0e0a98020e0a8b0e0a9b1e0a896e0a98b223b7d7d733a353a22706c5f504c223b613a383a7b733a383a226c616e6775616765223b733a353a22706c5f504c223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30372030393a32373a3039223b733a31323a22656e676c6973685f6e616d65223b733a363a22506f6c697368223b733a31313a226e61746976655f6e616d65223b733a363a22506f6c736b69223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f706c5f504c2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22706c223b693a323b733a333a22706f6c223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a224b6f6e74796e75756a223b7d7d733a323a227073223b613a383a7b733a383a226c616e6775616765223b733a323a227073223b733a373a2276657273696f6e223b733a363a22342e312e3136223b733a373a2275706461746564223b733a31393a22323031352d30332d32392032323a31393a3438223b733a31323a22656e676c6973685f6e616d65223b733a363a2250617368746f223b733a31313a226e61746976655f6e616d65223b733a383a22d9beda9ad8aad988223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e312e31362f70732e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227073223b693a323b733a333a22707573223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31393a22d8afd988d8a7d98520d988d8b1daa9da93d987223b7d7d733a353a2270745f4252223b613a383a7b733a383a226c616e6775616765223b733a353a2270745f4252223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d31362030333a35303a3038223b733a31323a22656e676c6973685f6e616d65223b733a31393a22506f727475677565736520284272617a696c29223b733a31313a226e61746976655f6e616d65223b733a32303a22506f7274756775c3aa7320646f2042726173696c223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f70745f42522e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227074223b693a323b733a333a22706f72223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a353a2270745f5054223b613a383a7b733a383a226c616e6775616765223b733a353a2270745f5054223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30372030303a31393a3532223b733a31323a22656e676c6973685f6e616d65223b733a32313a22506f72747567756573652028506f72747567616c29223b733a31313a226e61746976655f6e616d65223b733a31303a22506f7274756775c3aa73223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f70745f50542e7a6970223b733a333a2269736f223b613a313a7b693a313b733a323a227074223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e756172223b7d7d733a333a22726867223b613a383a7b733a383a226c616e6775616765223b733a333a22726867223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30332d31362031333a30333a3138223b733a31323a22656e676c6973685f6e616d65223b733a383a22526f68696e677961223b733a31313a226e61746976655f6e616d65223b733a383a225275c3a1696e6761223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f7268672e7a6970223b733a333a2269736f223b613a313a7b693a333b733a333a22726867223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a303a22223b7d7d733a353a22726f5f524f223b613a383a7b733a383a226c616e6775616765223b733a353a22726f5f524f223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30392030393a31383a3336223b733a31323a22656e676c6973685f6e616d65223b733a383a22526f6d616e69616e223b733a31313a226e61746976655f6e616d65223b733a383a22526f6dc3a26ec483223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f726f5f524f2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22726f223b693a323b733a333a22726f6e223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22436f6e74696e75c483223b7d7d733a353a2272755f5255223b613a383a7b733a383a226c616e6775616765223b733a353a2272755f5255223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d31332031393a34333a3033223b733a31323a22656e676c6973685f6e616d65223b733a373a225275737369616e223b733a31313a226e61746976655f6e616d65223b733a31343a22d0a0d183d181d181d0bad0b8d0b9223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f72755f52552e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227275223b693a323b733a333a22727573223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32303a22d09fd180d0bed0b4d0bed0bbd0b6d0b8d182d18c223b7d7d733a333a22736168223b613a383a7b733a383a226c616e6775616765223b733a333a22736168223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32312030323a30363a3431223b733a31323a22656e676c6973685f6e616d65223b733a353a2253616b6861223b733a31313a226e61746976655f6e616d65223b733a31343a22d0a1d0b0d185d0b0d0bbd18bd18b223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f7361682e7a6970223b733a333a2269736f223b613a323a7b693a323b733a333a22736168223b693a333b733a333a22736168223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31323a22d0a1d0b0d0bbd295d0b0d0b0223b7d7d733a353a2273695f4c4b223b613a383a7b733a383a226c616e6775616765223b733a353a2273695f4c4b223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31312d31322030363a30303a3532223b733a31323a22656e676c6973685f6e616d65223b733a373a2253696e68616c61223b733a31313a226e61746976655f6e616d65223b733a31353a22e0b783e0b792e0b682e0b784e0b6bd223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f73695f4c4b2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227369223b693a323b733a333a2273696e223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a34343a22e0b6afe0b792e0b69ce0b6a7e0b6b820e0b69ae0b6bbe0b69ce0b799e0b6b120e0b6bae0b6b1e0b78ae0b6b1223b7d7d733a353a22736b5f534b223b613a383a7b733a383a226c616e6775616765223b733a353a22736b5f534b223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32342031323a32323a3235223b733a31323a22656e676c6973685f6e616d65223b733a363a22536c6f76616b223b733a31313a226e61746976655f6e616d65223b733a31313a22536c6f76656ec48d696e61223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f736b5f534b2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22736b223b693a323b733a333a22736c6b223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31323a22506f6b7261c48d6f7661c5a5223b7d7d733a353a22736c5f5349223b613a383a7b733a383a226c616e6775616765223b733a353a22736c5f5349223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30322d30382031373a35373a3435223b733a31323a22656e676c6973685f6e616d65223b733a393a22536c6f76656e69616e223b733a31313a226e61746976655f6e616d65223b733a31333a22536c6f76656ec5a1c48d696e61223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f736c5f53492e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22736c223b693a323b733a333a22736c76223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a383a224e6164616c6a756a223b7d7d733a323a227371223b613a383a7b733a383a226c616e6775616765223b733a323a227371223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32392031383a31373a3530223b733a31323a22656e676c6973685f6e616d65223b733a383a22416c62616e69616e223b733a31313a226e61746976655f6e616d65223b733a353a225368716970223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f73712e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227371223b693a323b733a333a22737169223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a2256617a68646f223b7d7d733a353a2273725f5253223b613a383a7b733a383a226c616e6775616765223b733a353a2273725f5253223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34313a3033223b733a31323a22656e676c6973685f6e616d65223b733a373a225365726269616e223b733a31313a226e61746976655f6e616d65223b733a32333a22d0a1d180d0bfd181d0bad0b820d198d0b5d0b7d0b8d0ba223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f73725f52532e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227372223b693a323b733a333a22737270223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31343a22d09dd0b0d181d182d0b0d0b2d0b8223b7d7d733a353a2273765f5345223b613a383a7b733a383a226c616e6775616765223b733a353a2273765f5345223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30332030303a33343a3130223b733a31323a22656e676c6973685f6e616d65223b733a373a2253776564697368223b733a31313a226e61746976655f6e616d65223b733a373a225376656e736b61223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f73765f53452e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227376223b693a323b733a333a22737765223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a393a22466f727473c3a47474223b7d7d733a333a22737a6c223b613a383a7b733a383a226c616e6775616765223b733a333a22737a6c223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30392d32342031393a35383a3134223b733a31323a22656e676c6973685f6e616d65223b733a383a2253696c657369616e223b733a31313a226e61746976655f6e616d65223b733a31373a22c59a6cc58d6e736bc58f2067c58f646b61223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f737a6c2e7a6970223b733a333a2269736f223b613a313a7b693a333b733a333a22737a6c223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31333a224bc58d6e74796e756f7761c487223b7d7d733a353a2274615f494e223b613a383a7b733a383a226c616e6775616765223b733a353a2274615f494e223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32372030333a32323a3437223b733a31323a22656e676c6973685f6e616d65223b733a353a2254616d696c223b733a31313a226e61746976655f6e616d65223b733a31353a22e0aea4e0aeaee0aebfe0aeb4e0af8d223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f74615f494e2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227461223b693a323b733a333a2274616d223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32343a22e0aea4e0af8ae0ae9fe0aeb0e0aeb5e0af81e0aeaee0af8d223b7d7d733a323a227465223b613a383a7b733a383a226c616e6775616765223b733a323a227465223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34373a3339223b733a31323a22656e676c6973685f6e616d65223b733a363a2254656c756775223b733a31313a226e61746976655f6e616d65223b733a31383a22e0b0a4e0b186e0b0b2e0b181e0b097e0b181223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f74652e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227465223b693a323b733a333a2274656c223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a33303a22e0b095e0b18ae0b0a8e0b0b8e0b0bee0b097e0b0bfe0b082e0b09ae0b181223b7d7d733a323a227468223b613a383a7b733a383a226c616e6775616765223b733a323a227468223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a34383a3433223b733a31323a22656e676c6973685f6e616d65223b733a343a2254686169223b733a31313a226e61746976655f6e616d65223b733a393a22e0b984e0b897e0b8a2223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f74682e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227468223b693a323b733a333a22746861223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31353a22e0b895e0b988e0b8ade0b984e0b89b223b7d7d733a323a22746c223b613a383a7b733a383a226c616e6775616765223b733a323a22746c223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31322d33302030323a33383a3038223b733a31323a22656e676c6973685f6e616d65223b733a373a22546167616c6f67223b733a31313a226e61746976655f6e616d65223b733a373a22546167616c6f67223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f746c2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22746c223b693a323b733a333a2274676c223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31303a224d6167706174756c6f79223b7d7d733a353a2274725f5452223b613a383a7b733a383a226c616e6775616765223b733a353a2274725f5452223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30322d31372031313a34363a3532223b733a31323a22656e676c6973685f6e616d65223b733a373a225475726b697368223b733a31313a226e61746976655f6e616d65223b733a383a2254c3bc726bc3a765223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f74725f54522e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227472223b693a323b733a333a22747572223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a353a22446576616d223b7d7d733a353a2274745f5255223b613a383a7b733a383a226c616e6775616765223b733a353a2274745f5255223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31312d32302032303a32303a3530223b733a31323a22656e676c6973685f6e616d65223b733a353a225461746172223b733a31313a226e61746976655f6e616d65223b733a31393a22d0a2d0b0d182d0b0d18020d182d0b5d0bbd0b5223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f74745f52552e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227474223b693a323b733a333a22746174223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31373a22d0b4d399d0b2d0b0d0bc20d0b8d182d2af223b7d7d733a333a22746168223b613a383a7b733a383a226c616e6775616765223b733a333a22746168223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d30332d30362031383a33393a3339223b733a31323a22656e676c6973685f6e616d65223b733a383a22546168697469616e223b733a31313a226e61746976655f6e616d65223b733a31303a2252656f20546168697469223b733a373a227061636b616765223b733a36323a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f7461682e7a6970223b733a333a2269736f223b613a333a7b693a313b733a323a227479223b693a323b733a333a22746168223b693a333b733a333a22746168223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a303a22223b7d7d733a353a2275675f434e223b613a383a7b733a383a226c616e6775616765223b733a353a2275675f434e223b733a373a2276657273696f6e223b733a353a22342e372e32223b733a373a2275706461746564223b733a31393a22323031362d31322d30352030393a32333a3339223b733a31323a22656e676c6973685f6e616d65223b733a363a22556967687572223b733a31313a226e61746976655f6e616d65223b733a393a225579c6a3757271c999223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e322f75675f434e2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227567223b693a323b733a333a22756967223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32363a22d8afd8a7db8bd8a7d985d984d8a7d8b4d8aadb87d8b1db87d8b4223b7d7d733a323a22756b223b613a383a7b733a383a226c616e6775616765223b733a323a22756b223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32382032313a32313a3538223b733a31323a22656e676c6973685f6e616d65223b733a393a22556b7261696e69616e223b733a31313a226e61746976655f6e616d65223b733a32303a22d0a3d0bad180d0b0d197d0bdd181d18cd0bad0b0223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f756b2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22756b223b693a323b733a333a22756b72223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a32303a22d09fd180d0bed0b4d0bed0b2d0b6d0b8d182d0b8223b7d7d733a323a227572223b613a383a7b733a383a226c616e6775616765223b733a323a227572223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32372030373a30383a3037223b733a31323a22656e676c6973685f6e616d65223b733a343a2255726475223b733a31313a226e61746976655f6e616d65223b733a383a22d8a7d8b1d8afd988223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f75722e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227572223b693a323b733a333a22757264223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31393a22d8acd8a7d8b1db8c20d8b1daa9dabedb8cdaba223b7d7d733a353a22757a5f555a223b613a383a7b733a383a226c616e6775616765223b733a353a22757a5f555a223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30342030353a30333a3136223b733a31323a22656e676c6973685f6e616d65223b733a353a22557a62656b223b733a31313a226e61746976655f6e616d65223b733a31313a224fe280987a62656b636861223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f757a5f555a2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a22757a223b693a323b733a333a22757a62223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31313a224461766f6d206574697368223b7d7d733a323a227669223b613a383a7b733a383a226c616e6775616765223b733a323a227669223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30352030393a33363a3030223b733a31323a22656e676c6973685f6e616d65223b733a31303a22566965746e616d657365223b733a31313a226e61746976655f6e616d65223b733a31343a225469e1babf6e67205669e1bb8774223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f76692e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227669223b693a323b733a333a22766965223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a31323a225469e1babf702074e1bba563223b7d7d733a353a227a685f434e223b613a383a7b733a383a226c616e6775616765223b733a353a227a685f434e223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30312d32362031353a35343a3435223b733a31323a22656e676c6973685f6e616d65223b733a31353a224368696e65736520284368696e6129223b733a31313a226e61746976655f6e616d65223b733a31323a22e7ae80e4bd93e4b8ade69687223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f7a685f434e2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227a68223b693a323b733a333a227a686f223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22e7bba7e7bbad223b7d7d733a353a227a685f5457223b613a383a7b733a383a226c616e6775616765223b733a353a227a685f5457223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30342d30382030333a35373a3130223b733a31323a22656e676c6973685f6e616d65223b733a31363a224368696e657365202854616977616e29223b733a31313a226e61746976655f6e616d65223b733a31323a22e7b981e9ab94e4b8ade69687223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f7a685f54572e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227a68223b693a323b733a333a227a686f223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22e7b9bce7ba8c223b7d7d733a353a227a685f484b223b613a383a7b733a383a226c616e6775616765223b733a353a227a685f484b223b733a373a2276657273696f6e223b733a353a22342e372e33223b733a373a2275706461746564223b733a31393a22323031372d30332d32382031323a30333a3330223b733a31323a22656e676c6973685f6e616d65223b733a31393a224368696e6573652028486f6e67204b6f6e6729223b733a31313a226e61746976655f6e616d65223b733a31363a22e9a699e6b8afe4b8ade69687e7898809223b733a373a227061636b616765223b733a36343a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7472616e736c6174696f6e2f636f72652f342e372e332f7a685f484b2e7a6970223b733a333a2269736f223b613a323a7b693a313b733a323a227a68223b693a323b733a333a227a686f223b7d733a373a22737472696e6773223b613a313a7b733a383a22636f6e74696e7565223b733a363a22e7b9bce7ba8c223b7d7d7d, 'no'),
(99, 'widget_pages', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes');
INSERT INTO `wor1677_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES 
(100, 'widget_calendar', 0x613a323a7b693a323b613a313a7b733a353a227469746c65223b733a363a224167656e6461223b7d733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(101, 'widget_tag_cloud', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(102, 'widget_nav_menu', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(103, 'cron', 0x613a393a7b693a313439363330383935393b613a313a7b733a31333a226261636b777075705f63726f6e223b613a313a7b733a33323a223465663534643461646132306361613338343031613035663763636339333131223b613a323a7b733a383a227363686564756c65223b623a303b733a343a2261726773223b613a313a7b733a323a226964223b733a373a2272657374617274223b7d7d7d7d693a313439363330393730323b613a333a7b733a31363a2277705f76657273696f6e5f636865636b223b613a313a7b733a33323a223430636437353062626139383730663138616164613234373862323438343061223b613a333a7b733a383a227363686564756c65223b733a31303a2274776963656461696c79223b733a343a2261726773223b613a303a7b7d733a383a22696e74657276616c223b693a34333230303b7d7d733a31373a2277705f7570646174655f706c7567696e73223b613a313a7b733a33323a223430636437353062626139383730663138616164613234373862323438343061223b613a333a7b733a383a227363686564756c65223b733a31303a2274776963656461696c79223b733a343a2261726773223b613a303a7b7d733a383a22696e74657276616c223b693a34333230303b7d7d733a31363a2277705f7570646174655f7468656d6573223b613a313a7b733a33323a223430636437353062626139383730663138616164613234373862323438343061223b613a333a7b733a383a227363686564756c65223b733a31303a2274776963656461696c79223b733a343a2261726773223b613a303a7b7d733a383a22696e74657276616c223b693a34333230303b7d7d7d693a313439363331323435393b613a313a7b733a32343a2261696f7770735f686f75726c795f63726f6e5f6576656e74223b613a313a7b733a33323a223430636437353062626139383730663138616164613234373862323438343061223b613a333a7b733a383a227363686564756c65223b733a363a22686f75726c79223b733a343a2261726773223b613a303a7b7d733a383a22696e74657276616c223b693a333630303b7d7d7d693a313439363331333731333b613a313a7b733a31393a2277705f7363686564756c65645f64656c657465223b613a313a7b733a33323a223430636437353062626139383730663138616164613234373862323438343061223b613a333a7b733a383a227363686564756c65223b733a353a226461696c79223b733a343a2261726773223b613a303a7b7d733a383a22696e74657276616c223b693a38363430303b7d7d7d693a313439363331353935393b613a313a7b733a33303a2277705f7363686564756c65645f6175746f5f64726166745f64656c657465223b613a313a7b733a33323a223430636437353062626139383730663138616164613234373862323438343061223b613a333a7b733a383a227363686564756c65223b733a353a226461696c79223b733a343a2261726773223b613a303a7b7d733a383a22696e74657276616c223b693a38363430303b7d7d7d693a313439363334383435393b613a313a7b733a32333a2261696f7770735f6461696c795f63726f6e5f6576656e74223b613a313a7b733a33323a223430636437353062626139383730663138616164613234373862323438343061223b613a333a7b733a383a227363686564756c65223b733a353a226461696c79223b733a343a2261726773223b613a303a7b7d733a383a22696e74657276616c223b693a38363430303b7d7d7d693a313439363334383436363b613a313a7b733a32323a226261636b777075705f636865636b5f636c65616e7570223b613a313a7b733a33323a223430636437353062626139383730663138616164613234373862323438343061223b613a333a7b733a383a227363686564756c65223b733a31303a2274776963656461696c79223b733a343a2261726773223b613a303a7b7d733a383a22696e74657276616c223b693a34333230303b7d7d7d693a313439363533383030303b613a313a7b733a31333a226261636b777075705f63726f6e223b613a313a7b733a33323a223266333537303431343765343438396662396238616562333164626162616566223b613a323a7b733a383a227363686564756c65223b623a303b733a343a2261726773223b613a313a7b733a323a226964223b693a313b7d7d7d7d733a373a2276657273696f6e223b693a323b7d, 'yes'),
(397, 'c4p_logging_status', 0x64697361626c6564, 'yes'),
(398, 'c4p_log_email', 0x31, 'yes'),
(399, 'c4p_log_type', 0x333032, 'yes'),
(163, 'theme_mods_twentysixteen', 0x613a323a7b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a323a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313436343235313833333b733a343a2264617461223b613a343a7b733a31393a2277705f696e6163746976655f77696467657473223b613a333a7b693a303b733a31343a22726563656e742d706f7374732d32223b693a313b733a31373a22726563656e742d636f6d6d656e74732d32223b693a323b733a363a226d6574612d32223b7d733a393a22736964656261722d31223b613a343a7b693a303b733a31323a22717472616e736c6174652d32223b693a313b733a383a227365617263682d32223b693a323b733a31303a2261726368697665732d32223b693a333b733a31323a2263617465676f726965732d32223b7d733a393a22736964656261722d32223b613a303a7b7d733a393a22736964656261722d33223b613a303a7b7d7d7d7d, 'yes'),
(165, 'nav_menu_options', 0x613a323a7b693a303b623a303b733a383a226175746f5f616464223b613a303a7b7d7d, 'yes'),
(25747, 'category_children', 0x613a303a7b7d, 'yes'),
(43663, '_site_transient_timeout_theme_roots', 0x31343936333039373831, 'no'),
(43664, '_site_transient_theme_roots', 0x613a31323a7b733a31303a224578706c6f7261626c65223b733a373a222f7468656d6573223b733a31323a226164616d6f732d6368696c64223b733a373a222f7468656d6573223b733a363a226164616d6f73223b733a373a222f7468656d6573223b733a31363a22626c616e6b736c6174652d6368696c64223b733a373a222f7468656d6573223b733a31303a22626c616e6b736c617465223b733a373a222f7468656d6573223b733a31393a22696e74756974696f6e5f70726f2d6368696c64223b733a373a222f7468656d6573223b733a31333a22696e74756974696f6e5f70726f223b733a373a222f7468656d6573223b733a31363a22726573706f6e736976652d6368696c64223b733a373a222f7468656d6573223b733a31303a22726573706f6e73697665223b733a373a222f7468656d6573223b733a31333a227477656e74796669667465656e223b733a373a222f7468656d6573223b733a31393a227477656e74797369787465656e2d6368696c64223b733a373a222f7468656d6573223b733a31333a227477656e74797369787465656e223b733a373a222f7468656d6573223b7d, 'no'),
(29607, '_site_transient_timeout_browser_e57792bac1ff97c50704f6343fd68564', 0x31343930333639343130, 'no'),
(29608, '_site_transient_browser_e57792bac1ff97c50704f6343fd68564', 0x613a393a7b733a383a22706c6174666f726d223b733a373a2257696e646f7773223b733a343a226e616d65223b733a363a224368726f6d65223b733a373a2276657273696f6e223b733a31323a2235372e302e323938372e3938223b733a31303a227570646174655f75726c223b733a32383a22687474703a2f2f7777772e676f6f676c652e636f6d2f6368726f6d65223b733a373a22696d675f737263223b733a34393a22687474703a2f2f732e776f726470726573732e6f72672f696d616765732f62726f77736572732f6368726f6d652e706e67223b733a31313a22696d675f7372635f73736c223b733a34383a2268747470733a2f2f776f726470726573732e6f72672f696d616765732f62726f77736572732f6368726f6d652e706e67223b733a31353a2263757272656e745f76657273696f6e223b733a323a223138223b733a373a2275706772616465223b623a303b733a383a22696e736563757265223b623a303b7d, 'no'),
(2703, 'qtranslate_detect_browser_language', '', 'yes'),
(43684, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', 0x31343936333531343836, 'no'),
(43685, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', 0x31343936333038323836, 'no'),
(43683, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 0x31343936333531343836, 'no'),
(20545, 'fresh_site', '', 'yes'),
(6728, 'et_explorable', 0x613a36393a7b733a31353a226578706c6f7261626c655f6c6f676f223b733a38313a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31302f6c6f676f2d52532e706e67223b733a31383a226578706c6f7261626c655f66617669636f6e223b733a303a22223b733a31393a226578706c6f7261626c655f62675f696d616765223b733a303a22223b733a32313a226578706c6f7261626c655f677261625f696d616765223b733a353a2266616c7365223b733a31393a226578706c6f7261626c655f6d61705f74797065223b733a373a22526f61646d6170223b733a33303a226578706c6f7261626c655f686f6d65706167655f7a6f6f6d5f6c6576656c223b693a333b733a32393a226578706c6f7261626c655f64656661756c745f7a6f6f6d5f6c6576656c223b693a353b733a32333a226578706c6f7261626c655f6361746e756d5f706f737473223b693a363b733a32373a226578706c6f7261626c655f617263686976656e756d5f706f737473223b693a353b733a32363a226578706c6f7261626c655f7365617263686e756d5f706f737473223b693a353b733a32333a226578706c6f7261626c655f7461676e756d5f706f737473223b693a353b733a32323a226578706c6f7261626c655f646174655f666f726d6174223b733a363a224d206a2c2059223b733a32323a226578706c6f7261626c655f7573655f65786365727074223b733a353a2266616c7365223b733a33323a226578706c6f7261626c655f726573706f6e736976655f73686f7274636f646573223b733a323a226f6e223b733a33393a226578706c6f7261626c655f67665f656e61626c655f616c6c5f6368617261637465725f73657473223b733a353a2266616c7365223b733a32313a226578706c6f7261626c655f637573746f6d5f637373223b733a303a22223b733a32373a226578706c6f7261626c655f656e61626c655f64726f70646f776e73223b733a323a226f6e223b733a32303a226578706c6f7261626c655f686f6d655f6c696e6b223b733a323a226f6e223b733a32313a226578706c6f7261626c655f736f72745f7061676573223b733a31303a22706f73745f7469746c65223b733a32313a226578706c6f7261626c655f6f726465725f70616765223b733a333a22617363223b733a32383a226578706c6f7261626c655f74696572735f73686f776e5f7061676573223b693a333b733a33383a226578706c6f7261626c655f656e61626c655f64726f70646f776e735f63617465676f72696573223b733a323a226f6e223b733a32373a226578706c6f7261626c655f63617465676f726965735f656d707479223b733a323a226f6e223b733a33333a226578706c6f7261626c655f74696572735f73686f776e5f63617465676f72696573223b693a333b733a31393a226578706c6f7261626c655f736f72745f636174223b733a343a226e616d65223b733a32303a226578706c6f7261626c655f6f726465725f636174223b733a333a22617363223b733a32363a226578706c6f7261626c655f64697361626c655f746f7074696572223b733a353a2266616c7365223b733a32303a226578706c6f7261626c655f706f7374696e666f32223b613a343a7b693a303b733a363a22617574686f72223b693a313b733a343a2264617465223b693a323b733a31303a2263617465676f72696573223b693a333b733a383a22636f6d6d656e7473223b7d733a32313a226578706c6f7261626c655f7468756d626e61696c73223b733a323a226f6e223b733a32383a226578706c6f7261626c655f73686f775f706f7374636f6d6d656e7473223b733a323a226f6e223b733a32363a226578706c6f7261626c655f706167655f7468756d626e61696c73223b733a353a2266616c7365223b733a32393a226578706c6f7261626c655f73686f775f7061676573636f6d6d656e7473223b733a353a2266616c7365223b733a32303a226578706c6f7261626c655f706f7374696e666f31223b613a343a7b693a303b733a363a22617574686f72223b693a313b733a343a2264617465223b693a323b733a31303a2263617465676f72696573223b693a333b733a383a22636f6d6d656e7473223b7d733a32373a226578706c6f7261626c655f7468756d626e61696c735f696e646578223b733a323a226f6e223b733a33313a226578706c6f7261626c655f73686f775f6176617461725f6f6e5f706f737473223b733a323a226f6e223b733a32353a226578706c6f7261626c655f73656f5f686f6d655f7469746c65223b733a323a226f6e223b733a33313a226578706c6f7261626c655f73656f5f686f6d655f6465736372697074696f6e223b733a323a226f6e223b733a32383a226578706c6f7261626c655f73656f5f686f6d655f6b6579776f726473223b733a353a2266616c7365223b733a32393a226578706c6f7261626c655f73656f5f686f6d655f63616e6f6e6963616c223b733a353a2266616c7365223b733a32393a226578706c6f7261626c655f73656f5f686f6d655f7469746c6574657874223b733a33303a224a616e6520476f6f64616c6c277320796f7574682070726f6772616d6d65223b733a33353a226578706c6f7261626c655f73656f5f686f6d655f6465736372697074696f6e74657874223b733a34303a224a616e6520476f6f64616c6c277320796f7574682070726f6772616d6d6520696e204575726f7065223b733a33323a226578706c6f7261626c655f73656f5f686f6d655f6b6579776f72647374657874223b733a303a22223b733a32343a226578706c6f7261626c655f73656f5f686f6d655f74797065223b733a32373a22426c6f674e616d65207c20426c6f67206465736372697074696f6e223b733a32383a226578706c6f7261626c655f73656f5f686f6d655f7365706172617465223b733a333a22207c20223b733a32373a226578706c6f7261626c655f73656f5f73696e676c655f7469746c65223b733a353a2266616c7365223b733a33333a226578706c6f7261626c655f73656f5f73696e676c655f6465736372697074696f6e223b733a353a2266616c7365223b733a33303a226578706c6f7261626c655f73656f5f73696e676c655f6b6579776f726473223b733a353a2266616c7365223b733a33313a226578706c6f7261626c655f73656f5f73696e676c655f63616e6f6e6963616c223b733a353a2266616c7365223b733a33333a226578706c6f7261626c655f73656f5f73696e676c655f6669656c645f7469746c65223b733a393a2273656f5f7469746c65223b733a33393a226578706c6f7261626c655f73656f5f73696e676c655f6669656c645f6465736372697074696f6e223b733a31353a2273656f5f6465736372697074696f6e223b733a33363a226578706c6f7261626c655f73656f5f73696e676c655f6669656c645f6b6579776f726473223b733a31323a2273656f5f6b6579776f726473223b733a32363a226578706c6f7261626c655f73656f5f73696e676c655f74797065223b733a32313a22506f7374207469746c65207c20426c6f674e616d65223b733a33303a226578706c6f7261626c655f73656f5f73696e676c655f7365706172617465223b733a333a22207c20223b733a33303a226578706c6f7261626c655f73656f5f696e6465785f63616e6f6e6963616c223b733a353a2266616c7365223b733a33323a226578706c6f7261626c655f73656f5f696e6465785f6465736372697074696f6e223b733a353a2266616c7365223b733a32353a226578706c6f7261626c655f73656f5f696e6465785f74797065223b733a32343a2243617465676f7279206e616d65207c20426c6f674e616d65223b733a32393a226578706c6f7261626c655f73656f5f696e6465785f7365706172617465223b733a333a22207c20223b733a33343a226578706c6f7261626c655f696e746567726174655f6865616465725f656e61626c65223b733a323a226f6e223b733a33323a226578706c6f7261626c655f696e746567726174655f626f64795f656e61626c65223b733a323a226f6e223b733a33373a226578706c6f7261626c655f696e746567726174655f73696e676c65746f705f656e61626c65223b733a323a226f6e223b733a34303a226578706c6f7261626c655f696e746567726174655f73696e676c65626f74746f6d5f656e61626c65223b733a323a226f6e223b733a32373a226578706c6f7261626c655f696e746567726174696f6e5f68656164223b733a303a22223b733a32373a226578706c6f7261626c655f696e746567726174696f6e5f626f6479223b733a303a22223b733a33333a226578706c6f7261626c655f696e746567726174696f6e5f73696e676c655f746f70223b733a303a22223b733a33363a226578706c6f7261626c655f696e746567726174696f6e5f73696e676c655f626f74746f6d223b733a303a22223b733a32313a226578706c6f7261626c655f3436385f656e61626c65223b733a353a2266616c7365223b733a32303a226578706c6f7261626c655f3436385f696d616765223b733a303a22223b733a31383a226578706c6f7261626c655f3436385f75726c223b733a303a22223b733a32323a226578706c6f7261626c655f3436385f616473656e7365223b733a303a22223b7d, 'yes'),
(6729, 'et_google_api_settings', 0x613a313a7b733a373a226170695f6b6579223b733a33393a2241497a615379443876705447445339597279637164716a473862703775646f6463544d7434576b223b7d, 'yes'),
(6256, 'rewrite_rules', 0x613a3134303a7b733a31313a225e77702d6a736f6e2f3f24223b733a32323a22696e6465782e7068703f726573745f726f7574653d2f223b733a31343a225e77702d6a736f6e2f282e2a293f223b733a33333a22696e6465782e7068703f726573745f726f7574653d2f246d6174636865735b315d223b733a32313a225e696e6465782e7068702f77702d6a736f6e2f3f24223b733a32323a22696e6465782e7068703f726573745f726f7574653d2f223b733a32343a225e696e6465782e7068702f77702d6a736f6e2f282e2a293f223b733a33333a22696e6465782e7068703f726573745f726f7574653d2f246d6174636865735b315d223b733a34373a2263617465676f72792f282e2b3f292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a35323a22696e6465782e7068703f63617465676f72795f6e616d653d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a34323a2263617465676f72792f282e2b3f292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a35323a22696e6465782e7068703f63617465676f72795f6e616d653d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a32333a2263617465676f72792f282e2b3f292f656d6265642f3f24223b733a34363a22696e6465782e7068703f63617465676f72795f6e616d653d246d6174636865735b315d26656d6265643d74727565223b733a33353a2263617465676f72792f282e2b3f292f706167652f3f285b302d395d7b312c7d292f3f24223b733a35333a22696e6465782e7068703f63617465676f72795f6e616d653d246d6174636865735b315d2670616765643d246d6174636865735b325d223b733a31373a2263617465676f72792f282e2b3f292f3f24223b733a33353a22696e6465782e7068703f63617465676f72795f6e616d653d246d6174636865735b315d223b733a34343a227461672f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34323a22696e6465782e7068703f7461673d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a33393a227461672f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34323a22696e6465782e7068703f7461673d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a32303a227461672f285b5e2f5d2b292f656d6265642f3f24223b733a33363a22696e6465782e7068703f7461673d246d6174636865735b315d26656d6265643d74727565223b733a33323a227461672f285b5e2f5d2b292f706167652f3f285b302d395d7b312c7d292f3f24223b733a34333a22696e6465782e7068703f7461673d246d6174636865735b315d2670616765643d246d6174636865735b325d223b733a31343a227461672f285b5e2f5d2b292f3f24223b733a32353a22696e6465782e7068703f7461673d246d6174636865735b315d223b733a36353a2228656e7c66727c64657c65737c69747c6e6c292f747970652f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a36373a22696e6465782e7068703f6c616e673d246d6174636865735b315d26706f73745f666f726d61743d246d6174636865735b325d26666565643d246d6174636865735b335d223b733a36303a2228656e7c66727c64657c65737c69747c6e6c292f747970652f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a36373a22696e6465782e7068703f6c616e673d246d6174636865735b315d26706f73745f666f726d61743d246d6174636865735b325d26666565643d246d6174636865735b335d223b733a34313a2228656e7c66727c64657c65737c69747c6e6c292f747970652f285b5e2f5d2b292f656d6265642f3f24223b733a36313a22696e6465782e7068703f6c616e673d246d6174636865735b315d26706f73745f666f726d61743d246d6174636865735b325d26656d6265643d74727565223b733a35333a2228656e7c66727c64657c65737c69747c6e6c292f747970652f285b5e2f5d2b292f706167652f3f285b302d395d7b312c7d292f3f24223b733a36383a22696e6465782e7068703f6c616e673d246d6174636865735b315d26706f73745f666f726d61743d246d6174636865735b325d2670616765643d246d6174636865735b335d223b733a33353a2228656e7c66727c64657c65737c69747c6e6c292f747970652f285b5e2f5d2b292f3f24223b733a35303a22696e6465782e7068703f6c616e673d246d6174636865735b315d26706f73745f666f726d61743d246d6174636865735b325d223b733a33383a226163636f7264696f6e732f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f3f24223b733a33323a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d223b733a34383a226163636f7264696f6e732f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2674623d31223b733a36383a226163636f7264696f6e732f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a36333a226163636f7264696f6e732f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a36333a226163636f7264696f6e732f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a34343a226163636f7264696f6e732f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26656d6265643d74727565223b733a32373a226163636f7264696f6e732f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6163636f7264696f6e733d246d6174636865735b315d26656d6265643d74727565223b733a33313a226163636f7264696f6e732f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6163636f7264696f6e733d246d6174636865735b315d2674623d31223b733a33393a226163636f7264696f6e732f285b5e2f5d2b292f706167652f3f285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6163636f7264696f6e733d246d6174636865735b315d2670616765643d246d6174636865735b325d223b733a34363a226163636f7264696f6e732f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6163636f7264696f6e733d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a33353a226163636f7264696f6e732f285b5e2f5d2b29283f3a2f285b302d395d2b29293f2f3f24223b733a34393a22696e6465782e7068703f6163636f7264696f6e733d246d6174636865735b315d26706167653d246d6174636865735b325d223b733a32373a226163636f7264696f6e732f5b5e2f5d2b2f285b5e2f5d2b292f3f24223b733a33323a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d223b733a33373a226163636f7264696f6e732f5b5e2f5d2b2f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2674623d31223b733a35373a226163636f7264696f6e732f5b5e2f5d2b2f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35323a226163636f7264696f6e732f5b5e2f5d2b2f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35323a226163636f7264696f6e732f5b5e2f5d2b2f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a33333a226163636f7264696f6e732f5b5e2f5d2b2f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26656d6265643d74727565223b733a33373a2269665f736c696465722f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f3f24223b733a33323a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d223b733a34373a2269665f736c696465722f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2674623d31223b733a36373a2269665f736c696465722f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a36323a2269665f736c696465722f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a36323a2269665f736c696465722f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a34333a2269665f736c696465722f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26656d6265643d74727565223b733a32363a2269665f736c696465722f285b5e2f5d2b292f656d6265642f3f24223b733a34323a22696e6465782e7068703f69665f736c696465723d246d6174636865735b315d26656d6265643d74727565223b733a33303a2269665f736c696465722f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33363a22696e6465782e7068703f69665f736c696465723d246d6174636865735b315d2674623d31223b733a33383a2269665f736c696465722f285b5e2f5d2b292f706167652f3f285b302d395d7b312c7d292f3f24223b733a34393a22696e6465782e7068703f69665f736c696465723d246d6174636865735b315d2670616765643d246d6174636865735b325d223b733a34353a2269665f736c696465722f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a34393a22696e6465782e7068703f69665f736c696465723d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a33343a2269665f736c696465722f285b5e2f5d2b29283f3a2f285b302d395d2b29293f2f3f24223b733a34383a22696e6465782e7068703f69665f736c696465723d246d6174636865735b315d26706167653d246d6174636865735b325d223b733a32363a2269665f736c696465722f5b5e2f5d2b2f285b5e2f5d2b292f3f24223b733a33323a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d223b733a33363a2269665f736c696465722f5b5e2f5d2b2f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2674623d31223b733a35363a2269665f736c696465722f5b5e2f5d2b2f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35313a2269665f736c696465722f5b5e2f5d2b2f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35313a2269665f736c696465722f5b5e2f5d2b2f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a33323a2269665f736c696465722f5b5e2f5d2b2f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26656d6265643d74727565223b733a34303a22696e667573655f626c6f636b2f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f3f24223b733a33323a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d223b733a35303a22696e667573655f626c6f636b2f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2674623d31223b733a37303a22696e667573655f626c6f636b2f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a36353a22696e667573655f626c6f636b2f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a36353a22696e667573655f626c6f636b2f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a34363a22696e667573655f626c6f636b2f5b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26656d6265643d74727565223b733a32393a22696e667573655f626c6f636b2f285b5e2f5d2b292f656d6265642f3f24223b733a34353a22696e6465782e7068703f696e667573655f626c6f636b3d246d6174636865735b315d26656d6265643d74727565223b733a33333a22696e667573655f626c6f636b2f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33393a22696e6465782e7068703f696e667573655f626c6f636b3d246d6174636865735b315d2674623d31223b733a34313a22696e667573655f626c6f636b2f285b5e2f5d2b292f706167652f3f285b302d395d7b312c7d292f3f24223b733a35323a22696e6465782e7068703f696e667573655f626c6f636b3d246d6174636865735b315d2670616765643d246d6174636865735b325d223b733a34383a22696e667573655f626c6f636b2f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35323a22696e6465782e7068703f696e667573655f626c6f636b3d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a33373a22696e667573655f626c6f636b2f285b5e2f5d2b29283f3a2f285b302d395d2b29293f2f3f24223b733a35313a22696e6465782e7068703f696e667573655f626c6f636b3d246d6174636865735b315d26706167653d246d6174636865735b325d223b733a32393a22696e667573655f626c6f636b2f5b5e2f5d2b2f285b5e2f5d2b292f3f24223b733a33323a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d223b733a33393a22696e667573655f626c6f636b2f5b5e2f5d2b2f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2674623d31223b733a35393a22696e667573655f626c6f636b2f5b5e2f5d2b2f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35343a22696e667573655f626c6f636b2f5b5e2f5d2b2f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35343a22696e667573655f626c6f636b2f5b5e2f5d2b2f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a33353a22696e667573655f626c6f636b2f5b5e2f5d2b2f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26656d6265643d74727565223b733a31323a22726f626f74735c2e74787424223b733a31383a22696e6465782e7068703f726f626f74733d31223b733a34383a222e2a77702d2861746f6d7c7264667c7273737c727373327c666565647c636f6d6d656e747372737332295c2e70687024223b733a31383a22696e6465782e7068703f666565643d6f6c64223b733a32303a222e2a77702d6170705c2e706870282f2e2a293f24223b733a31393a22696e6465782e7068703f6572726f723d343033223b733a31383a222e2a77702d72656769737465722e70687024223b733a32333a22696e6465782e7068703f72656769737465723d74727565223b733a35323a2228656e7c66727c64657c65737c69747c6e6c292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34343a22696e6465782e7068703f6c616e673d246d6174636865735b315d2626666565643d246d6174636865735b325d223b733a34373a2228656e7c66727c64657c65737c69747c6e6c292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34343a22696e6465782e7068703f6c616e673d246d6174636865735b315d2626666565643d246d6174636865735b325d223b733a32383a2228656e7c66727c64657c65737c69747c6e6c292f656d6265642f3f24223b733a33383a22696e6465782e7068703f6c616e673d246d6174636865735b315d2626656d6265643d74727565223b733a34303a2228656e7c66727c64657c65737c69747c6e6c292f706167652f3f285b302d395d7b312c7d292f3f24223b733a34353a22696e6465782e7068703f6c616e673d246d6174636865735b315d262670616765643d246d6174636865735b325d223b733a34373a2228656e7c66727c64657c65737c69747c6e6c292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35363a22696e6465782e7068703f6c616e673d246d6174636865735b315d2626706167655f69643d39392663706167653d246d6174636865735b325d223b733a32323a2228656e7c66727c64657c65737c69747c6e6c292f3f24223b733a32363a22696e6465782e7068703f6c616e673d246d6174636865735b315d223b733a36313a2228656e7c66727c64657c65737c69747c6e6c292f636f6d6d656e74732f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a35393a22696e6465782e7068703f6c616e673d246d6174636865735b315d2626666565643d246d6174636865735b325d2677697468636f6d6d656e74733d31223b733a35363a2228656e7c66727c64657c65737c69747c6e6c292f636f6d6d656e74732f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a35393a22696e6465782e7068703f6c616e673d246d6174636865735b315d2626666565643d246d6174636865735b325d2677697468636f6d6d656e74733d31223b733a33373a2228656e7c66727c64657c65737c69747c6e6c292f636f6d6d656e74732f656d6265642f3f24223b733a33383a22696e6465782e7068703f6c616e673d246d6174636865735b315d2626656d6265643d74727565223b733a36343a2228656e7c66727c64657c65737c69747c6e6c292f7365617263682f282e2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a35373a22696e6465782e7068703f6c616e673d246d6174636865735b315d26733d246d6174636865735b325d26666565643d246d6174636865735b335d223b733a35393a2228656e7c66727c64657c65737c69747c6e6c292f7365617263682f282e2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a35373a22696e6465782e7068703f6c616e673d246d6174636865735b315d26733d246d6174636865735b325d26666565643d246d6174636865735b335d223b733a34303a2228656e7c66727c64657c65737c69747c6e6c292f7365617263682f282e2b292f656d6265642f3f24223b733a35313a22696e6465782e7068703f6c616e673d246d6174636865735b315d26733d246d6174636865735b325d26656d6265643d74727565223b733a35323a2228656e7c66727c64657c65737c69747c6e6c292f7365617263682f282e2b292f706167652f3f285b302d395d7b312c7d292f3f24223b733a35383a22696e6465782e7068703f6c616e673d246d6174636865735b315d26733d246d6174636865735b325d2670616765643d246d6174636865735b335d223b733a33343a2228656e7c66727c64657c65737c69747c6e6c292f7365617263682f282e2b292f3f24223b733a34303a22696e6465782e7068703f6c616e673d246d6174636865735b315d26733d246d6174636865735b325d223b733a36373a2228656e7c66727c64657c65737c69747c6e6c292f617574686f722f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a36373a22696e6465782e7068703f6c616e673d246d6174636865735b315d26617574686f725f6e616d653d246d6174636865735b325d26666565643d246d6174636865735b335d223b733a36323a2228656e7c66727c64657c65737c69747c6e6c292f617574686f722f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a36373a22696e6465782e7068703f6c616e673d246d6174636865735b315d26617574686f725f6e616d653d246d6174636865735b325d26666565643d246d6174636865735b335d223b733a34333a2228656e7c66727c64657c65737c69747c6e6c292f617574686f722f285b5e2f5d2b292f656d6265642f3f24223b733a36313a22696e6465782e7068703f6c616e673d246d6174636865735b315d26617574686f725f6e616d653d246d6174636865735b325d26656d6265643d74727565223b733a35353a2228656e7c66727c64657c65737c69747c6e6c292f617574686f722f285b5e2f5d2b292f706167652f3f285b302d395d7b312c7d292f3f24223b733a36383a22696e6465782e7068703f6c616e673d246d6174636865735b315d26617574686f725f6e616d653d246d6174636865735b325d2670616765643d246d6174636865735b335d223b733a33373a2228656e7c66727c64657c65737c69747c6e6c292f617574686f722f285b5e2f5d2b292f3f24223b733a35303a22696e6465782e7068703f6c616e673d246d6174636865735b315d26617574686f725f6e616d653d246d6174636865735b325d223b733a38393a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f285b302d395d7b312c327d292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a39373a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d266461793d246d6174636865735b345d26666565643d246d6174636865735b355d223b733a38343a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f285b302d395d7b312c327d292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a39373a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d266461793d246d6174636865735b345d26666565643d246d6174636865735b355d223b733a36353a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f285b302d395d7b312c327d292f656d6265642f3f24223b733a39313a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d266461793d246d6174636865735b345d26656d6265643d74727565223b733a37373a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f285b302d395d7b312c327d292f706167652f3f285b302d395d7b312c7d292f3f24223b733a39383a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d266461793d246d6174636865735b345d2670616765643d246d6174636865735b355d223b733a35393a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f285b302d395d7b312c327d292f3f24223b733a38303a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d266461793d246d6174636865735b345d223b733a37363a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a38313a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d26666565643d246d6174636865735b345d223b733a37313a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a38313a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d26666565643d246d6174636865735b345d223b733a35323a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f656d6265642f3f24223b733a37353a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d26656d6265643d74727565223b733a36343a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f706167652f3f285b302d395d7b312c7d292f3f24223b733a38323a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d2670616765643d246d6174636865735b345d223b733a34363a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f285b302d395d7b312c327d292f3f24223b733a36343a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d266d6f6e74686e756d3d246d6174636865735b335d223b733a36333a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a36303a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d26666565643d246d6174636865735b335d223b733a35383a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a36303a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d26666565643d246d6174636865735b335d223b733a33393a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f656d6265642f3f24223b733a35343a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d26656d6265643d74727565223b733a35313a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f706167652f3f285b302d395d7b312c7d292f3f24223b733a36313a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d2670616765643d246d6174636865735b335d223b733a33333a2228656e7c66727c64657c65737c69747c6e6c292f285b302d395d7b347d292f3f24223b733a34333a22696e6465782e7068703f6c616e673d246d6174636865735b315d26796561723d246d6174636865735b325d223b733a32373a222e3f2e2b3f2f6174746163686d656e742f285b5e2f5d2b292f3f24223b733a33323a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d223b733a33373a222e3f2e2b3f2f6174746163686d656e742f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2674623d31223b733a35373a222e3f2e2b3f2f6174746163686d656e742f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35323a222e3f2e2b3f2f6174746163686d656e742f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35323a222e3f2e2b3f2f6174746163686d656e742f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a33333a222e3f2e2b3f2f6174746163686d656e742f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26656d6265643d74727565223b733a31363a22282e3f2e2b3f292f656d6265642f3f24223b733a34313a22696e6465782e7068703f706167656e616d653d246d6174636865735b315d26656d6265643d74727565223b733a32303a22282e3f2e2b3f292f747261636b6261636b2f3f24223b733a33353a22696e6465782e7068703f706167656e616d653d246d6174636865735b315d2674623d31223b733a34303a22282e3f2e2b3f292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34373a22696e6465782e7068703f706167656e616d653d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a33353a22282e3f2e2b3f292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34373a22696e6465782e7068703f706167656e616d653d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a32383a22282e3f2e2b3f292f706167652f3f285b302d395d7b312c7d292f3f24223b733a34383a22696e6465782e7068703f706167656e616d653d246d6174636865735b315d2670616765643d246d6174636865735b325d223b733a33353a22282e3f2e2b3f292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a34383a22696e6465782e7068703f706167656e616d653d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a32343a22282e3f2e2b3f29283f3a2f285b302d395d2b29293f2f3f24223b733a34373a22696e6465782e7068703f706167656e616d653d246d6174636865735b315d26706167653d246d6174636865735b325d223b733a32373a225b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f3f24223b733a33323a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d223b733a33373a225b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2674623d31223b733a35373a225b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35323a225b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a35323a225b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a33333a225b5e2f5d2b2f6174746163686d656e742f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26656d6265643d74727565223b733a31363a22285b5e2f5d2b292f656d6265642f3f24223b733a33373a22696e6465782e7068703f6e616d653d246d6174636865735b315d26656d6265643d74727565223b733a32303a22285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33313a22696e6465782e7068703f6e616d653d246d6174636865735b315d2674623d31223b733a34303a22285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34333a22696e6465782e7068703f6e616d653d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a33353a22285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34333a22696e6465782e7068703f6e616d653d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a32383a22285b5e2f5d2b292f706167652f3f285b302d395d7b312c7d292f3f24223b733a34343a22696e6465782e7068703f6e616d653d246d6174636865735b315d2670616765643d246d6174636865735b325d223b733a33353a22285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a34343a22696e6465782e7068703f6e616d653d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a32343a22285b5e2f5d2b29283f3a2f285b302d395d2b29293f2f3f24223b733a34333a22696e6465782e7068703f6e616d653d246d6174636865735b315d26706167653d246d6174636865735b325d223b733a31363a225b5e2f5d2b2f285b5e2f5d2b292f3f24223b733a33323a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d223b733a32363a225b5e2f5d2b2f285b5e2f5d2b292f747261636b6261636b2f3f24223b733a33373a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2674623d31223b733a34363a225b5e2f5d2b2f285b5e2f5d2b292f666565642f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a34313a225b5e2f5d2b2f285b5e2f5d2b292f28666565647c7264667c7273737c727373327c61746f6d292f3f24223b733a34393a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26666565643d246d6174636865735b325d223b733a34313a225b5e2f5d2b2f285b5e2f5d2b292f636f6d6d656e742d706167652d285b302d395d7b312c7d292f3f24223b733a35303a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d2663706167653d246d6174636865735b325d223b733a32323a225b5e2f5d2b2f285b5e2f5d2b292f656d6265642f3f24223b733a34333a22696e6465782e7068703f6174746163686d656e743d246d6174636865735b315d26656d6265643d74727565223b7d, 'yes'),
(43686, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', 0x31343936333531343838, 'no'),
(43687, '_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', 0x31343936333531343838, 'no'),
(43691, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', 0x31343936333038323931, 'no'),
(43689, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', 0x31343936333531343931, 'no'),
(43690, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', 0x31343936333531343931, 'no'),
(6625, 'theme_mods_twentyfifteen', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a31393a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a393a226d61696e5f6d656e75223b693a323b733a383a22746f705f6d656e75223b693a33363b733a31313a22666f6f7465725f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b733a31343a226d61696e5f6d656e755f5f5f6672223b693a33313b733a31343a226d61696e5f6d656e755f5f5f6465223b693a33333b733a31343a226d61696e5f6d656e755f5f5f6573223b693a33343b733a31343a226d61696e5f6d656e755f5f5f6974223b693a33353b733a31343a226d61696e5f6d656e755f5f5f6e6c223b693a33303b733a31333a22746f705f6d656e755f5f5f6672223b693a33363b733a31333a22746f705f6d656e755f5f5f6465223b693a33363b733a31333a22746f705f6d656e755f5f5f6573223b693a33363b733a31333a22746f705f6d656e755f5f5f6974223b693a33363b733a31333a22746f705f6d656e755f5f5f6e6c223b693a33363b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313437373934373538303b733a343a2264617461223b613a353a7b733a31393a2277705f696e6163746976655f77696467657473223b613a303a7b7d733a393a22736964656261722d31223b613a313a7b693a303b733a31303a2261726368697665732d32223b7d733a31383a226f727068616e65645f776964676574735f31223b613a313a7b693a303b733a363a22746578742d32223b7d733a31383a226f727068616e65645f776964676574735f32223b613a313a7b693a303b733a363a22746578742d33223b7d733a31383a226f727068616e65645f776964676574735f33223b613a313a7b693a303b733a31303a2263616c656e6461722d32223b7d7d7d7d, 'yes'),
(6951, 'wpcf7', 0x613a323a7b733a373a2276657273696f6e223b733a333a22342e38223b733a31333a2262756c6b5f76616c6964617465223b613a343a7b733a393a2274696d657374616d70223b693a313437383237343636373b733a373a2276657273696f6e223b733a353a22342e352e31223b733a31313a22636f756e745f76616c6964223b693a313b733a31333a22636f756e745f696e76616c6964223b693a303b7d7d, 'yes'),
(6722, 'widget_aboutmewidget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(6723, 'widget_adsensewidget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(6724, 'widget_advwidget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(6725, 'et_images_temp_folder', 0x2f686f6d652f726f6f7473616e6476742f7777772f77702d636f6e74656e742f75706c6f6164732f65745f74656d70, 'yes'),
(6726, 'et_schedule_clean_images_last_time', 0x31343737393437353831, 'yes'),
(20529, 'can_compress_scripts', 0x31, 'no'),
(6730, 'et_automatic_updates_options', 0x613a323a7b733a383a22757365726e616d65223b733a31333a22646c616e6f7265646f626c6565223b733a373a226170695f6b6579223b733a34303a2233323339396163326161626664363065366436636462643739666462333661623832613463353863223b7d, 'yes'),
(43708, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', 0x31343936333139333833, 'no'),
(43709, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 0x4f3a383a22737464436c617373223a3130303a7b733a363a22776964676574223b613a333a7b733a343a226e616d65223b733a363a22776964676574223b733a343a22736c7567223b733a363a22776964676574223b733a353a22636f756e74223b693a343334303b7d733a343a22706f7374223b613a333a7b733a343a226e616d65223b733a343a22706f7374223b733a343a22736c7567223b733a343a22706f7374223b733a353a22636f756e74223b693a323437383b7d733a353a2261646d696e223b613a333a7b733a343a226e616d65223b733a353a2261646d696e223b733a343a22736c7567223b733a353a2261646d696e223b733a353a22636f756e74223b693a323335323b7d733a31313a22776f6f636f6d6d65726365223b613a333a7b733a343a226e616d65223b733a31313a22776f6f636f6d6d65726365223b733a343a22736c7567223b733a31313a22776f6f636f6d6d65726365223b733a353a22636f756e74223b693a323039383b7d733a353a22706f737473223b613a333a7b733a343a226e616d65223b733a353a22706f737473223b733a343a22736c7567223b733a353a22706f737473223b733a353a22636f756e74223b693a313832303b7d733a383a22636f6d6d656e7473223b613a333a7b733a343a226e616d65223b733a383a22636f6d6d656e7473223b733a343a22736c7567223b733a383a22636f6d6d656e7473223b733a353a22636f756e74223b693a313537393b7d733a393a2273686f7274636f6465223b613a333a7b733a343a226e616d65223b733a393a2273686f7274636f6465223b733a343a22736c7567223b733a393a2273686f7274636f6465223b733a353a22636f756e74223b693a313535383b7d733a373a2274776974746572223b613a333a7b733a343a226e616d65223b733a373a2274776974746572223b733a343a22736c7567223b733a373a2274776974746572223b733a353a22636f756e74223b693a313432393b7d733a363a22676f6f676c65223b613a333a7b733a343a226e616d65223b733a363a22676f6f676c65223b733a343a22736c7567223b733a363a22676f6f676c65223b733a353a22636f756e74223b693a313333353b7d733a363a22696d61676573223b613a333a7b733a343a226e616d65223b733a363a22696d61676573223b733a343a22736c7567223b733a363a22696d61676573223b733a353a22636f756e74223b693a313332333b7d733a383a2266616365626f6f6b223b613a333a7b733a343a226e616d65223b733a383a2266616365626f6f6b223b733a343a22736c7567223b733a383a2266616365626f6f6b223b733a353a22636f756e74223b693a313331363b7d733a373a2273696465626172223b613a333a7b733a343a226e616d65223b733a373a2273696465626172223b733a343a22736c7567223b733a373a2273696465626172223b733a353a22636f756e74223b693a313236373b7d733a353a22696d616765223b613a333a7b733a343a226e616d65223b733a353a22696d616765223b733a343a22736c7567223b733a353a22696d616765223b733a353a22636f756e74223b693a313236353b7d733a333a2273656f223b613a333a7b733a343a226e616d65223b733a333a2273656f223b733a343a22736c7567223b733a333a2273656f223b733a353a22636f756e74223b693a313130363b7d733a373a2267616c6c657279223b613a333a7b733a343a226e616d65223b733a373a2267616c6c657279223b733a343a22736c7567223b733a373a2267616c6c657279223b733a353a22636f756e74223b693a313034333b7d733a343a2270616765223b613a333a7b733a343a226e616d65223b733a343a2270616765223b733a343a22736c7567223b733a343a2270616765223b733a353a22636f756e74223b693a313033383b7d733a363a22736f6369616c223b613a333a7b733a343a226e616d65223b733a363a22736f6369616c223b733a343a22736c7567223b733a363a22736f6369616c223b733a353a22636f756e74223b693a3938333b7d733a353a22656d61696c223b613a333a7b733a343a226e616d65223b733a353a22656d61696c223b733a343a22736c7567223b733a353a22656d61696c223b733a353a22636f756e74223b693a3932363b7d733a353a226c696e6b73223b613a333a7b733a343a226e616d65223b733a353a226c696e6b73223b733a343a22736c7567223b733a353a226c696e6b73223b733a353a22636f756e74223b693a3831323b7d733a393a2265636f6d6d65726365223b613a333a7b733a343a226e616d65223b733a393a2265636f6d6d65726365223b733a343a22736c7567223b733a393a2265636f6d6d65726365223b733a353a22636f756e74223b693a3739303b7d733a353a226c6f67696e223b613a333a7b733a343a226e616d65223b733a353a226c6f67696e223b733a343a22736c7567223b733a353a226c6f67696e223b733a353a22636f756e74223b693a3738353b7d733a373a2277696467657473223b613a333a7b733a343a226e616d65223b733a373a2277696467657473223b733a343a22736c7567223b733a373a2277696467657473223b733a353a22636f756e74223b693a3736323b7d733a353a22766964656f223b613a333a7b733a343a226e616d65223b733a353a22766964656f223b733a343a22736c7567223b733a353a22766964656f223b733a353a22636f756e74223b693a3736303b7d733a333a22727373223b613a333a7b733a343a226e616d65223b733a333a22727373223b733a343a22736c7567223b733a333a22727373223b733a353a22636f756e74223b693a3636353b7d733a373a22636f6e74656e74223b613a333a7b733a343a226e616d65223b733a373a22636f6e74656e74223b733a343a22736c7567223b733a373a22636f6e74656e74223b733a353a22636f756e74223b693a3635373b7d733a31303a2262756464797072657373223b613a333a7b733a343a226e616d65223b733a31303a2262756464797072657373223b733a343a22736c7567223b733a31303a2262756464797072657373223b733a353a22636f756e74223b693a3635323b7d733a343a227370616d223b613a333a7b733a343a226e616d65223b733a343a227370616d223b733a343a22736c7567223b733a343a227370616d223b733a353a22636f756e74223b693a3634353b7d733a353a227061676573223b613a333a7b733a343a226e616d65223b733a353a227061676573223b733a343a22736c7567223b733a353a227061676573223b733a353a22636f756e74223b693a3634333b7d733a363a226a7175657279223b613a333a7b733a343a226e616d65223b733a363a226a7175657279223b733a343a22736c7567223b733a363a226a7175657279223b733a353a22636f756e74223b693a3633343b7d733a383a227365637572697479223b613a333a7b733a343a226e616d65223b733a383a227365637572697479223b733a343a22736c7567223b733a383a227365637572697479223b733a353a22636f756e74223b693a3632323b7d733a363a22736c69646572223b613a333a7b733a343a226e616d65223b733a363a22736c69646572223b733a343a22736c7567223b733a363a22736c69646572223b733a353a22636f756e74223b693a3630313b7d733a353a226d65646961223b613a333a7b733a343a226e616d65223b733a353a226d65646961223b733a343a22736c7567223b733a353a226d65646961223b733a353a22636f756e74223b693a3538393b7d733a343a22616a6178223b613a333a7b733a343a226e616d65223b733a343a22616a6178223b733a343a22736c7567223b733a343a22616a6178223b733a353a22636f756e74223b693a3538393b7d733a343a2266656564223b613a333a7b733a343a226e616d65223b733a343a2266656564223b733a343a22736c7567223b733a343a2266656564223b733a353a22636f756e74223b693a3537353b7d733a393a22616e616c7974696373223b613a333a7b733a343a226e616d65223b733a393a22616e616c7974696373223b733a343a22736c7567223b733a393a22616e616c7974696373223b733a353a22636f756e74223b693a3537343b7d733a383a2263617465676f7279223b613a333a7b733a343a226e616d65223b733a383a2263617465676f7279223b733a343a22736c7567223b733a383a2263617465676f7279223b733a353a22636f756e74223b693a3537323b7d733a363a22736561726368223b613a333a7b733a343a226e616d65223b733a363a22736561726368223b733a343a22736c7567223b733a363a22736561726368223b733a353a22636f756e74223b693a3536363b7d733a31303a22652d636f6d6d65726365223b613a333a7b733a343a226e616d65223b733a31303a22652d636f6d6d65726365223b733a343a22736c7567223b733a31303a22652d636f6d6d65726365223b733a353a22636f756e74223b693a3535343b7d733a343a226d656e75223b613a333a7b733a343a226e616d65223b733a343a226d656e75223b733a343a22736c7567223b733a343a226d656e75223b733a353a22636f756e74223b693a3535313b7d733a353a22656d626564223b613a333a7b733a343a226e616d65223b733a353a22656d626564223b733a343a22736c7567223b733a353a22656d626564223b733a353a22636f756e74223b693a3533383b7d733a31303a226a617661736372697074223b613a333a7b733a343a226e616d65223b733a31303a226a617661736372697074223b733a343a22736c7567223b733a31303a226a617661736372697074223b733a353a22636f756e74223b693a3533303b7d733a343a22666f726d223b613a333a7b733a343a226e616d65223b733a343a22666f726d223b733a343a22736c7567223b733a343a22666f726d223b733a353a22636f756e74223b693a3532333b7d733a343a226c696e6b223b613a333a7b733a343a226e616d65223b733a343a226c696e6b223b733a343a22736c7567223b733a343a226c696e6b223b733a353a22636f756e74223b693a3531383b7d733a333a22637373223b613a333a7b733a343a226e616d65223b733a333a22637373223b733a343a22736c7567223b733a333a22637373223b733a353a22636f756e74223b693a3530333b7d733a353a227368617265223b613a333a7b733a343a226e616d65223b733a353a227368617265223b733a343a22736c7567223b733a353a227368617265223b733a353a22636f756e74223b693a3439373b7d733a373a22796f7574756265223b613a333a7b733a343a226e616d65223b733a373a22796f7574756265223b733a343a22736c7567223b733a373a22796f7574756265223b733a353a22636f756e74223b693a3438393b7d733a373a22636f6d6d656e74223b613a333a7b733a343a226e616d65223b733a373a22636f6d6d656e74223b733a343a22736c7567223b733a373a22636f6d6d656e74223b733a353a22636f756e74223b693a3438383b7d733a353a227468656d65223b613a333a7b733a343a226e616d65223b733a353a227468656d65223b733a343a22736c7567223b733a353a227468656d65223b733a353a22636f756e74223b693a3437363b7d733a31303a22726573706f6e73697665223b613a333a7b733a343a226e616d65223b733a31303a22726573706f6e73697665223b733a343a22736c7567223b733a31303a22726573706f6e73697665223b733a353a22636f756e74223b693a3436363b7d733a363a22637573746f6d223b613a333a7b733a343a226e616d65223b733a363a22637573746f6d223b733a343a22736c7567223b733a363a22637573746f6d223b733a353a22636f756e74223b693a3436343b7d733a31303a2263617465676f72696573223b613a333a7b733a343a226e616d65223b733a31303a2263617465676f72696573223b733a343a22736c7567223b733a31303a2263617465676f72696573223b733a353a22636f756e74223b693a3436323b7d733a393a2264617368626f617264223b613a333a7b733a343a226e616d65223b733a393a2264617368626f617264223b733a343a22736c7567223b733a393a2264617368626f617264223b733a353a22636f756e74223b693a3435393b7d733a333a22616473223b613a333a7b733a343a226e616d65223b733a333a22616473223b733a343a22736c7567223b733a333a22616473223b733a353a22636f756e74223b693a3434303b7d733a343a2274616773223b613a333a7b733a343a226e616d65223b733a343a2274616773223b733a343a22736c7567223b733a343a2274616773223b733a353a22636f756e74223b693a3433343b7d733a363a22627574746f6e223b613a333a7b733a343a226e616d65223b733a363a22627574746f6e223b733a343a22736c7567223b733a363a22627574746f6e223b733a353a22636f756e74223b693a3433333b7d733a393a22616666696c69617465223b613a333a7b733a343a226e616d65223b733a393a22616666696c69617465223b733a343a22736c7567223b733a393a22616666696c69617465223b733a353a22636f756e74223b693a3433313b7d733a363a22656469746f72223b613a333a7b733a343a226e616d65223b733a363a22656469746f72223b733a343a22736c7567223b733a363a22656469746f72223b733a353a22636f756e74223b693a3432373b7d733a353a2270686f746f223b613a333a7b733a343a226e616d65223b733a353a2270686f746f223b733a343a22736c7567223b733a353a2270686f746f223b733a353a22636f756e74223b693a3432303b7d733a31323a22636f6e746163742d666f726d223b613a333a7b733a343a226e616d65223b733a31323a22636f6e7461637420666f726d223b733a343a22736c7567223b733a31323a22636f6e746163742d666f726d223b733a353a22636f756e74223b693a3431323b7d733a343a2275736572223b613a333a7b733a343a226e616d65223b733a343a2275736572223b733a343a22736c7567223b733a343a2275736572223b733a353a22636f756e74223b693a3430393b7d733a393a22736c69646573686f77223b613a333a7b733a343a226e616d65223b733a393a22736c69646573686f77223b733a343a22736c7567223b733a393a22736c69646573686f77223b733a353a22636f756e74223b693a3430363b7d733a363a226d6f62696c65223b613a333a7b733a343a226e616d65223b733a363a226d6f62696c65223b733a343a22736c7567223b733a363a226d6f62696c65223b733a353a22636f756e74223b693a3430313b7d733a353a227374617473223b613a333a7b733a343a226e616d65223b733a353a227374617473223b733a343a22736c7567223b733a353a227374617473223b733a353a22636f756e74223b693a3339393b7d733a373a22636f6e74616374223b613a333a7b733a343a226e616d65223b733a373a22636f6e74616374223b733a343a22736c7567223b733a373a22636f6e74616374223b733a353a22636f756e74223b693a3339363b7d733a353a227573657273223b613a333a7b733a343a226e616d65223b733a353a227573657273223b733a343a22736c7567223b733a353a227573657273223b733a353a22636f756e74223b693a3339353b7d733a363a2270686f746f73223b613a333a7b733a343a226e616d65223b733a363a2270686f746f73223b733a343a22736c7567223b733a363a2270686f746f73223b733a353a22636f756e74223b693a3339343b7d733a31303a2273746174697374696373223b613a333a7b733a343a226e616d65223b733a31303a2273746174697374696373223b733a343a22736c7567223b733a31303a2273746174697374696373223b733a353a22636f756e74223b693a3337363b7d733a333a22617069223b613a333a7b733a343a226e616d65223b733a333a22617069223b733a343a22736c7567223b733a333a22617069223b733a353a22636f756e74223b693a3337353b7d733a31303a226e617669676174696f6e223b613a333a7b733a343a226e616d65223b733a31303a226e617669676174696f6e223b733a343a22736c7567223b733a31303a226e617669676174696f6e223b733a353a22636f756e74223b693a3336353b7d733a363a226576656e7473223b613a333a7b733a343a226e616d65223b733a363a226576656e7473223b733a343a22736c7567223b733a363a226576656e7473223b733a353a22636f756e74223b693a3336333b7d733a343a226e657773223b613a333a7b733a343a226e616d65223b733a343a226e657773223b733a343a22736c7567223b733a343a226e657773223b733a353a22636f756e74223b693a3335303b7d733a383a2263616c656e646172223b613a333a7b733a343a226e616d65223b733a383a2263616c656e646172223b733a343a22736c7567223b733a383a2263616c656e646172223b733a353a22636f756e74223b693a3333333b7d733a31323a22736f6369616c2d6d65646961223b613a333a7b733a343a226e616d65223b733a31323a22736f6369616c206d65646961223b733a343a22736c7567223b733a31323a22736f6369616c2d6d65646961223b733a353a22636f756e74223b693a3333323b7d733a373a22706c7567696e73223b613a333a7b733a343a226e616d65223b733a373a22706c7567696e73223b733a343a22736c7567223b733a373a22706c7567696e73223b733a353a22636f756e74223b693a3333313b7d733a393a226d756c746973697465223b613a333a7b733a343a226e616d65223b733a393a226d756c746973697465223b733a343a22736c7567223b733a393a226d756c746973697465223b733a353a22636f756e74223b693a3332393b7d733a31303a2273686f7274636f646573223b613a333a7b733a343a226e616d65223b733a31303a2273686f7274636f646573223b733a343a22736c7567223b733a31303a2273686f7274636f646573223b733a353a22636f756e74223b693a3332333b7d733a343a22636f6465223b613a333a7b733a343a226e616d65223b733a343a22636f6465223b733a343a22736c7567223b733a343a22636f6465223b733a353a22636f756e74223b693a3332313b7d733a343a226d657461223b613a333a7b733a343a226e616d65223b733a343a226d657461223b733a343a22736c7567223b733a343a226d657461223b733a353a22636f756e74223b693a3331393b7d733a343a226c697374223b613a333a7b733a343a226e616d65223b733a343a226c697374223b733a343a22736c7567223b733a343a226c697374223b733a353a22636f756e74223b693a3331373b7d733a373a227061796d656e74223b613a333a7b733a343a226e616d65223b733a373a227061796d656e74223b733a343a22736c7567223b733a373a227061796d656e74223b733a353a22636f756e74223b693a3331373b7d733a333a2275726c223b613a333a7b733a343a226e616d65223b733a333a2275726c223b733a343a22736c7567223b733a333a2275726c223b733a353a22636f756e74223b693a3331343b7d733a31303a226e6577736c6574746572223b613a333a7b733a343a226e616d65223b733a31303a226e6577736c6574746572223b733a343a22736c7567223b733a31303a226e6577736c6574746572223b733a353a22636f756e74223b693a3331333b7d733a393a226d61726b6574696e67223b613a333a7b733a343a226e616d65223b733a393a226d61726b6574696e67223b733a343a22736c7567223b733a393a226d61726b6574696e67223b733a353a22636f756e74223b693a3239363b7d733a353a22706f707570223b613a333a7b733a343a226e616d65223b733a353a22706f707570223b733a343a22736c7567223b733a353a22706f707570223b733a353a22636f756e74223b693a3239343b7d733a363a2273696d706c65223b613a333a7b733a343a226e616d65223b733a363a2273696d706c65223b733a343a22736c7567223b733a363a2273696d706c65223b733a353a22636f756e74223b693a3239333b7d733a333a22746167223b613a333a7b733a343a226e616d65223b733a333a22746167223b733a343a22736c7567223b733a333a22746167223b733a353a22636f756e74223b693a3239323b7d733a31363a22637573746f6d2d706f73742d74797065223b613a333a7b733a343a226e616d65223b733a31363a22637573746f6d20706f73742074797065223b733a343a22736c7567223b733a31363a22637573746f6d2d706f73742d74797065223b733a353a22636f756e74223b693a3238373b7d733a343a2263686174223b613a333a7b733a343a226e616d65223b733a343a2263686174223b733a343a22736c7567223b733a343a2263686174223b733a353a22636f756e74223b693a3238353b7d733a383a227265646972656374223b613a333a7b733a343a226e616d65223b733a383a227265646972656374223b733a343a22736c7567223b733a383a227265646972656374223b733a353a22636f756e74223b693a3238353b7d733a31313a226164766572746973696e67223b613a333a7b733a343a226e616d65223b733a31313a226164766572746973696e67223b733a343a22736c7567223b733a31313a226164766572746973696e67223b733a353a22636f756e74223b693a3238303b7d733a363a22617574686f72223b613a333a7b733a343a226e616d65223b733a363a22617574686f72223b733a343a22736c7567223b733a363a22617574686f72223b733a353a22636f756e74223b693a3237393b7d733a373a22616473656e7365223b613a333a7b733a343a226e616d65223b733a373a22616473656e7365223b733a343a22736c7567223b733a373a22616473656e7365223b733a353a22636f756e74223b693a3237373b7d733a343a2268746d6c223b613a333a7b733a343a226e616d65223b733a343a2268746d6c223b733a343a22736c7567223b733a343a2268746d6c223b733a353a22636f756e74223b693a3237343b7d733a383a226c69676874626f78223b613a333a7b733a343a226e616d65223b733a383a226c69676874626f78223b733a343a22736c7567223b733a383a226c69676874626f78223b733a353a22636f756e74223b693a3237333b7d733a353a22666f726d73223b613a333a7b733a343a226e616d65223b733a353a22666f726d73223b733a343a22736c7567223b733a353a22666f726d73223b733a353a22636f756e74223b693a3236383b7d733a31353a227061796d656e742d67617465776179223b613a333a7b733a343a226e616d65223b733a31353a227061796d656e742067617465776179223b733a343a22736c7567223b733a31353a227061796d656e742d67617465776179223b733a353a22636f756e74223b693a3236373b7d733a31343a2261646d696e697374726174696f6e223b613a333a7b733a343a226e616d65223b733a31343a2261646d696e697374726174696f6e223b733a343a22736c7567223b733a31343a2261646d696e697374726174696f6e223b733a353a22636f756e74223b693a3236333b7d733a373a2263617074636861223b613a333a7b733a343a226e616d65223b733a373a2263617074636861223b733a343a22736c7567223b733a373a2263617074636861223b733a353a22636f756e74223b693a3236323b7d733a31323a226e6f74696669636174696f6e223b613a333a7b733a343a226e616d65223b733a31323a226e6f74696669636174696f6e223b733a343a22736c7567223b733a31323a226e6f74696669636174696f6e223b733a353a22636f756e74223b693a3236323b7d733a353a226361636865223b613a333a7b733a343a226e616d65223b733a353a226361636865223b733a343a22736c7567223b733a353a226361636865223b733a353a22636f756e74223b693a3236303b7d7d, 'no'),
(43692, '_transient_timeout_plugin_slugs', 0x31343936333935313133, 'no');
INSERT INTO `wor1677_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES 
(43693, '_transient_plugin_slugs', 0x613a31333a7b693a303b733a32353a226163636f7264696f6e732f6163636f7264696f6e732e706870223b693a313b733a35313a22616c6c2d696e2d6f6e652d77702d73656375726974792d616e642d6669726577616c6c2f77702d73656375726974792e706870223b693a323b733a32313a226261636b777075702f6261636b777075702e706870223b693a333b733a33363a22636f6e746163742d666f726d2d372f77702d636f6e746163742d666f726d2d372e706870223b693a343b733a33333a22637573746f6d2d3430342d70726f2f637573746f6d2d3430342d70726f2e706870223b693a353b733a33343a2269666561747572652d736c696465722f6966656174757265736c696465722e706870223b693a363b733a31373a22696e667573652f696e667573652e706870223b693a373b733a33333a226e61762d6d656e752d726f6c65732f6e61762d6d656e752d726f6c65732e706870223b693a383b733a32313a22706f6c796c616e672f706f6c796c616e672e706870223b693a393b733a33303a22726f6f7473616e6473686f6f74732f696e666f5f706c7567696e2e706870223b693a31303b733a34393a227365727665722d69702d6d656d6f72792d75736167652f7365727665722d69702d6d656d6f72792d75736167652e706870223b693a31313b733a32373a227376672d737570706f72742f7376672d737570706f72742e706870223b693a31323b733a34313a22776f726470726573732d696d706f727465722f776f726470726573732d696d706f727465722e706870223b7d, 'no'),
(2721, 'polylang_wpml_strings', 0x613a303a7b7d, 'yes'),
(2720, 'polylang', 0x613a31353a7b733a373a2262726f77736572223b623a313b733a373a2272657772697465223b693a313b733a31323a22686964655f64656661756c74223b693a303b733a31303a22666f7263655f6c616e67223b693a303b733a31333a2272656469726563745f6c616e67223b693a313b733a31333a226d656469615f737570706f7274223b623a313b733a393a22756e696e7374616c6c223b693a313b733a343a2273796e63223b613a303a7b7d733a31303a22706f73745f7479706573223b613a313a7b693a303b733a393a2269665f736c69646572223b7d733a31303a227461786f6e6f6d696573223b613a303a7b7d733a373a22646f6d61696e73223b613a303a7b7d733a373a2276657273696f6e223b733a353a22322e312e35223b733a31323a2264656661756c745f6c616e67223b733a323a22656e223b733a31363a2270726576696f75735f76657273696f6e223b733a353a22322e312e33223b733a393a226e61765f6d656e7573223b613a333a7b733a31323a226164616d6f732d6368696c64223b613a31303a7b733a363a22736f6369616c223b613a313a7b733a323a22656e223b693a303b7d733a31353a226d61696e5f6e617669676174696f6e223b613a313a7b733a323a22656e223b693a323b7d733a31323a226f7665726c61795f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a31313a226d6f62696c655f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a31323a22746f705f6261725f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a31313a22666f6f7465725f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a383a22746f705f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a393a226d61696e5f6d656e75223b613a313a7b733a323a22656e223b693a323b7d733a373a227072696d617279223b613a363a7b733a323a22656e223b693a323b733a323a226672223b693a33313b733a323a226465223b693a33333b733a323a226573223b693a33343b733a323a226974223b693a33353b733a323a226e6c223b693a33303b7d733a393a227365636f6e64617279223b613a363a7b733a323a22656e223b693a33363b733a323a226672223b693a33363b733a323a226465223b693a33363b733a323a226573223b693a33363b733a323a226974223b693a33363b733a323a226e6c223b693a33363b7d7d733a31393a22696e74756974696f6e5f70726f2d6368696c64223b613a393a7b733a373a227072696d617279223b613a313a7b733a323a22656e223b693a303b7d733a363a22736f6369616c223b613a313a7b733a323a22656e223b693a303b7d733a31353a226d61696e5f6e617669676174696f6e223b613a313a7b733a323a22656e223b693a323b7d733a31323a226f7665726c61795f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a31323a22746f705f6261725f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a393a226d61696e5f6d656e75223b613a363a7b733a323a22656e223b693a323b733a323a226672223b693a33313b733a323a226465223b693a33333b733a323a226573223b693a33343b733a323a226974223b693a33353b733a323a226e6c223b693a33303b7d733a383a22746f705f6d656e75223b613a363a7b733a323a22656e223b693a33363b733a323a226672223b693a33363b733a323a226465223b693a33363b733a323a226573223b693a33363b733a323a226974223b693a33363b733a323a226e6c223b693a33363b7d733a31313a22666f6f7465725f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a31313a226d6f62696c655f6d656e75223b613a313a7b733a323a22656e223b693a303b7d7d733a31303a224578706c6f7261626c65223b613a31303a7b733a373a227072696d617279223b613a313a7b733a323a22656e223b693a303b7d733a363a22736f6369616c223b613a313a7b733a323a22656e223b693a303b7d733a31353a226d61696e5f6e617669676174696f6e223b613a313a7b733a323a22656e223b693a323b7d733a31323a226f7665726c61795f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a31323a22746f705f6261725f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a393a226d61696e5f6d656e75223b613a363a7b733a323a22656e223b693a323b733a323a226672223b693a33313b733a323a226465223b693a33333b733a323a226573223b693a33343b733a323a226974223b693a33353b733a323a226e6c223b693a33303b7d733a383a22746f705f6d656e75223b613a363a7b733a323a22656e223b693a33363b733a323a226672223b693a33363b733a323a226465223b693a33363b733a323a226573223b693a33363b733a323a226974223b693a33363b733a323a226e6c223b693a33363b7d733a31313a22666f6f7465725f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a31313a226d6f62696c655f6d656e75223b613a313a7b733a323a22656e223b693a303b7d733a31323a227072696d6172792d6d656e75223b613a363a7b733a323a22656e223b693a323b733a323a226672223b693a33313b733a323a226465223b693a33333b733a323a226573223b693a33343b733a323a226974223b693a33353b733a323a226e6c223b693a33303b7d7d7d7d, 'yes'),
(138, 'recently_activated', 0x613a303a7b7d, 'yes'),
(3022, 'nav_menu_roles_db_version', 0x312e382e36, 'yes'),
(6150, 'revision-control', 0x613a323a7b733a383a227065722d74797065223b613a333a7b733a343a22706f7374223b733a313a2233223b733a343a2270616765223b733a313a2233223b733a333a22616c6c223b733a393a22756e6c696d69746564223b7d733a31343a227265766973696f6e2d72616e6765223b733a31373a22322e2e352c31302c32302c35302c313030223b7d, 'yes'),
(147, 'WPLANG', 0x656e5f4742, 'yes'),
(295, 'qtranslate_date_formats', 0x613a353a7b733a323a226573223b733a31383a222564205c645c65202542205c645c65202559223b733a323a226974223b733a383a222565202542202559223b733a323a226465223b733a32303a2225412c205c645c655c722025652e202542202559223b733a323a226672223b733a31313a222541202565202542202559223b733a323a22656e223b733a31343a22254120254220256525712c202559223b7d, 'yes'),
(204, 'aiowpsec_db_version', 0x312e39, 'yes'),
(205, 'aio_wp_security_configs', 0x613a38333a7b733a31393a2261696f7770735f656e61626c655f6465627567223b733a303a22223b733a33363a2261696f7770735f72656d6f76655f77705f67656e657261746f725f6d6574615f696e666f223b733a313a2231223b733a32353a2261696f7770735f70726576656e745f686f746c696e6b696e67223b733a313a2231223b733a32383a2261696f7770735f656e61626c655f6c6f67696e5f6c6f636b646f776e223b733a313a2231223b733a32383a2261696f7770735f616c6c6f775f756e6c6f636b5f7265717565737473223b733a303a22223b733a32353a2261696f7770735f6d61785f6c6f67696e5f617474656d707473223b693a353b733a32343a2261696f7770735f72657472795f74696d655f706572696f64223b693a353b733a32363a2261696f7770735f6c6f636b6f75745f74696d655f6c656e677468223b693a36303b733a32383a2261696f7770735f7365745f67656e657269635f6c6f67696e5f6d7367223b733a303a22223b733a32363a2261696f7770735f656e61626c655f656d61696c5f6e6f74696679223b733a303a22223b733a32303a2261696f7770735f656d61696c5f61646472657373223b733a31383a22696374406a616e65676f6f64616c6c2e6265223b733a32373a2261696f7770735f656e61626c655f666f726365645f6c6f676f7574223b733a313a2231223b733a32353a2261696f7770735f6c6f676f75745f74696d655f706572696f64223b693a36303b733a33393a2261696f7770735f656e61626c655f696e76616c69645f757365726e616d655f6c6f636b646f776e223b733a313a2231223b733a33323a2261696f7770735f756e6c6f636b5f726571756573745f7365637265745f6b6579223b733a32303a2276613232706d67637734757a31723739716e3937223b733a32363a2261696f7770735f656e61626c655f77686974656c697374696e67223b733a303a22223b733a32373a2261696f7770735f616c6c6f7765645f69705f616464726573736573223b733a303a22223b733a32373a2261696f7770735f656e61626c655f6c6f67696e5f63617074636861223b733a313a2231223b733a33343a2261696f7770735f656e61626c655f637573746f6d5f6c6f67696e5f63617074636861223b733a303a22223b733a32353a2261696f7770735f636170746368615f7365637265745f6b6579223b733a32303a2239706363776a31387a65336f363339617172386e223b733a34323a2261696f7770735f656e61626c655f6d616e75616c5f726567697374726174696f6e5f617070726f76616c223b733a313a2231223b733a33393a2261696f7770735f656e61626c655f726567697374726174696f6e5f706167655f63617074636861223b733a303a22223b733a32373a2261696f7770735f656e61626c655f72616e646f6d5f707265666978223b733a303a22223b733a33313a2261696f7770735f656e61626c655f6175746f6d617465645f6261636b757073223b733a303a22223b733a32363a2261696f7770735f64625f6261636b75705f6672657175656e6379223b733a313a2234223b733a32353a2261696f7770735f64625f6261636b75705f696e74657276616c223b733a313a2232223b733a32363a2261696f7770735f6261636b75705f66696c65735f73746f726564223b733a313a2232223b733a33323a2261696f7770735f73656e645f6261636b75705f656d61696c5f61646472657373223b733a303a22223b733a32373a2261696f7770735f6261636b75705f656d61696c5f61646472657373223b733a31383a22696374406a616e65676f6f64616c6c2e6265223b733a32373a2261696f7770735f64697361626c655f66696c655f65646974696e67223b733a303a22223b733a33373a2261696f7770735f70726576656e745f64656661756c745f77705f66696c655f616363657373223b733a313a2231223b733a32323a2261696f7770735f73797374656d5f6c6f675f66696c65223b733a393a226572726f725f6c6f67223b733a32363a2261696f7770735f656e61626c655f626c61636b6c697374696e67223b733a313a2231223b733a32363a2261696f7770735f62616e6e65645f69705f616464726573736573223b733a3130353a223132302e32372e33352e31310a3137382e3231302e34332e2a0a3138352e38352e3233392e2a0a3138382e3136332e3130372e2a0a3139332e3230312e3232352e2a0a33372e3131352e3231342e2a0a39312e3231302e3134342e2a0a39312e3231302e3134372e2a223b733a32383a2261696f7770735f656e61626c655f62617369635f6669726577616c6c223b733a313a2231223b733a33313a2261696f7770735f656e61626c655f70696e676261636b5f6669726577616c6c223b733a313a2231223b733a33343a2261696f7770735f626c6f636b5f64656275675f6c6f675f66696c655f616363657373223b733a313a2231223b733a32363a2261696f7770735f64697361626c655f696e6465785f7669657773223b733a303a22223b733a33303a2261696f7770735f64697361626c655f74726163655f616e645f747261636b223b733a303a22223b733a32383a2261696f7770735f666f726269645f70726f78795f636f6d6d656e7473223b733a303a22223b733a32393a2261696f7770735f64656e795f6261645f71756572795f737472696e6773223b733a303a22223b733a33343a2261696f7770735f616476616e6365645f636861725f737472696e675f66696c746572223b733a303a22223b733a32353a2261696f7770735f656e61626c655f35675f6669726577616c6c223b733a303a22223b733a32353a2261696f7770735f656e61626c655f36675f6669726577616c6c223b733a303a22223b733a32363a2261696f7770735f656e61626c655f637573746f6d5f72756c6573223b733a303a22223b733a31393a2261696f7770735f637573746f6d5f72756c6573223b733a303a22223b733a32353a2261696f7770735f656e61626c655f3430345f6c6f6767696e67223b733a313a2231223b733a32383a2261696f7770735f656e61626c655f3430345f49505f6c6f636b6f7574223b733a313a2231223b733a33303a2261696f7770735f3430345f6c6f636b6f75745f74696d655f6c656e677468223b693a36303b733a32383a2261696f7770735f3430345f6c6f636b5f72656469726563745f75726c223b733a31363a22687474703a2f2f3132372e302e302e31223b733a33313a2261696f7770735f656e61626c655f72656e616d655f6c6f67696e5f70616765223b733a303a22223b733a32383a2261696f7770735f656e61626c655f6c6f67696e5f686f6e6579706f74223b733a313a2231223b733a34333a2261696f7770735f656e61626c655f62727574655f666f7263655f61747461636b5f70726576656e74696f6e223b733a303a22223b733a33303a2261696f7770735f62727574655f666f7263655f7365637265745f776f7264223b733a303a22223b733a32343a2261696f7770735f636f6f6b69655f62727574655f74657374223b733a303a22223b733a34343a2261696f7770735f636f6f6b69655f62617365645f62727574655f666f7263655f72656469726563745f75726c223b733a31363a22687474703a2f2f3132372e302e302e31223b733a35393a2261696f7770735f62727574655f666f7263655f61747461636b5f70726576656e74696f6e5f70775f70726f7465637465645f657863657074696f6e223b733a303a22223b733a35313a2261696f7770735f62727574655f666f7263655f61747461636b5f70726576656e74696f6e5f616a61785f657863657074696f6e223b733a303a22223b733a31393a2261696f7770735f736974655f6c6f636b6f7574223b733a303a22223b733a32333a2261696f7770735f736974655f6c6f636b6f75745f6d7367223b733a303a22223b733a33303a2261696f7770735f656e61626c655f7370616d626f745f626c6f636b696e67223b733a303a22223b733a32393a2261696f7770735f656e61626c655f636f6d6d656e745f63617074636861223b733a303a22223b733a33313a2261696f7770735f656e61626c655f6175746f626c6f636b5f7370616d5f6970223b733a303a22223b733a33333a2261696f7770735f7370616d5f69705f6d696e5f636f6d6d656e74735f626c6f636b223b733a303a22223b733a33323a2261696f7770735f656e61626c655f6175746f6d617465645f6663645f7363616e223b733a303a22223b733a32353a2261696f7770735f6663645f7363616e5f6672657175656e6379223b733a313a2234223b733a32343a2261696f7770735f6663645f7363616e5f696e74657276616c223b733a313a2232223b733a32383a2261696f7770735f6663645f6578636c7564655f66696c657479706573223b733a303a22223b733a32343a2261696f7770735f6663645f6578636c7564655f66696c6573223b733a303a22223b733a32363a2261696f7770735f73656e645f6663645f7363616e5f656d61696c223b733a303a22223b733a32393a2261696f7770735f6663645f7363616e5f656d61696c5f61646472657373223b733a31383a22696374406a616e65676f6f64616c6c2e6265223b733a32373a2261696f7770735f666364735f6368616e67655f6465746563746564223b623a303b733a32323a2261696f7770735f636f70795f70726f74656374696f6e223b733a303a22223b733a34303a2261696f7770735f70726576656e745f736974655f646973706c61795f696e736964655f6672616d65223b733a303a22223b733a33323a2261696f7770735f70726576656e745f75736572735f656e756d65726174696f6e223b733a303a22223b733a32383a2261696f7770735f626c6f636b5f66616b655f676f6f676c65626f7473223b733a313a2231223b733a33353a2261696f7770735f656e61626c655f6c6f73745f70617373776f72645f63617074636861223b733a313a2231223b733a32353a2261696f7770735f62616e6e65645f757365725f6167656e7473223b733a303a22223b733a34333a2261696f7770735f696e7374616e746c795f6c6f636b6f75745f73706563696669635f757365726e616d6573223b613a303a7b7d733a33353a2261696f7770735f6c6f636b646f776e5f656e61626c655f77686974656c697374696e67223b733a303a22223b733a33363a2261696f7770735f6c6f636b646f776e5f616c6c6f7765645f69705f616464726573736573223b733a303a22223b733a33353a2261696f7770735f656e61626c655f726567697374726174696f6e5f686f6e6579706f74223b733a303a22223b733a33383a2261696f7770735f64697361626c655f786d6c7270635f70696e676261636b5f6d6574686f6473223b733a303a22223b7d, 'yes'),
(176, 'backwpup_cfg_hash', 0x613265626230, 'yes'),
(177, 'backwpup_jobs', 0x613a323a7b693a313b613a33383a7b733a353a226a6f626964223b693a313b733a31303a226261636b757074797065223b733a373a2261726368697665223b733a343a2274797065223b613a323a7b693a303b733a363a22444244554d50223b693a313b733a343a2246494c45223b7d733a31323a2264657374696e6174696f6e73223b613a313a7b693a303b733a363a22464f4c444552223b7d733a343a226e616d65223b733a393a2257656b656c696a6b73223b733a31343a226d61696c616464726573736c6f67223b733a31383a22696374406a616e65676f6f64616c6c2e6265223b733a32303a226d61696c6164647265737373656e6465726c6f67223b733a36373a224261636b57507570204a616e6520476f6f64616c6c5c277320526f6f7473616e6473686f6f7473204575726f7065203c696374406a616e65676f6f64616c6c2e62653e223b733a31333a226d61696c6572726f726f6e6c79223b623a313b733a31333a2261726368697665666f726d6174223b733a343a222e7a6970223b733a31313a22617263686976656e616d65223b733a33333a226261636b777075705f6132656262305f25592d256d2d25645f25482d25692d2573223b733a31303a2261637469766574797065223b733a363a22777063726f6e223b733a31303a2263726f6e73656c656374223b733a353a226261736963223b733a343a2263726f6e223b733a393a22302033202a202a2030223b733a32313a22646264756d7066696c65636f6d7072657373696f6e223b733a303a22223b733a31303a22646264756d7066696c65223b733a31313a22726f6f7473616e64767434223b733a31333a22646264756d706578636c756465223b613a303a7b7d733a31313a2266696c656578636c756465223b733a35313a222e44535f53746f72652c2e6769742c2e73766e2c2e746d702c2f6e6f64655f6d6f64756c65732f2c6465736b746f702e696e69223b733a31303a22646972696e636c756465223b733a303a22223b733a31393a226261636b75706578636c7564657468756d6273223b623a303b733a31383a226261636b75707370656369616c66696c6573223b623a313b733a31303a226261636b7570726f6f74223b623a313b733a31373a226261636b7570616273666f6c6465727570223b623a303b733a32313a226261636b7570726f6f746578636c75646564697273223b613a303a7b7d733a31333a226261636b7570636f6e74656e74223b623a313b733a32343a226261636b7570636f6e74656e746578636c75646564697273223b613a313a7b693a303b733a373a2275706772616465223b7d733a31333a226261636b7570706c7567696e73223b623a313b733a32343a226261636b7570706c7567696e736578636c75646564697273223b613a323a7b693a303b733a373a22616b69736d6574223b693a313b733a32323a227365727665722d69702d6d656d6f72792d7573616765223b7d733a31323a226261636b75707468656d6573223b623a313b733a32333a226261636b75707468656d65736578636c75646564697273223b613a313a7b693a303b733a31333a227477656e74796669667465656e223b7d733a31333a226261636b757075706c6f616473223b623a313b733a32343a226261636b757075706c6f6164736578636c75646564697273223b613a303a7b7d733a393a226261636b7570646972223b733a33323a2275706c6f6164732f6261636b777075702d6132656262302d6261636b7570732f223b733a31303a226d61786261636b757073223b693a333b733a31383a226261636b757073796e636e6f64656c657465223b623a303b733a373a226c61737472756e223b693a313439333533313336313b733a373a226c6f6766696c65223b733a3130353a222f686f6d652f726f6f7473616e6476742f7777772f77702d636f6e74656e742f75706c6f6164732f6261636b777075702d6132656262302d6c6f67732f6261636b777075705f6c6f675f6132656262305f323031372d30342d33305f30352d34392d32312e68746d6c223b733a32313a226c6173746261636b7570646f776e6c6f616475726c223b733a3135373a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d61646d696e2f61646d696e2e7068703f706167653d6261636b777075706261636b75707326616374696f6e3d646f776e6c6f6164666f6c6465722666696c653d6261636b777075705f6132656262305f323031372d30342d33305f30352d34392d32312e7a6970266a6f6269643d31223b733a31313a226c61737472756e74696d65223b693a34323b7d693a323b613a33333a7b733a353a226a6f626964223b693a323b733a31303a226261636b757074797065223b733a373a2261726368697665223b733a343a2274797065223b613a323a7b693a303b733a363a22444244554d50223b693a313b733a343a2246494c45223b7d733a31323a2264657374696e6174696f6e73223b613a313a7b693a303b733a363a22464f4c444552223b7d733a343a226e616d65223b733a31333a224d616e75616c206261636b7570223b733a31343a226d61696c616464726573736c6f67223b733a303a22223b733a32303a226d61696c6164647265737373656e6465726c6f67223b733a36353a224261636b57507570204a616e6520476f6f64616c6c5c277320526f6f74732653686f6f7473204575726f7065203c696374406a616e65676f6f64616c6c2e62653e223b733a31333a226d61696c6572726f726f6e6c79223b623a303b733a31333a2261726368697665666f726d6174223b733a343a222e7a6970223b733a31313a22617263686976656e616d65223b733a33353a226261636b777075705f61326562623030325f25592d256d2d25645f25482d25692d2573223b733a32313a22646264756d7066696c65636f6d7072657373696f6e223b733a303a22223b733a31303a22646264756d7066696c65223b733a32313a22726f6f7473616e6473686f6f74735f6575726f7065223b733a31333a22646264756d706578636c756465223b613a363a7b693a303b733a32313a22776f72313637375f61696f7770735f6576656e7473223b693a313b733a32383a22776f72313637375f61696f7770735f6661696c65645f6c6f67696e73223b693a323b733a32363a22776f72313637375f61696f7770735f676c6f62616c5f6d657461223b693a333b733a32393a22776f72313637375f61696f7770735f6c6f67696e5f6163746976697479223b693a343b733a32393a22776f72313637375f61696f7770735f6c6f67696e5f6c6f636b646f776e223b693a353b733a33303a22776f72313637375f61696f7770735f7065726d616e656e745f626c6f636b223b7d733a31313a2266696c656578636c756465223b733a35313a222e44535f53746f72652c2e6769742c2e73766e2c2e746d702c2f6e6f64655f6d6f64756c65732f2c6465736b746f702e696e69223b733a31303a22646972696e636c756465223b733a303a22223b733a31393a226261636b75706578636c7564657468756d6273223b623a303b733a31383a226261636b75707370656369616c66696c6573223b623a313b733a31303a226261636b7570726f6f74223b623a313b733a31373a226261636b7570616273666f6c6465727570223b623a303b733a31333a226261636b7570636f6e74656e74223b623a313b733a31333a226261636b7570706c7567696e73223b623a313b733a31323a226261636b75707468656d6573223b623a313b733a31333a226261636b757075706c6f616473223b623a313b733a32313a226261636b7570726f6f746578636c75646564697273223b613a303a7b7d733a32343a226261636b7570706c7567696e736578636c75646564697273223b613a313a7b693a303b733a383a226261636b77707570223b7d733a32333a226261636b75707468656d65736578636c75646564697273223b613a303a7b7d733a32343a226261636b757075706c6f6164736578636c75646564697273223b613a313a7b693a303b733a32303a226261636b777075702d6132656262302d6c6f6773223b7d733a393a226261636b7570646972223b733a33323a2275706c6f6164732f6261636b777075702d6132656262302d6261636b7570732f223b733a31303a226d61786261636b757073223b693a313b733a31383a226261636b757073796e636e6f64656c657465223b623a303b733a373a226c61737472756e223b693a313439363331363039393b733a373a226c6f6766696c65223b733a3131393a22433a2f77616d7036342f7777772f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f6261636b777075702d6132656262302d6c6f67732f6261636b777075705f6c6f675f6132656262305f323031372d30362d30315f31312d32312d33392e68746d6c223b733a32313a226c6173746261636b7570646f776e6c6f616475726c223b733a303a22223b7d7d, 'no'),
(178, 'backwpup_version', 0x332e342e30, 'no'),
(179, 'backwpup_cfg_showadminbar', 0x31, 'yes'),
(180, 'backwpup_cfg_showfoldersize', '', 'yes'),
(181, 'backwpup_cfg_protectfolders', 0x31, 'yes'),
(182, 'backwpup_cfg_jobmaxexecutiontime', 0x3330, 'yes'),
(183, 'backwpup_cfg_jobstepretry', 0x33, 'yes'),
(184, 'backwpup_cfg_jobrunauthkey', 0x3335636132356234, 'yes'),
(185, 'backwpup_cfg_loglevel', 0x6e6f726d616c5f7472616e736c61746564, 'yes'),
(186, 'backwpup_cfg_jobwaittimems', '', 'yes'),
(187, 'backwpup_cfg_jobdooutput', '', 'yes'),
(188, 'backwpup_cfg_maxlogs', 0x3330, 'yes'),
(189, 'backwpup_cfg_gzlogs', '', 'yes'),
(190, 'backwpup_cfg_logfolder', 0x75706c6f6164732f6261636b777075702d6132656262302d6c6f67732f, 'yes'),
(191, 'backwpup_cfg_httpauthuser', '', 'yes'),
(192, 'backwpup_cfg_httpauthpassword', '', 'yes'),
(194, 'backwpup_about_page', 0x31, 'yes'),
(199, '_transient_timeout_feed_78563e83d96fd15aaf33246bfd7f9d95', 0x31343633393630323138, 'no'),
(238, 'qtranslate_admin_notices', 0x613a323a7b733a31353a22696e697469616c2d696e7374616c6c223b693a313436333935303736313b733a32363a227375727665792d7472616e736c6174696f6e2d73657276696365223b693a313436333939353732333b7d, 'yes'),
(239, 'qtranslate_enabled_languages', 0x613a363a7b693a303b733a323a22656e223b693a313b733a323a226e6c223b693a323b733a323a226672223b693a333b733a323a226465223b693a343b733a323a226573223b693a353b733a323a226974223b7d, 'yes'),
(240, 'qtranslate_default_language', 0x656e, 'yes'),
(241, 'qtranslate_version_previous', 0x3334363830, 'yes'),
(242, 'qtranslate_versions', 0x613a343a7b693a33343638303b693a313436333935303734333b733a313a226c223b693a313437313936363631383b733a313a2274223b693a373939333836373b733a313a2270223b693a313437313938353030303b7d, 'yes'),
(243, 'qtranslate_admin_config', 0x613a373a7b733a343a22706f7374223b613a343a7b733a353a227061676573223b613a323a7b733a383a22706f73742e706870223b733a303a22223b733a31323a22706f73742d6e65772e706870223b733a303a22223b7d733a373a22616e63686f7273223b613a313a7b733a31373a22706f73742d626f64792d636f6e74656e74223b613a313a7b733a353a227768657265223b733a31303a226669727374206c617374223b7d7d733a353a22666f726d73223b613a323a7b733a343a22706f7374223b613a313a7b733a363a226669656c6473223b613a383a7b733a353a227469746c65223b613a303a7b7d733a373a2265786365727074223b613a303a7b7d733a31383a226174746163686d656e745f63617074696f6e223b613a303a7b7d733a31343a226174746163686d656e745f616c74223b613a303a7b7d733a31333a22766965772d706f73742d62746e223b613a313a7b733a363a22656e636f6465223b733a373a22646973706c6179223b7d733a31343a2277702d656469746f722d61726561223b613a313a7b733a363a226a7175657279223b733a31353a222e77702d656469746f722d61726561223b7d733a31353a2267616c6c6572792d63617074696f6e223b613a323a7b733a363a226a7175657279223b733a31363a222e67616c6c6572792d63617074696f6e223b733a363a22656e636f6465223b733a343a226e6f6e65223b7d733a31353a2277702d63617074696f6e2d74657874223b613a323a7b733a363a226a7175657279223b733a31363a222e77702d63617074696f6e2d74657874223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d733a31343a227770626f64792d636f6e74656e74223b613a313a7b733a363a226669656c6473223b613a323a7b733a373a22777261702d6831223b613a323a7b733a363a226a7175657279223b733a383a222e77726170206831223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d733a373a22777261702d6832223b613a323a7b733a363a226a7175657279223b733a383a222e77726170206832223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d7d733a373a226a732d65786563223b613a313a7b733a393a22706f73742d65786563223b613a313a7b733a333a22737263223b733a32373a222e2f61646d696e2f6a732f706f73742d657865632e6d696e2e6a73223b7d7d7d733a31353a226f7074696f6e732d67656e6572616c223b613a333a7b733a31343a22707265675f64656c696d69746572223b733a313a2223223b733a353a227061676573223b613a313a7b733a31393a226f7074696f6e732d67656e6572616c2e706870223b733a32313a225e283f212e2a706167653d5b5e3d265d2b292e2a24223b7d733a353a22666f726d73223b613a313a7b733a373a226f7074696f6e73223b613a313a7b733a363a226669656c6473223b613a333a7b733a383a22626c6f676e616d65223b613a303a7b7d733a31353a22626c6f676465736372697074696f6e223b613a303a7b7d733a31303a22686561642d7469746c65223b613a323a7b733a363a226a7175657279223b733a31303a2268656164207469746c65223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d7d7d733a373a2277696467657473223b613a343a7b733a353a227061676573223b613a313a7b733a31313a22776964676574732e706870223b733a303a22223b7d733a373a22616e63686f7273223b613a313a7b733a31333a22776964676574732d7269676874223b613a313a7b733a353a227768657265223b733a31323a226265666f7265206166746572223b7d7d733a353a22666f726d73223b613a313a7b733a31333a22776964676574732d7269676874223b613a313a7b733a363a226669656c6473223b613a333a7b733a31323a227769646765742d7469746c65223b613a313a7b733a363a226a7175657279223b733a33343a22696e7075745b69645e3d277769646765742d275d5b6964243d272d7469746c65275d223b7d733a31363a227769646765742d746578742d74657874223b613a313a7b733a363a226a7175657279223b733a34313a2274657874617265615b69645e3d277769646765742d746578742d275d5b6964243d272d74657874275d223b7d733a31353a22696e2d7769646765742d7469746c65223b613a323a7b733a363a226a7175657279223b733a32303a227370616e2e696e2d7769646765742d7469746c65223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d7d733a373a226a732d65786563223b613a313a7b733a31323a22776964676574732d65786563223b613a313a7b733a333a22737263223b733a33303a222e2f61646d696e2f6a732f776964676574732d657865632e6d696e2e6a73223b7d7d7d733a383a22656469742d746167223b613a333a7b733a353a227061676573223b613a323a7b733a383a227465726d2e706870223b733a303a22223b733a31333a22656469742d746167732e706870223b733a31313a22616374696f6e3d65646974223b7d733a353a22666f726d73223b613a313a7b733a373a2265646974746167223b613a313a7b733a363a226669656c6473223b613a333a7b733a343a226e616d65223b613a303a7b7d733a31313a226465736372697074696f6e223b613a303a7b7d733a363a22706172656e74223b613a313a7b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d7d733a373a226a732d65786563223b613a313a7b733a31333a22656469742d7461672d65786563223b613a313a7b733a333a22737263223b733a33313a222e2f61646d696e2f6a732f656469742d7461672d657865632e6d696e2e6a73223b7d7d7d733a393a22656469742d74616773223b613a353a7b733a31343a22707265675f64656c696d69746572223b733a313a2223223b733a353a227061676573223b613a313a7b733a31333a22656469742d746167732e706870223b733a32313a225e283f212e2a616374696f6e3d65646974292e2a24223b7d733a373a22616e63686f7273223b613a313a7b733a31323a22706f7374732d66696c746572223b613a313a7b733a353a227768657265223b733a31323a226265666f7265206166746572223b7d7d733a353a22666f726d73223b613a333a7b733a363a22616464746167223b613a313a7b733a363a226669656c6473223b613a333a7b733a383a227461672d6e616d65223b613a303a7b7d733a31353a227461672d6465736372697074696f6e223b613a303a7b7d733a363a22706172656e74223b613a313a7b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d733a383a22636f6c2d6c656674223b613a313a7b733a363a226669656c6473223b613a313a7b733a383a22746167636c6f7564223b613a323a7b733a363a226a7175657279223b733a31333a222e746167636c6f7564203e2061223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d733a383a227468652d6c697374223b613a313a7b733a363a226669656c6473223b613a323a7b733a393a22726f772d7469746c65223b613a323a7b733a363a226a7175657279223b733a31303a222e726f772d7469746c65223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d733a31313a226465736372697074696f6e223b613a323a7b733a363a226a7175657279223b733a31323a222e6465736372697074696f6e223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d7d733a373a226a732d65786563223b613a313a7b733a31343a22656469742d746167732d65786563223b613a313a7b733a333a22737263223b733a33323a222e2f61646d696e2f6a732f656469742d746167732d657865632e6d696e2e6a73223b7d7d7d733a393a226e61762d6d656e7573223b613a343a7b733a353a227061676573223b613a313a7b733a31333a226e61762d6d656e75732e706870223b733a32333a22616374696f6e3d656469747c6d656e753d5c642b7c5e24223b7d733a373a22616e63686f7273223b613a313a7b733a31323a226d656e752d746f2d65646974223b613a313a7b733a353a227768657265223b733a31323a226265666f7265206166746572223b7d7d733a353a22666f726d73223b613a323a7b733a31353a227570646174652d6e61762d6d656e75223b613a313a7b733a363a226669656c6473223b613a353a7b733a353a227469746c65223b613a313a7b733a363a226a7175657279223b733a32373a225b69645e3d656469742d6d656e752d6974656d2d7469746c652d5d223b7d733a31303a22617474722d7469746c65223b613a313a7b733a363a226a7175657279223b733a33323a225b69645e3d656469742d6d656e752d6974656d2d617474722d7469746c652d5d223b7d733a31313a226465736372697074696f6e223b613a313a7b733a363a226a7175657279223b733a33333a225b69645e3d656469742d6d656e752d6974656d2d6465736372697074696f6e2d5d223b7d733a31303a227370616e2e7469746c65223b613a323a7b733a363a226a7175657279223b733a32303a227370616e2e6d656e752d6974656d2d7469746c65223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d733a31363a226c696e6b2d746f2d6f726967696e616c223b613a323a7b733a363a226a7175657279223b733a32303a222e6c696e6b2d746f2d6f726967696e616c203e61223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d733a31343a22736964652d736f727461626c6573223b613a313a7b733a363a226669656c6473223b613a323a7b733a31313a226c6162656c2e7469746c65223b613a323a7b733a363a226a7175657279223b733a32313a226c6162656c2e6d656e752d6974656d2d7469746c65223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d733a32333a226163636f7264696f6e2d73656374696f6e2d7469746c65223b613a323a7b733a363a226a7175657279223b733a32363a2268332e6163636f7264696f6e2d73656374696f6e2d7469746c65223b733a363a22656e636f6465223b733a373a22646973706c6179223b7d7d7d7d733a373a226a732d65786563223b613a313a7b733a31343a226e61762d6d656e75732d65786563223b613a313a7b733a333a22737263223b733a33323a222e2f61646d696e2f6a732f6e61762d6d656e75732d657865632e6d696e2e6a73223b7d7d7d733a393a22616c6c2d7061676573223b613a313a7b733a373a2266696c74657273223b613a313a7b733a343a2274657874223b613a313a7b733a31313a2261646d696e5f7469746c65223b733a323a223230223b7d7d7d7d, 'yes'),
(2706, 'qtranslate_show_displayed_language_prefix', '', 'yes'),
(454, 'widget_flickr-widget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(455, 'widget_instagram-widget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(456, 'widget_video-widget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(457, 'widget_sf_recent_custom_posts', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(458, 'widget_sf_recent_custom_portfolio', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(459, 'widget_sf_custom_portfolio_grid', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(460, 'widget_advert-grid-widget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(461, 'widget_sf_infocus_widget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(267, 'qtranslate_language_names', 0x613a363a7b733a323a226e6c223b733a31303a224e656465726c616e6473223b733a323a226672223b733a393a226672616ec3a7616973223b733a323a226573223b733a383a2245737061c3b16f6c223b733a323a226974223b733a383a224974616c69616e6f223b733a323a226465223b733a373a2244657574736368223b733a323a22656e223b733a373a22456e676c697368223b7d, 'yes'),
(268, 'qtranslate_locales', 0x613a363a7b733a323a226e6c223b733a353a226e6c5f4245223b733a323a226672223b733a353a2266725f4652223b733a323a226573223b733a353a2265735f4553223b733a323a226974223b733a353a2269745f4954223b733a323a226465223b733a353a2264655f4445223b733a323a22656e223b733a353a22656e5f4742223b7d, 'yes'),
(269, 'qtranslate_locales_html', 0x613a353a7b733a323a226e6c223b733a323a226e6c223b733a323a226672223b733a323a226672223b733a323a226573223b733a323a226573223b733a323a226974223b733a323a226974223b733a323a226465223b733a323a226465223b7d, 'yes'),
(244, 'qtranslate_front_config', 0x613a313a7b733a393a22616c6c2d7061676573223b613a313a7b733a373a2266696c74657273223b613a333a7b733a343a2274657874223b613a31313a7b733a31323a227769646765745f7469746c65223b733a323a223230223b733a31313a227769646765745f74657874223b733a323a223230223b733a393a227468655f7469746c65223b733a323a223230223b733a32303a2263617465676f72795f6465736372697074696f6e223b733a323a223230223b733a393a226c6973745f63617473223b733a323a223230223b733a31363a2277705f64726f70646f776e5f63617473223b733a323a223230223b733a393a227465726d5f6e616d65223b733a323a223230223b733a31383a226765745f636f6d6d656e745f617574686f72223b733a323a223230223b733a31303a227468655f617574686f72223b733a323a223230223b733a393a22746d6c5f7469746c65223b733a323a223230223b733a31363a227465726d5f6465736372697074696f6e223b733a323a223230223b7d733a343a227465726d223b613a31303a7b733a373a226361745f726f77223b733a313a2230223b733a383a226361745f726f7773223b733a313a2230223b733a31393a2277705f6765745f6f626a6563745f7465726d73223b733a313a2230223b733a31363a2273696e676c655f6361745f7469746c65223b733a313a2230223b733a31363a2273696e676c655f7461675f7469746c65223b733a313a2230223b733a31373a2273696e676c655f7465726d5f7469746c65223b733a313a2230223b733a31323a227468655f63617465676f7279223b733a313a2230223b733a383a226765745f7465726d223b733a313a2230223b733a393a226765745f7465726d73223b733a313a2230223b733a31323a226765745f63617465676f7279223b733a313a2230223b7d733a333a2275726c223b613a31363a7b733a31363a22617574686f725f666565645f6c696e6b223b733a323a223130223b733a31313a22617574686f725f6c696e6b223b733a323a223130223b733a32373a226765745f636f6d6d656e745f617574686f725f75726c5f6c696e6b223b733a323a223130223b733a32333a22706f73745f636f6d6d656e74735f666565645f6c696e6b223b733a323a223130223b733a383a226461795f6c696e6b223b733a323a223130223b733a31303a226d6f6e74685f6c696e6b223b733a323a223130223b733a393a22796561725f6c696e6b223b733a323a223130223b733a393a22706167655f6c696e6b223b733a323a223130223b733a393a22706f73745f6c696e6b223b733a323a223130223b733a31333a2263617465676f72795f6c696e6b223b733a323a223130223b733a31383a2263617465676f72795f666565645f6c696e6b223b733a323a223130223b733a383a227461675f6c696e6b223b733a323a223130223b733a393a227465726d5f6c696e6b223b733a323a223130223b733a31333a227468655f7065726d616c696e6b223b733a323a223130223b733a393a22666565645f6c696e6b223b733a323a223130223b733a31333a227461675f666565645f6c696e6b223b733a323a223130223b7d7d7d7d, 'yes'),
(245, 'widget_qtranslate', 0x613a323a7b693a323b613a333a7b733a353a227469746c65223b733a32333a225b3a656e5d43686f6f7365206c616e67756167655b3a5d223b733a343a2274797065223b733a343a2274657874223b733a31303a227769646765742d637373223b733a3835373a222e717472616e78735f77696467657420756c207b206d617267696e3a20303b207d0d0a2e717472616e78735f77696467657420756c206c690d0a7b0d0a646973706c61793a20696e6c696e653b202f2a20686f72697a6f6e74616c206c6973742c2075736520226c6973742d6974656d22206f72206f7468657220617070726f7072696174652076616c756520666f7220766572746963616c206c697374202a2f0d0a6c6973742d7374796c652d747970653a206e6f6e653b202f2a207573652022696e697469616c22206f72206f7468657220746f20656e61626c652062756c6c657473202a2f0d0a6d617267696e3a203020357078203020303b202f2a2061646a7573742073706163696e67206265747765656e206974656d73202a2f0d0a6f7061636974793a20302e353b0d0a2d6f2d7472616e736974696f6e3a2031732065617365206f7061636974793b0d0a2d6d6f7a2d7472616e736974696f6e3a2031732065617365206f7061636974793b0d0a2d7765626b69742d7472616e736974696f6e3a2031732065617365206f7061636974793b0d0a7472616e736974696f6e3a2031732065617365206f7061636974793b0d0a7d0d0a2f2a202e717472616e78735f77696467657420756c206c69207370616e207b206d617267696e3a203020357078203020303b207d202a2f202f2a206f746865722077617920746f20636f6e74726f6c2073706163696e67202a2f0d0a2e717472616e78735f77696467657420756c206c692e616374697665207b206f7061636974793a20302e383b207d0d0a2e717472616e78735f77696467657420756c206c693a686f766572207b206f7061636974793a20313b207d0d0a2e717472616e78735f77696467657420696d67207b20626f782d736861646f773a206e6f6e653b20766572746963616c2d616c69676e3a206d6964646c653b20646973706c61793a20696e697469616c3b207d0d0a2e717472616e78735f666c6167207b206865696768743a313270783b2077696474683a313870783b20646973706c61793a626c6f636b3b207d0d0a2e717472616e78735f666c61675f616e645f74657874207b2070616464696e672d6c6566743a323070783b207d0d0a2e717472616e78735f666c6167207370616e207b20646973706c61793a6e6f6e653b207d0d0a223b7d733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(246, 'qtranslate_next_thanks', 0x31343830393731353433, 'yes'),
(247, 'qtranslate_next_update_mo', 0x31343732313137333435, 'yes'),
(400, 'c4p_mode', 0x70616765, 'yes'),
(401, 'c4p_selected_page', 0x733a3836333a224f3a373a2257505f506f7374223a32343a7b733a323a224944223b693a32373b733a31313a22706f73745f617574686f72223b733a313a2231223b733a393a22706f73745f64617465223b733a31393a22323031362d30352d32342031383a35303a3536223b733a31333a22706f73745f646174655f676d74223b733a31393a22323031362d30352d32342031363a35303a3536223b733a31323a22706f73745f636f6e74656e74223b733a303a22223b733a31303a22706f73745f7469746c65223b733a36343a225b3a656e5d556e666f7274756e6174656c795b3a6e6c5d5370696a7469675b3a66725d4d616c68657572657573656d656e745b3a64655d4c65696465725b3a5d223b733a31323a22706f73745f65786365727074223b733a303a22223b733a31313a22706f73745f737461747573223b733a373a227075626c697368223b733a31343a22636f6d6d656e745f737461747573223b733a363a22636c6f736564223b733a31313a2270696e675f737461747573223b733a363a22636c6f736564223b733a31333a22706f73745f70617373776f7264223b733a303a22223b733a393a22706f73745f6e616d65223b733a31333a22756e666f7274756e6174656c79223b733a373a22746f5f70696e67223b733a303a22223b733a363a2270696e676564223b733a303a22223b733a31333a22706f73745f6d6f646966696564223b733a31393a22323031362d30352d32342031383a35303a3536223b733a31373a22706f73745f6d6f6469666965645f676d74223b733a31393a22323031362d30352d32342031363a35303a3536223b733a32313a22706f73745f636f6e74656e745f66696c7465726564223b733a303a22223b733a31313a22706f73745f706172656e74223b693a303b733a343a2267756964223b733a35343a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f3f706167655f69643d3237223b733a31303a226d656e755f6f72646572223b693a303b733a393a22706f73745f74797065223b733a343a2270616765223b733a31343a22706f73745f6d696d655f74797065223b733a303a22223b733a31333a22636f6d6d656e745f636f756e74223b733a313a2230223b733a363a2266696c746572223b733a333a22726177223b7d223b, 'yes'),
(270, 'qtranslate_na_messages', 0x613a363a7b733a323a226e6c223b733a35393a22536f7272792c20646974206265726963687420697320616c6c65656e206265736368696b6261617220696e20254c414e473a2c203a20656e20252e223b733a323a226672223b733a36353a2244c3a9736f6cc3a92c206365742061727469636c6520657374207365756c656d656e7420646973706f6e69626c6520656e20254c414e473a2c203a20657420252e223b733a323a226573223b733a36383a2244697363756c70612c207065726f206573746120656e747261646120657374c3a120646973706f6e69626c652073c3b36c6f20656e20254c414e473a2c203a207920252e223b733a323a226974223b733a37313a224369207370696163652c206d612071756573746f2061727469636f6c6f20c3a820646973706f6e6962696c6520736f6c74616e746f20696e20254c414e473a2c203a206520252e223b733a323a226465223b733a35383a224c656964657220697374206465722045696e74726167206e75722061756620254c414e473a2c203a20756e6420252076657266c3bc676261722e223b733a323a22656e223b733a35353a22536f7272792c207468697320656e747279206973206f6e6c7920617661696c61626c6520696e20254c414e473a2c203a20616e6420252e223b7d, 'yes'),
(271, 'qtranslate_flags', 0x613a363a7b733a323a226e6c223b733a363a226e6c2e706e67223b733a323a226672223b733a363a2266722e706e67223b733a323a226573223b733a363a2265732e706e67223b733a323a226974223b733a363a2269742e706e67223b733a323a226465223b733a363a2264652e706e67223b733a323a22656e223b733a363a2267622e706e67223b7d, 'yes'),
(272, 'qtranslate_ignore_file_types', 0x6769662c6a70672c6a7065672c706e672c7376672c7064662c7377662c7469662c7261722c7a69702c377a2c6d70672c646976782c6d7065672c6176692c6373732c6a732c6d70332c6d70342c61706b, 'yes'),
(2707, 'qtranslate_hide_default_language', '', 'yes'),
(296, 'qtranslate_time_formats', 0x613a353a7b733a323a226573223b733a31303a2225483a254d206872732e223b733a323a226974223b733a353a2225483a254d223b733a323a226465223b733a353a2225483a254d223b733a323a226672223b733a353a2225483a254d223b733a323a22656e223b733a383a2225493a254d202570223b7d, 'yes'),
(451, 'theme_mods_joyn-child', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a373a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a31313a22666f6f7465725f6d656e75223b693a303b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313436343238393839353b733a343a2264617461223b613a31323a7b733a31393a2277705f696e6163746976655f77696467657473223b613a343a7b693a303b733a31343a22726563656e742d706f7374732d32223b693a313b733a31373a22726563656e742d636f6d6d656e74732d32223b693a323b733a363a226d6574612d32223b693a333b733a31323a22717472616e736c6174652d32223b7d733a393a22736964656261722d31223b613a333a7b693a303b733a383a227365617263682d32223b693a313b733a31303a2261726368697665732d32223b693a323b733a31323a2263617465676f726965732d32223b7d733a393a22736964656261722d32223b613a303a7b7d733a393a22736964656261722d33223b613a303a7b7d733a393a22736964656261722d34223b4e3b733a393a22736964656261722d35223b4e3b733a393a22736964656261722d36223b4e3b733a393a22736964656261722d37223b4e3b733a393a22736964656261722d38223b4e3b733a31353a22666f6f7465722d636f6c756d6e2d31223b4e3b733a31353a22666f6f7465722d636f6c756d6e2d32223b4e3b733a31353a22666f6f7465722d636f6c756d6e2d33223b4e3b7d7d7d, 'yes'),
(453, 'widget_twitter-widget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(339, 'current_theme', 0x496e74756974696f6e2050726f206368696c64, 'yes'),
(340, 'theme_mods_twentysixteen-child', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a323a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313436343235323135363b733a343a2264617461223b613a343a7b733a31393a2277705f696e6163746976655f77696467657473223b613a343a7b693a303b733a31343a22726563656e742d706f7374732d32223b693a313b733a31373a22726563656e742d636f6d6d656e74732d32223b693a323b733a363a226d6574612d32223b693a333b733a31323a22717472616e736c6174652d32223b7d733a393a22736964656261722d31223b613a333a7b693a303b733a383a227365617263682d32223b693a313b733a31303a2261726368697665732d32223b693a323b733a31323a2263617465676f726965732d32223b7d733a393a22736964656261722d32223b613a303a7b7d733a393a22736964656261722d33223b613a303a7b7d7d7d7d, 'yes'),
(341, 'theme_switched', '', 'yes'),
(402, 'c4p_selected_url', '', 'yes'),
(590, 'license_intuitionpro', 0x36653533623530643539353933313463346464383065383731323965636439, 'yes'),
(476, 'external_theme_updates-joyn', 0x4f3a383a22737464436c617373223a333a7b733a393a226c617374436865636b223b693a313436343238393838353b733a31343a22636865636b656456657273696f6e223b733a353a22322e352e30223b733a363a22757064617465223b4e3b7d, 'yes'),
(462, 'widget_sf_recent_custom_comments', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(463, 'widget_lip_most_loved_widget', 0x613a313a7b733a31323a225f6d756c7469776964676574223b693a313b7d, 'yes'),
(464, 'sf_customizer', 0x613a3130303a7b733a31373a2264657369676e5f7374796c655f74797065223b733a373a226d696e696d616c223b733a31323a22616363656e745f636f6c6f72223b733a373a2223666535303466223b733a31363a22616363656e745f616c745f636f6c6f72223b733a373a2223666666666666223b733a32323a227365636f6e646172795f616363656e745f636f6c6f72223b733a373a2223323232323232223b733a32363a227365636f6e646172795f616363656e745f616c745f636f6c6f72223b733a373a2223666666666666223b733a31333a22706167655f62675f636f6c6f72223b733a373a2223323232323232223b733a32353a22696e6e65725f706167655f62675f7472616e73706172656e74223b733a353a22636f6c6f72223b733a31393a22696e6e65725f706167655f62675f636f6c6f72223b733a373a2223464646464646223b733a32303a2273656374696f6e5f6469766964655f636f6c6f72223b733a373a2223653465346534223b733a31323a22616c745f62675f636f6c6f72223b733a373a2223663766376637223b733a31353a22746f706261725f62675f636f6c6f72223b733a373a2223666666666666223b733a31373a22746f706261725f746578745f636f6c6f72223b733a373a2223323232323232223b733a31373a22746f706261725f6c696e6b5f636f6c6f72223b733a373a2223363636363636223b733a32333a22746f706261725f6c696e6b5f686f7665725f636f6c6f72223b733a373a2223666535303466223b733a32303a22746f706261725f646976696465725f636f6c6f72223b733a373a2223653365336533223b733a31353a226865616465725f62675f636f6c6f72223b733a373a2223666666666666223b733a32313a226865616465725f62675f7472616e73706172656e74223b733a353a22636f6c6f72223b733a31393a226865616465725f626f726465725f636f6c6f72223b733a373a2223653465346534223b733a31373a226865616465725f746578745f636f6c6f72223b733a343a2223323232223b733a31373a226865616465725f6c696e6b5f636f6c6f72223b733a343a2223323232223b733a32333a226865616465725f6c696e6b5f686f7665725f636f6c6f72223b733a373a2223666535303466223b733a32303a226865616465725f646976696465725f7374796c65223b733a373a2264697669646572223b733a32303a226d6f62696c655f6d656e755f62675f636f6c6f72223b733a343a2223323232223b733a32353a226d6f62696c655f6d656e755f646976696465725f636f6c6f72223b733a343a2223343434223b733a32323a226d6f62696c655f6d656e755f746578745f636f6c6f72223b733a373a2223653465346534223b733a32323a226d6f62696c655f6d656e755f6c696e6b5f636f6c6f72223b733a343a2223666666223b733a32383a226d6f62696c655f6d656e755f6c696e6b5f686f7665725f636f6c6f72223b733a373a2223666535303466223b733a31353a226e61765f686f7665725f7374796c65223b733a383a227374616e64617264223b733a31323a226e61765f62675f636f6c6f72223b733a343a2223666666223b733a31343a226e61765f746578745f636f6c6f72223b733a373a2223323532353235223b733a31383a226e61765f62675f686f7665725f636f6c6f72223b733a373a2223663766376637223b733a32303a226e61765f746578745f686f7665725f636f6c6f72223b733a373a2223666535303466223b733a32313a226e61765f73656c65637465645f62675f636f6c6f72223b733a373a2223653365336533223b733a32333a226e61765f73656c65637465645f746578745f636f6c6f72223b733a373a2223666535303466223b733a31373a226e61765f706f696e7465725f636f6c6f72223b733a373a2223303763316236223b733a31353a226e61765f736d5f62675f636f6c6f72223b733a373a2223464646464646223b733a31373a226e61765f736d5f746578745f636f6c6f72223b733a373a2223363636363636223b733a32313a226e61765f736d5f62675f686f7665725f636f6c6f72223b733a373a2223663766376637223b733a32333a226e61765f736d5f746578745f686f7665725f636f6c6f72223b733a373a2223303030303030223b733a32363a226e61765f736d5f73656c65637465645f746578745f636f6c6f72223b733a373a2223303030303030223b733a31313a226e61765f64697669646572223b733a353a22736f6c6964223b733a31373a226e61765f646976696465725f636f6c6f72223b733a373a2223663066306630223b733a32313a226f7665726c61795f6d656e755f62675f636f6c6f72223b733a373a2223666535303466223b733a32333a226f7665726c61795f6d656e755f6c696e6b5f636f6c6f72223b733a373a2223666666666666223b733a32393a226f7665726c61795f6d656e755f6c696e6b5f686f7665725f636f6c6f72223b733a373a2223666535303466223b733a33323a226f7665726c61795f6d656e755f6c696e6b5f686f7665725f62675f636f6c6f72223b733a373a2223666666666666223b733a31383a2270726f6d6f5f6261725f62675f636f6c6f72223b733a373a2223653465346534223b733a32303a2270726f6d6f5f6261725f746578745f636f6c6f72223b733a343a2223323232223b733a31393a2262726561646372756d625f62675f636f6c6f72223b733a373a2223653465346534223b733a32313a2262726561646372756d625f746578745f636f6c6f72223b733a373a2223363636363636223b733a32313a2262726561646372756d625f6c696e6b5f636f6c6f72223b733a373a2223393939393939223b733a32313a22706167655f68656164696e675f62675f636f6c6f72223b733a373a2223663766376637223b733a32333a22706167655f68656164696e675f746578745f636f6c6f72223b733a373a2223323232323232223b733a32333a22706167655f68656164696e675f746578745f616c69676e223b733a343a226c656674223b733a31303a22626f64795f636f6c6f72223b733a373a2223323232323232223b733a31343a22626f64795f616c745f636f6c6f72223b733a373a2223323232323232223b733a31303a226c696e6b5f636f6c6f72223b733a373a2223343434343434223b733a31363a226c696e6b5f686f7665725f636f6c6f72223b733a373a2223393939393939223b733a383a2268315f636f6c6f72223b733a373a2223323232323232223b733a383a2268325f636f6c6f72223b733a373a2223323232323232223b733a383a2268335f636f6c6f72223b733a373a2223323232323232223b733a383a2268345f636f6c6f72223b733a373a2223323232323232223b733a383a2268355f636f6c6f72223b733a373a2223323232323232223b733a383a2268365f636f6c6f72223b733a373a2223323232323232223b733a31363a226f7665726c61795f62675f636f6c6f72223b733a373a2223666535303466223b733a31383a226f7665726c61795f746578745f636f6c6f72223b733a373a2223666666666666223b733a32383a2261727469636c655f7265766965775f6261725f616c745f636f6c6f72223b733a373a2223663766376637223b733a32343a2261727469636c655f7265766965775f6261725f636f6c6f72223b733a373a2223326532653336223b733a32393a2261727469636c655f7265766965775f6261725f746578745f636f6c6f72223b733a343a2223666666223b733a32333a2261727469636c655f6578747261735f62675f636f6c6f72223b733a373a2223663766376637223b733a31393a2261727469636c655f6e705f62675f636f6c6f72223b733a343a2223343434223b733a32313a2261727469636c655f6e705f746578745f636f6c6f72223b733a343a2223666666223b733a31343a22696e7075745f62675f636f6c6f72223b733a373a2223663766376637223b733a31363a22696e7075745f746578745f636f6c6f72223b733a373a2223323232323232223b733a32333a2269636f6e5f636f6e7461696e65725f62675f636f6c6f72223b733a373a2223316463366466223b733a31333a2273665f69636f6e5f636f6c6f72223b733a373a2223316463366466223b733a32393a2269636f6e5f636f6e7461696e65725f686f7665725f62675f636f6c6f72223b733a343a2223323232223b733a31373a2273665f69636f6e5f616c745f636f6c6f72223b733a373a2223666666666666223b733a31393a22626f7865645f636f6e74656e745f636f6c6f72223b733a373a2223303763316236223b733a31353a2273686172655f627574746f6e5f6267223b733a373a2223666535303466223b733a31373a2273686172655f627574746f6e5f74657874223b733a373a2223666666666666223b733a31303a22626f6c645f72705f6267223b733a373a2223653365336533223b733a31323a22626f6c645f72705f74657874223b733a343a2223323232223b733a31363a22626f6c645f72705f686f7665725f6267223b733a373a2223666535303466223b733a31383a22626f6c645f72705f686f7665725f74657874223b733a373a2223666666666666223b733a31353a2274776565745f736c696465725f6267223b733a373a2223316463366466223b733a31373a2274776565745f736c696465725f74657874223b733a373a2223666666666666223b733a31373a2274776565745f736c696465725f6c696e6b223b733a373a2223333339393333223b733a32333a2274776565745f736c696465725f6c696e6b5f686f766572223b733a373a2223666666666666223b733a32313a2274657374696d6f6e69616c5f736c696465725f6267223b733a373a2223316463366466223b733a32333a2274657374696d6f6e69616c5f736c696465725f74657874223b733a373a2223666666666666223b733a31353a22666f6f7465725f62675f636f6c6f72223b733a373a2223323232323232223b733a31373a22666f6f7465725f746578745f636f6c6f72223b733a373a2223636363636363223b733a31373a22666f6f7465725f6c696e6b5f636f6c6f72223b733a373a2223666666666666223b733a32333a22666f6f7465725f6c696e6b5f686f7665725f636f6c6f72223b733a373a2223636363636363223b733a31393a22666f6f7465725f626f726465725f636f6c6f72223b733a373a2223333333333333223b733a31383a22636f707972696768745f62675f636f6c6f72223b733a373a2223323232323232223b733a32303a22636f707972696768745f746578745f636f6c6f72223b733a373a2223393939393939223b733a32303a22636f707972696768745f6c696e6b5f636f6c6f72223b733a373a2223666666666666223b733a32363a22636f707972696768745f6c696e6b5f686f7665725f636f6c6f72223b733a373a2223636363636363223b7d, 'yes'),
(465, 'redux_version_upgraded_from', 0x332e352e372e35, 'yes');
INSERT INTO `wor1677_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES 
(468, 'sf_joyn_options', 0x613a3232343a7b733a31373a22656e61626c655f726573706f6e73697665223b733a313a2231223b733a31333a22736974655f6d61787769647468223b733a343a2231313730223b733a31303a22656e61626c655f72746c223b733a313a2230223b733a31313a22706167655f6c61796f7574223b733a393a2266756c6c7769647468223b733a31383a22656e61626c655f706167655f736861646f77223b733a313a2231223b733a32333a22656e61626c655f6d6f62696c655f74776f5f636c69636b223b733a313a2230223b733a31363a22656e61626c655f6261636b746f746f70223b733a313a2231223b733a31333a22736964656261725f7769647468223b733a383a227374616e64617264223b733a31363a22706167696e6174696f6e5f7374796c65223b733a383a2266732d6172726f77223b733a31393a22656e61626c655f61727469636c657377697065223b733a313a2230223b733a31353a226f6e65706167656e61765f74797065223b733a363a226172726f7773223b733a32303a2264697361626c655f70616765636f6d6d656e7473223b733a313a2231223b733a31383a22656e61626c655f747769747465725f727473223b733a313a2230223b733a32323a22706f73745f6c696e6b735f6d617463685f7468756d62223b733a313a2230223b733a31363a22637573746f6d5f696f735f7469746c65223b733a303a22223b733a31323a227273735f666565645f75726c223b733a31303a223f666565643d72737332223b733a31363a22676f6f676c655f616e616c7974696373223b733a303a22223b733a32353a2264697361626c655f6d6f62696c655f616e696d6174696f6e73223b733a313a2231223b733a32303a22656e61626c655f7374796c657377697463686572223b733a313a2230223b733a31383a22656e61626c655f6d61696e74656e616e6365223b733a313a2230223b733a32313a226d61696e74656e616e63655f6d6f64655f70616765223b733a303a22223b733a31383a22656e61626c655f6d696e5f73637269707473223b733a313a2230223b733a31343a22686f6d655f7072656c6f61646572223b733a313a2230223b733a32333a22656e61626c655f706167655f7472616e736974696f6e73223b733a313a2230223b733a31353a22706167655f7472616e736974696f6e223b733a31303a22636972636c652d626172223b733a31363a223430345f706167655f636f6e74656e74223b733a3137323a22536f7272792062757420776520636f756c646e27742066696e6420746865207061676520796f7520617265206c6f6f6b696e6720666f722e20506c6561736520636865636b20746f206d616b65207375726520796f75277665207479706564207468652055524c20636f72726563746c792e20596f75206d617920616c736f2077616e7420746f2073656172636820666f72207768617420796f7520617265206c6f6f6b696e6720666f722e223b733a31383a223430345f736964656261725f636f6e666967223b733a31333a2272696768742d73696465626172223b733a31363a223430345f6c6566745f73696465626172223b733a393a22736964656261722d31223b733a31373a223430345f72696768745f73696465626172223b733a393a22736964656261722d31223b733a31393a2264697361626c655f736f6369616c5f6d657461223b733a313a2230223b733a32333a22747769747465725f617574686f725f757365726e616d65223b733a303a22223b733a31373a22676f6f676c65706c75735f617574686f72223b733a303a22223b733a31343a2264697361626c655f6c6f76656974223b733a313a2230223b733a31313a226c6f766569745f69636f6e223b733a383a2273732d6865617274223b733a31313a226c6f766569745f74657874223b733a353a224c696b6573223b733a31373a2264697361626c655f736667616c6c657279223b733a313a2230223b733a31323a226c69676874626f785f6e6176223b733a373a2264656661756c74223b733a31353a226c69676874626f785f7468756d6273223b733a313a2231223b733a31333a226c69676874626f785f736b696e223b733a353a226c69676874223b733a31363a226c69676874626f785f73686172696e67223b733a313a2231223b733a32343a226361726f7573656c5f706167696e6174696f6e5370656564223b733a333a22383030223b733a31393a226361726f7573656c5f736c6964655370656564223b733a333a22323030223b733a31373a226361726f7573656c5f6175746f706c6179223b733a313a2230223b733a31393a226361726f7573656c5f706167696e6174696f6e223b733a313a2231223b733a32313a22736c696465725f736c69646573686f775370656564223b733a343a2237303030223b733a32313a22736c696465725f616e696d6174696f6e5370656564223b733a333a22363030223b733a31353a22736c696465725f6175746f706c6179223b733a313a2230223b733a31353a226f7665726c61795f6f706163697479223b733a323a223930223b733a31343a227468756d626e61696c5f74797065223b733a333a22737464223b733a31303a22637573746f6d5f637373223b733a303a22223b733a393a22637573746f6d5f6a73223b733a303a22223b733a32373a22636f6c6f75725f736368656d655f73656c6563745f736368656d65223b693a303b733a31323a227573655f62675f696d616765223b733a313a2230223b733a373a2262675f73697a65223b733a343a226175746f223b733a31353a227072657365745f62675f696d616765223b733a303a22223b733a393a22656e61626c655f7462223b733a313a2230223b733a31343a2274625f6c6566745f636f6e666967223b733a343a2274657874223b733a31323a2274625f6c6566745f74657874223b733a34343a22436f6e74616374207573206f6e2030383030203132332034353637206f7220696e666f406a6f796e2e636f6d223b733a31353a2274625f72696768745f636f6e666967223b733a343a2274657874223b733a31333a2274625f72696768745f74657874223b733a34343a22436f6e74616374207573206f6e2030383030203132332034353637206f7220696e666f406a6f796e2e636f6d223b733a32303a22656e61626c655f737469636b795f746f70626172223b733a313a2230223b733a31333a226865616465725f6c61796f7574223b733a383a226865616465722d34223b733a31363a2266756c6c77696474685f686561646572223b733a313a2230223b733a31383a226865616465725f6c6566745f636f6e666967223b613a323a7b733a373a22656e61626c6564223b613a313a7b733a343a2274657874223b733a31343a22546578742f53686f7274636f6465223b7d733a383a2264697361626c6564223b613a383a7b733a393a226175782d6c696e6b73223b733a393a22417578204c696e6b73223b733a363a22736f6369616c223b733a31323a22536f6369616c2049636f6e73223b733a31323a226f7665726c61792d6d656e75223b733a31323a224f7665726c6179204d656e75223b733a373a22636f6e74616374223b733a373a22436f6e74616374223b733a363a22736561726368223b733a363a22536561726368223b733a343a2263617274223b733a343a2243617274223b733a383a22776973686c697374223b733a383a22576973686c697374223b733a31313a227375706572736561726368223b733a31323a22537570657220536561726368223b7d7d733a31363a226865616465725f6c6566745f74657874223b733a31363a22486561646572206c6566742074657874223b733a31393a226865616465725f72696768745f636f6e666967223b613a323a7b733a373a22656e61626c6564223b613a313a7b733a363a22736f6369616c223b733a31323a22536f6369616c2049636f6e73223b7d733a383a2264697361626c6564223b613a383a7b733a343a2274657874223b733a31343a22546578742f53686f7274636f6465223b733a393a226175782d6c696e6b73223b733a393a22417578204c696e6b73223b733a31323a226f7665726c61792d6d656e75223b733a31323a224f7665726c6179204d656e75223b733a373a22636f6e74616374223b733a373a22436f6e74616374223b733a363a22736561726368223b733a363a22536561726368223b733a343a2263617274223b733a343a2243617274223b733a383a22776973686c697374223b733a383a22576973686c697374223b733a31313a227375706572736561726368223b733a31323a22537570657220536561726368223b7d7d733a31373a226865616465725f72696768745f74657874223b733a31373a224865616465722072696768742074657874223b733a32313a22636f6e746163745f736c6964656f75745f70616765223b733a303a22223b733a383a2273686f775f737562223b733a313a2230223b733a383a227375625f636f6465223b733a303a22223b733a31363a2273686f775f7472616e736c6174696f6e223b733a313a2230223b733a31323a2273686f775f6163636f756e74223b733a313a2231223b733a393a2273686f775f63617274223b733a313a2230223b733a31333a2273686f775f776973686c697374223b733a313a2230223b733a32303a22656e61626c655f6865616465725f736861646f77223b733a313a2230223b733a31383a22656e61626c655f6d696e695f686561646572223b733a313a2231223b733a32353a22656e61626c655f6d696e695f6865616465725f726573697a65223b733a313a2230223b733a31383a226865616465725f7365617263685f74797065223b733a31323a2266732d7365617263682d6f6e223b733a31363a226865616465725f7365617263685f7074223b733a333a22616e79223b733a32303a22766572746963616c5f6865616465725f74657874223b733a3131383a2226636f70793b5b7468652d796561725d204a6f796e20266d6964646f743b204275696c742077697468206c6f7665206279203c6120687265663d27687474703a2f2f7777772e737769667469646561732e6e6574273e53776966742049646561733c2f613e207573696e67205b77702d6c696e6b5d2e223b733a31343a226c6f676f5f6d6178686569676874223b733a333a22313030223b733a31323a226c6f676f5f70616464696e67223b733a303a22223b733a31393a22656e61626c655f6c6f676f5f7461676c696e65223b733a313a2230223b733a393a226c6f676f5f666f6e74223b613a343a7b733a353a22636f6c6f72223b733a343a2223323232223b733a393a22666f6e742d73697a65223b733a343a2232347078223b733a31313a22666f6e742d66616d696c79223b733a343a224c61746f223b733a31313a22666f6e742d776569676874223b733a333a22343030223b7d733a31393a226d6f62696c655f6865616465725f73686f776e223b733a31313a227461626c65742d6c616e64223b733a32303a226d6f62696c655f6865616465725f737469636b79223b733a313a2230223b733a32303a226d6f62696c655f6865616465725f6c61796f7574223b733a393a226c6566742d6c6f676f223b733a31363a226d6f62696c655f6d656e755f74797065223b733a373a226f7665726c6179223b733a31353a226d6f62696c655f746f705f74657874223b733a303a22223b733a31383a226d6f62696c655f73686f775f736561726368223b733a313a2230223b733a32333a226d6f62696c655f73686f775f7472616e736c6174696f6e223b733a313a2230223b733a31363a226d6f62696c655f73686f775f63617274223b733a313a2230223b733a31393a226d6f62696c655f73686f775f6163636f756e74223b733a313a2231223b733a31333a22656e61626c655f666f6f746572223b733a313a2231223b733a32313a22656e61626c655f666f6f7465725f64697669646572223b733a313a2231223b733a31333a22666f6f7465725f6c61796f7574223b733a383a22666f6f7465722d31223b733a31363a22656e61626c655f636f70797269676874223b733a313a2231223b733a32343a22656e61626c655f636f707972696768745f64697669646572223b733a313a2231223b733a32313a22666f6f7465725f636f707972696768745f74657874223b733a3131383a2226636f70793b5b7468652d796561725d204a6f796e20266d6964646f743b204275696c742077697468206c6f7665206279203c6120687265663d27687474703a2f2f7777772e737769667469646561732e6e6574273e53776966742049646561733c2f613e207573696e67205b77702d6c696e6b5d2e223b733a31353a22636f707972696768745f7269676874223b733a343a226d656e75223b733a32373a22666f6f7465725f636f707972696768745f746578745f7269676874223b733a3131383a2226636f70793b5b7468652d796561725d204a6f796e20266d6964646f743b204275696c742077697468206c6f7665206279203c6120687265663d27687474703a2f2f7777772e737769667469646561732e6e6574273e53776966742049646561733c2f613e207573696e67205b77702d6c696e6b5d2e223b733a31333a2273686f775f6261636b6c696e6b223b733a313a2231223b733a393a2273735f656e61626c65223b733a313a2231223b733a393a2273735f6d6f62696c65223b733a313a2231223b733a31313a226669656c64315f74657874223b733a31353a2249276d206c6f6f6b696e6720666f72223b733a31333a226669656c64315f66696c746572223b733a31313a2270726f647563745f636174223b733a31393a226669656c64315f64656661756c745f74657874223b733a373a2270726f64756374223b733a31313a226669656c64325f74657874223b733a393a22696e20612073697a65223b733a31333a226669656c64325f66696c746572223b733a31313a2270726f647563745f636174223b733a31393a226669656c64325f64656661756c745f74657874223b733a343a2273697a65223b733a31313a226669656c64335f74657874223b733a31333a222e2053686f77206d6520746865223b733a31333a226669656c64335f66696c746572223b733a31313a2270726f647563745f636174223b733a31393a226669656c64335f64656661756c745f74657874223b733a363a22636f6c6f7572223b733a31313a226669656c64345f74657874223b733a303a22223b733a31333a226669656c64345f66696c746572223b733a31313a2270726f647563745f636174223b733a31393a226669656c64345f64656661756c745f74657874223b733a303a22223b733a31313a226669656c64355f74657874223b733a303a22223b733a31333a226669656c64355f66696c746572223b733a31313a2270726f647563745f636174223b733a31393a226669656c64355f64656661756c745f74657874223b733a303a22223b733a31313a226669656c64365f74657874223b733a303a22223b733a31333a226669656c64365f66696c746572223b733a31313a2270726f647563745f636174223b733a31393a226669656c64365f64656661756c745f74657874223b733a303a22223b733a31333a2273735f66696e616c5f74657874223b733a363a226974656d732e223b733a31343a2273735f627574746f6e5f74657874223b733a31323a22537570657220536561726368223b733a32333a22656e61626c655f666f6f7465725f70726f6d6f5f626172223b733a313a2230223b733a32313a22666f6f7465725f70726f6d6f5f6261725f74797065223b733a363a22627574746f6e223b733a32313a22666f6f7465725f70726f6d6f5f6261725f74657874223b733a33313a22456e74657220796f75722070726f6d6f20626172207465787420686572652e223b733a32393a22666f6f7465725f70726f6d6f5f6261725f627574746f6e5f636f6c6f72223b733a363a22616363656e74223b733a32383a22666f6f7465725f70726f6d6f5f6261725f627574746f6e5f74657874223b733a31323a22427574746f6e20546578742e223b733a32383a22666f6f7465725f70726f6d6f5f6261725f627574746f6e5f6c696e6b223b733a373a22687474703a2f2f223b733a33303a22666f6f7465725f70726f6d6f5f6261725f627574746f6e5f746172676574223b733a353a225f73656c66223b733a393a22626f64795f666f6e74223b613a343a7b733a393a22666f6e742d73697a65223b733a343a2231347078223b733a31313a226c696e652d686569676874223b733a343a2232307078223b733a31313a22666f6e742d66616d696c79223b733a31353a22536f757263652053616e732050726f223b733a31313a22666f6e742d776569676874223b733a333a22343030223b7d733a373a2268315f666f6e74223b613a343a7b733a393a22666f6e742d73697a65223b733a343a2232347078223b733a31313a226c696e652d686569676874223b733a343a2233347078223b733a31313a22666f6e742d66616d696c79223b733a343a224c61746f223b733a31313a22666f6e742d776569676874223b733a333a22343030223b7d733a373a2268325f666f6e74223b613a343a7b733a393a22666f6e742d73697a65223b733a343a2232307078223b733a31313a226c696e652d686569676874223b733a343a2233307078223b733a31313a22666f6e742d66616d696c79223b733a343a224c61746f223b733a31313a22666f6e742d776569676874223b733a333a22343030223b7d733a373a2268335f666f6e74223b613a343a7b733a393a22666f6e742d73697a65223b733a343a2231387078223b733a31313a226c696e652d686569676874223b733a343a2232347078223b733a31313a22666f6e742d66616d696c79223b733a343a224c61746f223b733a31313a22666f6e742d776569676874223b733a333a22343030223b7d733a373a2268345f666f6e74223b613a343a7b733a393a22666f6e742d73697a65223b733a343a2231367078223b733a31313a226c696e652d686569676874223b733a343a2232307078223b733a31313a22666f6e742d66616d696c79223b733a343a224c61746f223b733a31313a22666f6e742d776569676874223b733a333a22343030223b7d733a373a2268355f666f6e74223b613a343a7b733a393a22666f6e742d73697a65223b733a343a2231347078223b733a31313a226c696e652d686569676874223b733a343a2231387078223b733a31313a22666f6e742d66616d696c79223b733a343a224c61746f223b733a31313a22666f6e742d776569676874223b733a333a22343030223b7d733a373a2268365f666f6e74223b613a343a7b733a393a22666f6e742d73697a65223b733a343a2231327078223b733a31313a226c696e652d686569676874223b733a343a2231367078223b733a31313a22666f6e742d66616d696c79223b733a343a224c61746f223b733a31313a22666f6e742d776569676874223b733a333a22343030223b7d733a393a226d656e755f666f6e74223b613a333a7b733a393a22666f6e742d73697a65223b733a343a2231387078223b733a31313a22666f6e742d66616d696c79223b733a31353a22536f757263652053616e732050726f223b733a31313a22666f6e742d776569676874223b733a333a22343030223b7d733a32353a2264656661756c745f73686f775f706167655f68656164696e67223b733a313a2231223b733a32323a2264656661756c745f736964656261725f636f6e666967223b733a31313a226e6f2d7369646562617273223b733a32303a2264656661756c745f6c6566745f73696465626172223b733a393a22736964656261722d31223b733a32313a2264656661756c745f72696768745f73696465626172223b733a393a22736964656261722d31223b733a32373a2264656661756c745f706f73745f736964656261725f636f6e666967223b733a31313a226e6f2d7369646562617273223b733a32353a2264656661756c745f706f73745f6c6566745f73696465626172223b733a393a22736964656261722d31223b733a32363a2264656661756c745f706f73745f72696768745f73696465626172223b733a393a22736964656261722d31223b733a32323a2264656661756c745f696e636c7564655f617574686f72223b733a313a2231223b733a32323a2264656661756c745f696e636c7564655f736f6369616c223b733a313a2231223b733a32333a2264656661756c745f696e636c7564655f72656c61746564223b733a313a2231223b733a31393a2264656661756c745f7468756d625f6d65646961223b733a353a22696d616765223b733a32303a2264656661756c745f64657461696c5f6d65646961223b733a353a22696d616765223b733a32323a22617263686976655f736964656261725f636f6e666967223b733a31333a2272696768742d73696465626172223b733a32303a22617263686976655f736964656261725f6c656674223b733a393a22736964656261722d31223b733a32313a22617263686976655f736964656261725f7269676874223b733a393a22736964656261722d31223b733a32303a22617263686976655f646973706c61795f74797065223b733a373a226d61736f6e7279223b733a32333a22617263686976655f646973706c61795f636f6c756d6e73223b733a313a2232223b733a32323a22617263686976655f636f6e74656e745f6f7574707574223b733a373a2265786365727074223b733a33303a22706f7274666f6c696f5f617263686976655f646973706c61795f74797065223b733a383a227374616e64617264223b733a32353a22706f7274666f6c696f5f617263686976655f636f6c756d6e73223b733a313a2234223b733a31373a2262705f736964656261725f636f6e666967223b733a31333a2272696768742d73696465626172223b733a31353a2262705f736964656261725f6c656674223b733a393a22736964656261722d31223b733a31363a2262705f736964656261725f7269676874223b733a393a22736964656261722d31223b733a31373a2262625f736964656261725f636f6e666967223b733a31333a2272696768742d73696465626172223b733a31353a2262625f736964656261725f6c656674223b733a393a22736964656261722d31223b733a31363a2262625f736964656261725f7269676874223b733a393a22736964656261722d31223b733a393a22626c6f675f70616765223b733a303a22223b733a31333a2273696e676c655f617574686f72223b733a313a2230223b733a31323a2272656d6f76655f6461746573223b733a313a2230223b733a31343a22706f7274666f6c696f5f70616765223b733a303a22223b733a32363a22656e61626c655f63617465676f72795f6e617669676174696f6e223b733a313a2230223b733a32363a2272656c617465645f70726f6a656374735f66756c6c7769647468223b733a313a2231223b733a32343a2272656c617465645f70726f6a656374735f636f6c756d6e73223b733a313a2233223b733a31363a2274657374696d6f6e69616c5f70616765223b733a303a22223b733a31393a22656e61626c655f636174616c6f675f6d6f6465223b733a313a2230223b733a31373a2270726f64756374735f7065725f70616765223b733a323a223234223b733a393a226e65775f6261646765223b733a313a2237223b733a32353a22636865636b6f75745f6e65775f6163636f756e745f74657874223b733a3230333a224372656174696e6720616e206163636f756e742077697468204a6f796e20697320717569636b20616e6420656173792c20616e642077696c6c20616c6c6f7720796f7520746f206d6f7665207468726f756768206f757220636865636b6f757420717569636b65722e20596f752063616e20616c736f2073746f7265206d756c7469706c65207368697070696e67206164647265737365732c206761696e2061636365737320746f20796f7572206f7264657220686973746f72792c20616e64206d756368206d6f72652e223b733a31333a2268656c705f6261725f74657874223b733a35313a224e6565642068656c703f2043616c6c20637573746f6d6572207365727669636573206f6e20303830302031323320343536372e223b733a31313a22656d61696c5f6d6f64616c223b733a38393a22456e74657220796f757220636f6e746163742064657461696c73206f7220656d61696c20666f726d2073686f7274636f646520686572652e2028546578742f48544d4c2f53686f7274636f646573206163636570746564292e223b733a31343a227368697070696e675f6d6f64616c223b733a37303a22456e74657220796f7572207368697070696e6720696e666f726d6174696f6e20686572652e2028546578742f48544d4c2f53686f7274636f646573206163636570746564292e223b733a31333a2272657475726e735f6d6f64616c223b733a38323a22456e74657220796f75722072657475726e7320616e642065786368616e676520696e666f726d6174696f6e20686572652e2028546578742f48544d4c2f53686f7274636f646573206163636570746564292e223b733a31303a22666171735f6d6f64616c223b733a35343a22456e74657220796f7572206661717320686572652e2028546578742f48544d4c2f53686f7274636f646573206163636570746564292e223b733a31343a22666565646261636b5f6d6f64616c223b733a37323a22456e74657220796f757220666565646261636b206d6f64616c20636f6e74656e7420686572652e2028546578742f48544d4c2f53686f7274636f646573206163636570746564292e223b733a32303a2270726f647563745f646973706c61795f74797065223b733a383a227374616e64617264223b733a32333a2270726f647563745f646973706c61795f636f6c756d6e73223b733a313a2234223b733a32333a2270726f647563745f646973706c61795f67757474657273223b733a313a2231223b733a32353a2270726f647563745f646973706c61795f66756c6c7769647468223b733a313a2230223b733a31363a2270726f647563745f71765f686f766572223b733a313a2231223b733a31343a2270726f647563745f726174696e67223b733a313a2231223b733a31343a2270726f647563745f62757962746e223b733a313a2231223b733a31383a22776f6f5f736964656261725f636f6e666967223b733a31313a226e6f2d7369646562617273223b733a31363a22776f6f5f6c6566745f73696465626172223b733a31393a22776f6f636f6d6d657263652d73696465626172223b733a31373a22776f6f5f72696768745f73696465626172223b733a31393a22776f6f636f6d6d657263652d73696465626172223b733a32313a22776f6f5f73686f775f706167655f68656164696e67223b733a313a2231223b733a32323a22776f6f5f706167655f68656164696e675f7374796c65223b733a383a227374616e64617264223b733a32373a22776f6f5f706167655f68656164696e675f746578745f7374796c65223b733a353a226c69676874223b733a31393a22656e61626c655f64656661756c745f74616273223b733a313a2230223b733a31393a22656e61626c655f70726f647563745f7a6f6f6d223b733a313a2230223b733a31373a2270726f647563745f7a6f6f6d5f74797065223b733a353a22696e6e6572223b733a33303a2264656661756c745f70726f647563745f736964656261725f636f6e666967223b733a31313a226e6f2d7369646562617273223b733a32383a2264656661756c745f70726f647563745f6c6566745f73696465626172223b733a31393a22776f6f636f6d6d657263652d73696465626172223b733a32393a2264656661756c745f70726f647563745f72696768745f73696465626172223b733a31393a22776f6f636f6d6d657263652d73696465626172223b733a31363a22747769747465725f757365726e616d65223b733a303a22223b733a31373a2266616365626f6f6b5f706167655f75726c223b733a303a22223b733a31373a226472696262626c655f757365726e616d65223b733a303a22223b733a31343a2276696d656f5f757365726e616d65223b733a303a22223b733a31353a2274756d626c725f757365726e616d65223b733a303a22223b733a31343a22736b7970655f757365726e616d65223b733a303a22223b733a31373a226c696e6b6564696e5f706167655f75726c223b733a303a22223b733a31393a22676f6f676c65706c75735f706167655f75726c223b733a303a22223b733a31353a22666c69636b725f706167655f75726c223b733a303a22223b733a31313a22796f75747562655f75726c223b733a303a22223b733a31383a2270696e7465726573745f757365726e616d65223b733a303a22223b733a31343a22666f75727371756172655f75726c223b733a303a22223b733a31383a22696e7374616772616d5f757365726e616d65223b733a303a22223b733a31303a226769746875625f75726c223b733a303a22223b733a383a2278696e675f75726c223b733a303a22223b733a31313a22626568616e63655f75726c223b733a303a22223b733a31343a2264657669616e746172745f75726c223b733a303a22223b733a31343a22736f756e64636c6f75645f75726c223b733a303a22223b733a383a2279656c705f75726c223b733a303a22223b733a363a22766b5f75726c223b733a303a22223b733a31303a227477697463685f75726c223b733a303a22223b733a373a227273735f75726c223b733a303a22223b7d, 'yes'),
(469, 'sf_joyn_options-transients', 0x613a323a7b733a31343a226368616e6765645f76616c756573223b613a303a7b7d733a393a226c6173745f73617665223b693a313436343137383639353b7d, 'yes'),
(589, 'cpotheme_settings', 0x613a383a7b733a31393a22696e74756974696f6e70726f5f77697a617264223b733a393a226469736d6973736564223b733a32373a226c6963656e73655f696e74756974696f6e70726f5f737461747573223b733a373a22696e76616c6964223b733a32303a22696e74756974696f6e70726f5f6c6963656e7365223b733a393a226469736d6973736564223b733a31303a22686f6d655f706f737473223b623a303b733a31373a2267656e6572616c5f746578747469746c65223b623a303b733a31303a22686f6d655f6f72646572223b733a34333a227461676c696e652c736c696465722c66656174757265732c66656174757265642c706f7274666f6c696f2c223b733a31323a22686f6d655f7461676c696e65223b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b733a31323a2267656e6572616c5f6c6f676f223b733a38313a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31302f6c6f676f2d52532e706e67223b7d, 'yes'),
(474, 'theme_mods_joyn', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a333a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313436343230393433393b733a343a2264617461223b613a31333a7b733a31393a2277705f696e6163746976655f77696467657473223b613a343a7b693a303b733a31343a22726563656e742d706f7374732d32223b693a313b733a31373a22726563656e742d636f6d6d656e74732d32223b693a323b733a363a226d6574612d32223b693a333b733a31323a22717472616e736c6174652d32223b7d733a393a22736964656261722d31223b613a333a7b693a303b733a383a227365617263682d32223b693a313b733a31303a2261726368697665732d32223b693a323b733a31323a2263617465676f726965732d32223b7d733a393a22736964656261722d32223b613a303a7b7d733a393a22736964656261722d33223b613a303a7b7d733a393a22736964656261722d34223b4e3b733a393a22736964656261722d35223b4e3b733a393a22736964656261722d36223b4e3b733a393a22736964656261722d37223b4e3b733a393a22736964656261722d38223b4e3b733a31353a22666f6f7465722d636f6c756d6e2d31223b4e3b733a31353a22666f6f7465722d636f6c756d6e2d32223b4e3b733a31353a22666f6f7465722d636f6c756d6e2d33223b4e3b733a31353a22666f6f7465722d636f6c756d6e2d34223b4e3b7d7d7d, 'yes'),
(700, 'theme_mods_responsive', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a393a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a31313a22666f6f7465725f6d656e75223b693a303b733a383a22746f705f6d656e75223b693a303b733a393a226d61696e5f6d656e75223b693a323b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313436383236353030383b733a343a2264617461223b613a31333a7b733a31393a2277705f696e6163746976655f77696467657473223b613a343a7b693a303b733a31343a22726563656e742d706f7374732d32223b693a313b733a31373a22726563656e742d636f6d6d656e74732d32223b693a323b733a363a226d6574612d32223b693a333b733a31323a22717472616e736c6174652d32223b7d733a31323a226d61696e2d73696465626172223b613a333a7b693a303b733a383a227365617263682d32223b693a313b733a31303a2261726368697665732d32223b693a323b733a31323a2263617465676f726965732d32223b7d733a31333a2272696768742d73696465626172223b613a303a7b7d733a31323a226c6566742d73696465626172223b613a303a7b7d733a31373a226c6566742d736964656261722d68616c66223b4e3b733a31383a2272696768742d736964656261722d68616c66223b4e3b733a31333a22686f6d652d7769646765742d31223b4e3b733a31333a22686f6d652d7769646765742d32223b4e3b733a31333a22686f6d652d7769646765742d33223b4e3b733a31343a2267616c6c6572792d776964676574223b4e3b733a31353a22636f6c6f70686f6e2d776964676574223b4e3b733a31303a22746f702d776964676574223b4e3b733a31333a22666f6f7465722d776964676574223b4e3b7d7d7d, 'yes'),
(594, 'theme_mods_intuition_pro', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a393a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a31313a22666f6f7465725f6d656e75223b693a303b733a383a22746f705f6d656e75223b693a303b733a393a226d61696e5f6d656e75223b693a323b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313437373531393536373b733a343a2264617461223b613a363a7b733a31393a2277705f696e6163746976655f77696467657473223b613a343a7b693a303b733a31303a2261726368697665732d32223b693a313b733a31303a2263616c656e6461722d32223b693a323b733a363a22746578742d32223b693a333b733a363a22746578742d33223b7d733a31353a227072696d6172792d77696467657473223b613a303a7b7d733a31373a227365636f6e646172792d77696467657473223b613a303a7b7d733a31363a22666f6f7465722d776964676574732d31223b613a303a7b7d733a31363a22666f6f7465722d776964676574732d32223b4e3b733a31363a22666f6f7465722d776964676574732d33223b4e3b7d7d7d, 'yes'),
(707, 'theme_mods_responsive-child', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a393a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a31313a22666f6f7465725f6d656e75223b693a303b733a383a22746f705f6d656e75223b693a303b733a393a226d61696e5f6d656e75223b693a323b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313436353233343536343b733a343a2264617461223b613a31333a7b733a31393a2277705f696e6163746976655f77696467657473223b613a343a7b693a303b733a31343a22726563656e742d706f7374732d32223b693a313b733a31373a22726563656e742d636f6d6d656e74732d32223b693a323b733a363a226d6574612d32223b693a333b733a31323a22717472616e736c6174652d32223b7d733a31323a226d61696e2d73696465626172223b613a333a7b693a303b733a383a227365617263682d32223b693a313b733a31303a2261726368697665732d32223b693a323b733a31323a2263617465676f726965732d32223b7d733a31333a2272696768742d73696465626172223b613a303a7b7d733a31323a226c6566742d73696465626172223b613a303a7b7d733a31373a226c6566742d736964656261722d68616c66223b4e3b733a31383a2272696768742d736964656261722d68616c66223b4e3b733a31333a22686f6d652d7769646765742d31223b4e3b733a31333a22686f6d652d7769646765742d32223b4e3b733a31333a22686f6d652d7769646765742d33223b4e3b733a31343a2267616c6c6572792d776964676574223b4e3b733a31353a22636f6c6f70686f6e2d776964676574223b4e3b733a31303a22746f702d776964676574223b4e3b733a31333a22666f6f7465722d776964676574223b4e3b7d7d7d, 'yes'),
(587, 'theme_mods_intuition_pro-child', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a393a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a393a226d61696e5f6d656e75223b693a323b733a383a22746f705f6d656e75223b693a33363b733a31313a22666f6f7465725f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b7d733a31383a22637573746f6d5f6373735f706f73745f6964223b693a2d313b7d, 'yes'),
(701, 'responsive_theme_options', 0x613a33343a7b733a31303a2262726561646372756d62223b623a303b733a31303a226374615f627574746f6e223b623a303b733a31323a226d696e69666965645f637373223b623a303b733a31303a2266726f6e745f70616765223b693a313b733a31333a22686f6d655f686561646c696e65223b4e3b733a31363a22686f6d655f737562686561646c696e65223b4e3b733a31373a22686f6d655f636f6e74656e745f61726561223b4e3b733a383a226374615f74657874223b4e3b733a373a226374615f75726c223b4e3b733a31363a2266656174757265645f636f6e74656e74223b4e3b733a32343a22676f6f676c655f736974655f766572696669636174696f6e223b733a303a22223b733a32323a2262696e675f736974655f766572696669636174696f6e223b733a303a22223b733a32333a227961686f6f5f736974655f766572696669636174696f6e223b733a303a22223b733a32333a22736974655f737461746973746963735f747261636b6572223b733a303a22223b733a31313a22747769747465725f756964223b733a303a22223b733a31323a2266616365626f6f6b5f756964223b733a303a22223b733a31323a226c696e6b6564696e5f756964223b733a303a22223b733a31313a22796f75747562655f756964223b733a303a22223b733a31313a227374756d626c655f756964223b733a303a22223b733a373a227273735f756964223b733a303a22223b733a31353a22676f6f676c655f706c75735f756964223b733a303a22223b733a31333a22696e7374616772616d5f756964223b733a303a22223b733a31333a2270696e7465726573745f756964223b733a303a22223b733a383a2279656c705f756964223b733a303a22223b733a393a2276696d656f5f756964223b733a303a22223b733a31343a22666f75727371756172655f756964223b733a303a22223b733a32313a22726573706f6e736976655f696e6c696e655f637373223b733a303a22223b733a32353a22726573706f6e736976655f696e6c696e655f6a735f68656164223b733a303a22223b733a33313a22726573706f6e736976655f696e6c696e655f6373735f6a735f666f6f746572223b733a303a22223b733a32363a227374617469635f706167655f6c61796f75745f64656661756c74223b733a373a2264656661756c74223b733a32363a2273696e676c655f706f73745f6c61796f75745f64656661756c74223b733a373a2264656661756c74223b733a33313a22626c6f675f706f7374735f696e6465785f6c61796f75745f64656661756c74223b733a373a2264656661756c74223b733a31343a22676f6f676c65706c75735f756964223b733a303a22223b733a31353a227374756d626c6575706f6e5f756964223b733a303a22223b7d, 'yes'),
(1118, 'auto_core_update_notified', 0x613a343a7b733a343a2274797065223b733a373a2273756363657373223b733a353a22656d61696c223b733a31383a22696374406a616e65676f6f64616c6c2e6265223b733a373a2276657273696f6e223b733a353a22342e372e35223b733a393a2274696d657374616d70223b693a313439363330383030333b7d, 'no'),
(2492, 'db_upgraded', '', 'yes'),
(2601, 'theme_mods_blankslate', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a393a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a31313a22666f6f7465725f6d656e75223b693a303b733a383a22746f705f6d656e75223b693a303b733a393a226d61696e5f6d656e75223b693a323b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313437313830393833343b733a343a2264617461223b613a323a7b733a31393a2277705f696e6163746976655f77696467657473223b613a343a7b693a303b733a31343a22726563656e742d706f7374732d32223b693a313b733a31373a22726563656e742d636f6d6d656e74732d32223b693a323b733a363a226d6574612d32223b693a333b733a31323a22717472616e736c6174652d32223b7d733a31393a227072696d6172792d7769646765742d61726561223b613a333a7b693a303b733a383a227365617263682d32223b693a313b733a31303a2261726368697665732d32223b693a323b733a31323a2263617465676f726965732d32223b7d7d7d7d, 'yes'),
(2656, 'theme_mods_adamos-child', 0x613a363a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a31303a7b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a31313a22666f6f7465725f6d656e75223b693a303b733a383a22746f705f6d656e75223b693a303b733a393a226d61696e5f6d656e75223b693a323b733a373a227072696d617279223b693a323b733a393a227365636f6e64617279223b693a33363b7d733a31313a226164616d6f735f6c6f676f223b733a38313a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31302f6c6f676f2d52532e706e67223b733a31343a22686964655f636f70797269676874223b733a313a2231223b733a31393a22686964655f666f6f7465725f77696467657473223b733a313a2231223b733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313437373631303030323b733a343a2264617461223b613a373a7b733a31393a2277705f696e6163746976655f77696467657473223b613a343a7b693a303b733a31303a2261726368697665732d32223b693a313b733a363a22746578742d32223b693a323b733a363a22746578742d33223b693a333b733a31303a2263616c656e6461722d32223b7d733a393a22736964656261722d31223b613a303a7b7d733a393a22736964656261722d32223b613a303a7b7d733a393a22736964656261722d33223b613a303a7b7d733a31313a226c6566745f636f6c756d6e223b613a303a7b7d733a31333a2263656e7465725f636f6c756d6e223b613a303a7b7d733a31323a2272696768745f636f6c756d6e223b613a303a7b7d7d7d7d, 'yes'),
(6721, 'theme_mods_Explorable', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a31303a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a393a226d61696e5f6d656e75223b693a323b733a383a22746f705f6d656e75223b693a33363b733a31313a22666f6f7465725f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b733a31323a227072696d6172792d6d656e75223b693a323b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313437373935303936353b733a343a2264617461223b613a353a7b733a31393a2277705f696e6163746976655f77696467657473223b613a303a7b7d733a393a22736964656261722d31223b613a313a7b693a303b733a31303a2261726368697665732d32223b7d733a393a22736964656261722d32223b613a313a7b693a303b733a363a22746578742d32223b7d733a393a22736964656261722d33223b613a313a7b693a303b733a363a22746578742d33223b7d733a393a22736964656261722d34223b613a313a7b693a303b733a31303a2263616c656e6461722d32223b7d7d7d7d, 'yes'),
(2602, 'theme_mods_blankslate-child', 0x613a333a7b693a303b623a303b733a31383a226e61765f6d656e755f6c6f636174696f6e73223b613a393a7b733a373a227072696d617279223b693a303b733a363a22736f6369616c223b693a303b733a31353a226d61696e5f6e617669676174696f6e223b693a323b733a31323a226f7665726c61795f6d656e75223b693a303b733a31313a226d6f62696c655f6d656e75223b693a303b733a31323a22746f705f6261725f6d656e75223b693a303b733a31313a22666f6f7465725f6d656e75223b693a303b733a383a22746f705f6d656e75223b693a303b733a393a226d61696e5f6d656e75223b693a323b7d733a31363a2273696465626172735f77696467657473223b613a323a7b733a343a2274696d65223b693a313437313837303032333b733a343a2264617461223b613a323a7b733a31393a2277705f696e6163746976655f77696467657473223b613a343a7b693a303b733a31343a22726563656e742d706f7374732d32223b693a313b733a31373a22726563656e742d636f6d6d656e74732d32223b693a323b733a363a226d6574612d32223b693a333b733a31323a22717472616e736c6174652d32223b7d733a31393a227072696d6172792d7769646765742d61726561223b613a333a7b693a303b733a383a227365617263682d32223b693a313b733a31303a2261726368697665732d32223b693a323b733a31323a2263617465676f726965732d32223b7d7d7d7d, 'yes'),
(9815, 'bodhi_svgs_settings', 0x613a333a7b733a383a227265737472696374223b733a323a226f6e223b733a31343a226a735f666f6f745f63686f696365223b733a323a226f6e223b733a31303a226373735f746172676574223b733a303a22223b7d, 'yes'),
(43688, '_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', 0x31343936333038323838, 'no'),
(43694, '_transient_timeout_dash_5f25301ca0145abac6dfc3a0899dc43b', 0x31343936333531343931, 'no'),
(43695, '_transient_dash_5f25301ca0145abac6dfc3a0899dc43b', 0x3c64697620636c6173733d227273732d776964676574223e3c756c3e3c6c693e3c6120636c6173733d277273737769646765742720687265663d2768747470733a2f2f776f726470726573732e6f72672f6e6577732f323031372f30352f776f726470726573732d342d382d72656c656173652d63616e6469646174652f273e576f7264507265737320342e382052656c656173652043616e6469646174653c2f613e203c7370616e20636c6173733d227273732d64617465223e32352f30352f323031373c2f7370616e3e3c64697620636c6173733d2272737353756d6d617279223e5468652072656c656173652063616e64696461746520666f7220576f7264507265737320342e38206973206e6f7720617661696c61626c652e205243206d65616e73207765207468696e6b207765e28099726520646f6e652c206275742077697468206d696c6c696f6e73206f6620757365727320616e642074686f7573616e6473206f6620706c7567696e7320616e64207468656d65732c206974e280997320706f737369626c65207765e280997665206d697373656420736f6d657468696e672e20576520686f706520746f207368697020576f7264507265737320342e38206f6e2054687572736461792c204a756e6520382c20627574207765206e65656420796f75722068656c7020746f206765742074686572652e20496620796f7520686176656ee28099742074657374656420342e38207965742c205b2668656c6c69703b5d3c2f6469763e3c2f6c693e3c2f756c3e3c2f6469763e3c64697620636c6173733d227273732d776964676574223e3c756c3e3c6c693e3c6120636c6173733d277273737769646765742720687265663d2768747470733a2f2f777074617665726e2e636f6d2f77707765656b6c792d657069736f64652d3237352d7468652d6a6176617363726970742d6672616d65776f726b2d7261626269742d686f6c65273e575054617665726e3a2057505765656b6c7920457069736f64652032373520e2809320546865204a617661536372697074204672616d65776f726b2052616262697420486f6c653c2f613e3c2f6c693e3c6c693e3c6120636c6173733d277273737769646765742720687265663d2768747470733a2f2f777074617665726e2e636f6d2f77702d636c692d312d322d302d72656c65617365642d70726f6a6563742d756e7665696c732d6e65772d6c6f676f273e575054617665726e3a2057502d434c4920312e322e302052656c65617365642c2050726f6a65637420556e7665696c73204e6577204c6f676f3c2f613e3c2f6c693e3c6c693e3c6120636c6173733d277273737769646765742720687265663d2768747470733a2f2f777074617665726e2e636f6d2f706f64732d322d372d626574612d696e74726f64756365732d666c657869626c652d72656c6174696f6e73686970732d72657772697465732d6669656c64732d696e2d6a617661736372697074273e575054617665726e3a20506f647320322e37204265746120496e74726f647563657320466c657869626c652052656c6174696f6e73686970732c205265777269746573204669656c647320696e204a6176615363726970743c2f613e3c2f6c693e3c2f756c3e3c2f6469763e3c64697620636c6173733d227273732d776964676574223e3c756c3e3c6c6920636c6173733d2264617368626f6172642d6e6577732d706c7567696e223e3c7370616e3e506f70756c617220506c7567696e3a3c2f7370616e3e204a65747061636b20627920576f726450726573732e636f6d266e6273703b3c6120687265663d22706c7567696e2d696e7374616c6c2e7068703f7461623d706c7567696e2d696e666f726d6174696f6e26616d703b706c7567696e3d6a65747061636b26616d703b5f77706e6f6e63653d3633613566306337616126616d703b54425f696672616d653d7472756526616d703b77696474683d36303026616d703b6865696768743d3830302220636c6173733d22746869636b626f78206f70656e2d706c7567696e2d64657461696c732d6d6f64616c2220617269612d6c6162656c3d22496e7374616c6c204a65747061636b20627920576f726450726573732e636f6d223e28496e7374616c6c293c2f613e3c2f6c693e3c2f756c3e3c2f6469763e, 'no'),
(2487, 'backwpup_messages', 0x613a313a7b733a373a2275706461746564223b613a313a7b693a303b733a32383a224a6f6220224d616e75616c206261636b75702220737461727465642e223b7d7d, 'no'),
(30332, '_site_transient_timeout_browser_4130101fe09bf8ad32e702450ff42e8e', 0x31343932333730343033, 'no'),
(30333, '_site_transient_browser_4130101fe09bf8ad32e702450ff42e8e', 0x613a393a7b733a383a22706c6174666f726d223b733a373a2257696e646f7773223b733a343a226e616d65223b733a363a224368726f6d65223b733a373a2276657273696f6e223b733a31333a2235372e302e323938372e313333223b733a31303a227570646174655f75726c223b733a32383a22687474703a2f2f7777772e676f6f676c652e636f6d2f6368726f6d65223b733a373a22696d675f737263223b733a34393a22687474703a2f2f732e776f726470726573732e6f72672f696d616765732f62726f77736572732f6368726f6d652e706e67223b733a31313a22696d675f7372635f73736c223b733a34383a2268747470733a2f2f776f726470726573732e6f72672f696d616765732f62726f77736572732f6368726f6d652e706e67223b733a31353a2263757272656e745f76657273696f6e223b733a323a223138223b733a373a2275706772616465223b623a303b733a383a22696e736563757265223b623a303b7d, 'no'),
(25497, '_site_transient_timeout_popular_importers_b6b79a694bfdf061aab5ef0f2fb81514', 0x31343837373230363436, 'no'),
(25498, '_site_transient_popular_importers_b6b79a694bfdf061aab5ef0f2fb81514', 0x613a323a7b733a393a22696d706f7274657273223b613a383a7b733a373a22626c6f67676572223b613a343a7b733a343a226e616d65223b733a373a22426c6f67676572223b733a31313a226465736372697074696f6e223b733a35343a22496d706f727420706f7374732c20636f6d6d656e74732c20616e642075736572732066726f6d206120426c6f6767657220626c6f672e223b733a31313a22706c7567696e2d736c7567223b733a31363a22626c6f676765722d696d706f72746572223b733a31313a22696d706f727465722d6964223b733a373a22626c6f67676572223b7d733a393a22777063617432746167223b613a343a7b733a343a226e616d65223b733a32393a2243617465676f7269657320616e64205461677320436f6e766572746572223b733a31313a226465736372697074696f6e223b733a37313a22436f6e76657274206578697374696e672063617465676f7269657320746f2074616773206f72207461677320746f2063617465676f726965732c2073656c6563746976656c792e223b733a31313a22706c7567696e2d736c7567223b733a31383a227770636174327461672d696d706f72746572223b733a31313a22696d706f727465722d6964223b733a31303a2277702d63617432746167223b7d733a31313a226c6976656a6f75726e616c223b613a343a7b733a343a226e616d65223b733a31313a224c6976654a6f75726e616c223b733a31313a226465736372697074696f6e223b733a34363a22496d706f727420706f7374732066726f6d204c6976654a6f75726e616c207573696e67207468656972204150492e223b733a31313a22706c7567696e2d736c7567223b733a32303a226c6976656a6f75726e616c2d696d706f72746572223b733a31313a22696d706f727465722d6964223b733a31313a226c6976656a6f75726e616c223b7d733a31313a226d6f7661626c6574797065223b613a343a7b733a343a226e616d65223b733a32343a224d6f7661626c65205479706520616e642054797065506164223b733a31313a226465736372697074696f6e223b733a36323a22496d706f727420706f73747320616e6420636f6d6d656e74732066726f6d2061204d6f7661626c652054797065206f72205479706550616420626c6f672e223b733a31313a22706c7567696e2d736c7567223b733a32303a226d6f7661626c65747970652d696d706f72746572223b733a31313a22696d706f727465722d6964223b733a323a226d74223b7d733a343a226f706d6c223b613a343a7b733a343a226e616d65223b733a383a22426c6f67726f6c6c223b733a31313a226465736372697074696f6e223b733a32383a22496d706f7274206c696e6b7320696e204f504d4c20666f726d61742e223b733a31313a22706c7567696e2d736c7567223b733a31333a226f706d6c2d696d706f72746572223b733a31313a22696d706f727465722d6964223b733a343a226f706d6c223b7d733a333a22727373223b613a343a7b733a343a226e616d65223b733a333a22525353223b733a31313a226465736372697074696f6e223b733a33303a22496d706f727420706f7374732066726f6d20616e2052535320666565642e223b733a31313a22706c7567696e2d736c7567223b733a31323a227273732d696d706f72746572223b733a31313a22696d706f727465722d6964223b733a333a22727373223b7d733a363a2274756d626c72223b613a343a7b733a343a226e616d65223b733a363a2254756d626c72223b733a31313a226465736372697074696f6e223b733a35333a22496d706f727420706f7374732026616d703b206d656469612066726f6d2054756d626c72207573696e67207468656972204150492e223b733a31313a22706c7567696e2d736c7567223b733a31353a2274756d626c722d696d706f72746572223b733a31313a22696d706f727465722d6964223b733a363a2274756d626c72223b7d733a393a22776f72647072657373223b613a343a7b733a343a226e616d65223b733a393a22576f72645072657373223b733a31313a226465736372697074696f6e223b733a39363a22496d706f727420706f7374732c2070616765732c20636f6d6d656e74732c20637573746f6d206669656c64732c2063617465676f726965732c20616e6420746167732066726f6d206120576f72645072657373206578706f72742066696c652e223b733a31313a22706c7567696e2d736c7567223b733a31383a22776f726470726573732d696d706f72746572223b733a31313a22696d706f727465722d6964223b733a393a22776f72647072657373223b7d7d733a31303a227472616e736c61746564223b623a303b7d, 'no'),
(25472, '_site_transient_timeout_browser_754cdcc1e6416d7a56262cf3d275472d', 0x31343838313532363035, 'no'),
(25473, '_site_transient_browser_754cdcc1e6416d7a56262cf3d275472d', 0x613a393a7b733a383a22706c6174666f726d223b733a373a2257696e646f7773223b733a343a226e616d65223b733a363a224368726f6d65223b733a373a2276657273696f6e223b733a31323a2235362e302e323932342e3837223b733a31303a227570646174655f75726c223b733a32383a22687474703a2f2f7777772e676f6f676c652e636f6d2f6368726f6d65223b733a373a22696d675f737263223b733a34393a22687474703a2f2f732e776f726470726573732e6f72672f696d616765732f62726f77736572732f6368726f6d652e706e67223b733a31313a22696d675f7372635f73736c223b733a34383a2268747470733a2f2f776f726470726573732e6f72672f696d616765732f62726f77736572732f6368726f6d652e706e67223b733a31353a2263757272656e745f76657273696f6e223b733a323a223138223b733a373a2275706772616465223b623a303b733a383a22696e736563757265223b623a303b7d, 'no'),
(20522, 'bodhi_svgs_admin_notice_dismissed', 0x31, 'yes'),
(20479, '_site_transient_timeout_browser_844f7ae4d251b2e6e152fdd13ef479f6', 0x31343836363738323035, 'no'),
(20480, '_site_transient_browser_844f7ae4d251b2e6e152fdd13ef479f6', 0x613a393a7b733a383a22706c6174666f726d223b733a373a2257696e646f7773223b733a343a226e616d65223b733a363a224368726f6d65223b733a373a2276657273696f6e223b733a31323a2235352e302e323838332e3837223b733a31303a227570646174655f75726c223b733a32383a22687474703a2f2f7777772e676f6f676c652e636f6d2f6368726f6d65223b733a373a22696d675f737263223b733a34393a22687474703a2f2f732e776f726470726573732e6f72672f696d616765732f62726f77736572732f6368726f6d652e706e67223b733a31313a22696d675f7372635f73736c223b733a34383a2268747470733a2f2f776f726470726573732e6f72672f696d616765732f62726f77736572732f6368726f6d652e706e67223b733a31353a2263757272656e745f76657273696f6e223b733a323a223138223b733a373a2275706772616465223b623a303b733a383a22696e736563757265223b623a303b7d, 'no'),
(20513, 'bodhi_svgs_plugin_version', 0x322e332e38, 'yes'),
(43714, 'backwpup_cfg_windows', '', 'no'),
(43673, '_transient_aiowps_captcha_string_info_whx4uje1yo', 0x4d5451354e6a4d774f4441784f546c7759324e33616a4534656d557a627a597a4f574678636a68754e513d3d, 'no'),
(43674, '_transient_timeout_aiowps_captcha_string_info_bnij4w6atq', 0x31343936333039393730, 'no'),
(43675, '_transient_aiowps_captcha_string_info_bnij4w6atq', 0x4d5451354e6a4d774f4445334d446c7759324e33616a4534656d557a627a597a4f574678636a68754d54493d, 'no'),
(43676, '_transient_timeout_aiowps_captcha_string_info_bz9hk220k3', 0x31343936333130303630, 'no'),
(43677, '_transient_aiowps_captcha_string_info_bz9hk220k3', 0x4d5451354e6a4d774f4449324d446c7759324e33616a4534656d557a627a597a4f574678636a68754e673d3d, 'no'),
(43678, '_transient_timeout_users_online', 0x31343936333130303833, 'no'),
(43679, '_transient_users_online', 0x613a313a7b693a303b613a333a7b733a373a22757365725f6964223b693a323b733a31333a226c6173745f6163746976697479223b693a313439363331353438333b733a31303a2269705f61646472657373223b733a333a223a3a31223b7d7d, 'no'),
(43680, '_site_transient_timeout_browser_372b39fc0ede5776ae5d65b675deeef4', 0x31343936393133303833, 'no'),
(43681, '_site_transient_browser_372b39fc0ede5776ae5d65b675deeef4', 0x613a393a7b733a383a22706c6174666f726d223b733a373a2257696e646f7773223b733a343a226e616d65223b733a373a2246697265666f78223b733a373a2276657273696f6e223b733a343a2235332e30223b733a31303a227570646174655f75726c223b733a32333a22687474703a2f2f7777772e66697265666f782e636f6d2f223b733a373a22696d675f737263223b733a35303a22687474703a2f2f732e776f726470726573732e6f72672f696d616765732f62726f77736572732f66697265666f782e706e67223b733a31313a22696d675f7372635f73736c223b733a34393a2268747470733a2f2f776f726470726573732e6f72672f696d616765732f62726f77736572732f66697265666f782e706e67223b733a31353a2263757272656e745f76657273696f6e223b733a323a223136223b733a373a2275706772616465223b623a303b733a383a22696e736563757265223b623a303b7d, 'no'),
(43672, '_transient_timeout_aiowps_captcha_string_info_whx4uje1yo', 0x31343936333039383139, 'no'),
(43682, '_transient_pll_languages_list', 0x613a363a7b693a303b613a32343a7b733a373a227465726d5f6964223b693a343b733a343a226e616d65223b733a373a22456e676c697368223b733a343a22736c7567223b733a323a22656e223b733a31303a227465726d5f67726f7570223b693a303b733a31363a227465726d5f7461786f6e6f6d795f6964223b693a343b733a383a227461786f6e6f6d79223b733a383a226c616e6775616765223b733a31313a226465736372697074696f6e223b733a353a22656e5f4742223b733a363a22706172656e74223b693a303b733a353a22636f756e74223b693a383b733a31303a22746c5f7465726d5f6964223b693a353b733a31393a22746c5f7465726d5f7461786f6e6f6d795f6964223b693a353b733a383a22746c5f636f756e74223b693a313b733a363a226c6f63616c65223b523a393b733a363a2269735f72746c223b693a303b733a383a22666c61675f75726c223b733a38333a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f706c7567696e732f706f6c796c616e672f666c6167732f67622e706e67223b733a343a22666c6167223b733a3836363a223c696d67207372633d22646174613a696d6167652f706e673b6261736536342c6956424f5277304b47676f414141414e5355684555674141414241414141414c4341494141414435674a707541414141475852465748525462325a30643246795a5142425a4739695a53424a6257466e5a564a6c5957523563636c6c5041414141666c4a52454655654e70696e44527a6e35714e337546447431362b595742672b50763333392b4b474e30726256502b2f2f327257357466304866792f322b6d7239392b794b70794f6c33596474386e6a4557496e3866397a6a3633394e43376a373865502f2f3837333947565555684e554e75686c382f2f79734b655a724a2f76377a31305a623250545154495931585a4f32586d6661642b663758676b5878755572564236636a505658656637384a794d6a41385046757779583767415a6a39372b543265396f33643442574e7038344b314e7a7562546a4142336648302b6676364e3371502f6972396257366f7a4e5143696a42382f387a772f5475513772342f6e64764e356d5a676b70505869697333507633342b5a5068357432332f2f3739527765686f662f392f4e4445674d724f5848764a63726c6c67706f524e3850464f77792f667a50382b67556c675a492f662f357863506a2f3639652f33372f2f4155582b2f6d58526b4e35353567734f473278742f35685a514d77463472392f2f2f37352b2b66336e7a386e72373567536d7338326a6676516e54367a717658506a4338652f73724a51486f3950396676774e7441486d473466387a5a36644463336249794d324c544e6c736274664d394f5048483346687471557a3365585839482b634f79395a4d42326f36742f506e3044484d507a2f622b327758475476506c504746786463442b6d5a796a50382b384d554536736137612f786f3650796b6e3173347a647a495a362f2f2f387a4d47704b4d32704b4142306a7179345545372f6d734b6174364a77356d61667273784e74575a362f666a764e4c573239717632357051642f2f2f6e2b352b2f66784444566263632f2f502f7a782f33366d355562397a4c382b377436367945524f63484b377135626c644d4241677741446352424375564c666f4541414141415355564f524b35435949493d22207469746c653d22456e676c6973682220616c743d22456e676c69736822202f3e223b733a383a22686f6d655f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f656e2f223b733a31303a227365617263685f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f656e2f223b733a343a22686f7374223b4e3b733a353a226d6f5f6964223b733a323a223536223b733a31333a22706167655f6f6e5f66726f6e74223b733a323a223939223b733a31343a22706167655f666f725f706f737473223b623a303b733a363a2266696c746572223b733a333a22726177223b733a393a22666c61675f636f6465223b733a323a226762223b7d693a313b613a32343a7b733a373a227465726d5f6964223b693a31313b733a343a226e616d65223b733a393a224672616ec3a7616973223b733a343a22736c7567223b733a323a226672223b733a31303a227465726d5f67726f7570223b693a303b733a31363a227465726d5f7461786f6e6f6d795f6964223b693a31313b733a383a227461786f6e6f6d79223b733a383a226c616e6775616765223b733a31313a226465736372697074696f6e223b733a353a2266725f4652223b733a363a22706172656e74223b693a303b733a353a22636f756e74223b693a353b733a31303a22746c5f7465726d5f6964223b693a31323b733a31393a22746c5f7465726d5f7461786f6e6f6d795f6964223b693a31323b733a383a22746c5f636f756e74223b693a313b733a363a226c6f63616c65223b523a33333b733a363a2269735f72746c223b693a303b733a383a22666c61675f75726c223b733a38333a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f706c7567696e732f706f6c796c616e672f666c6167732f66722e706e67223b733a343a22666c6167223b733a3739383a223c696d67207372633d22646174613a696d6167652f706e673b6261736536342c6956424f5277304b47676f414141414e5355684555674141414241414141414c4341494141414435674a7075414141414247644254554541414b2f494e77574b3651414141426c30525668305532396d64486468636d554151575276596d5567535731685a3256535a57466b6558484a5a5477414141477a5355524256486a615969796565706b42427637392b5a666e782f663337392b66503338437954392f2f6a41794d697135475037377776446e4a384d666f414947426f4141596747714337535441704c2f2f2f332f392b2b2f704354762f2f2f2f51647a2f514f342f494d6e613076662f7a2b392f763337392f2f333762555554514143424e4444385a2f6a3837666666767941565837392b2f51384751446251654b4139664d2b652f507631382f2b766e777a43496b424c41414b514f41593541494177434576342f345064644e556d336a6930514a7978573372677a4530694c6671444772326f597575306c35344159766e7a3578395136642b2f515051667941517141696e394233454f794731413155446a2f2f33367a666a7231793847426f41414649394244674177434d49772b5038486f3347444f365851306c344d4e3862326b557759614c737a71674b4d2f4b48634458774278414a554433544a37373941386839513544385341486f41525033362b52666f34312b2f6d6341324141515179343966663043752f2f4d50704165492f3046644131514e59594e56412f33776d7745595667774d4141484538755048483542716f44312f2f674a4a4c41446f4a4b44533337385a2f2f774668684a41414c4638413372697a7a3875546d5967373838664a6b6a34514f4b524551795978535742686a45432f6663585a414e41414c46382b2f616e6263486c487a392b666676783538755058394b636b6b436e2f6762792f774c64387576486a7839366b2b6344315547694751674141677741377131375a70734d64555141414141415355564f524b35435949493d22207469746c653d224672616ec3a76169732220616c743d224672616ec3a761697322202f3e223b733a383a22686f6d655f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f66722f223b733a31303a227365617263685f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f66722f223b733a343a22686f7374223b4e3b733a353a226d6f5f6964223b733a333a22313336223b733a31333a22706167655f6f6e5f66726f6e74223b693a3137343b733a31343a22706167655f666f725f706f737473223b623a303b733a363a2266696c746572223b733a333a22726177223b733a393a22666c61675f636f6465223b733a323a226672223b7d693a323b613a32343a7b733a373a227465726d5f6964223b693a31353b733a343a226e616d65223b733a373a2244657574736368223b733a343a22736c7567223b733a323a226465223b733a31303a227465726d5f67726f7570223b693a303b733a31363a227465726d5f7461786f6e6f6d795f6964223b693a31353b733a383a227461786f6e6f6d79223b733a383a226c616e6775616765223b733a31313a226465736372697074696f6e223b733a353a2264655f4445223b733a363a22706172656e74223b693a303b733a353a22636f756e74223b693a353b733a31303a22746c5f7465726d5f6964223b693a31363b733a31393a22746c5f7465726d5f7461786f6e6f6d795f6964223b693a31363b733a383a22746c5f636f756e74223b693a313b733a363a226c6f63616c65223b523a35373b733a363a2269735f72746c223b693a303b733a383a22666c61675f75726c223b733a38333a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f706c7567696e732f706f6c796c616e672f666c6167732f64652e706e67223b733a343a22666c6167223b733a3739343a223c696d67207372633d22646174613a696d6167652f706e673b6261736536342c6956424f5277304b47676f414141414e5355684555674141414241414141414c4341494141414435674a7075414141414247644254554541414b2f494e77574b3651414141426c30525668305532396d64486468636d554151575276596d5567535731685a3256535a57466b6558484a5a5477414141477a5355524256486a6159765478635762342b353368337a38475a705a66662f37392b76336e2f372f6644417a2f47484141674142692b663337653346784f5a443144777a2b2f76337a39792b452f414d4676332f2f2b51756d6676396574323431514143784d444578415657664f486b4a4a4145572f67554550304551446e37382b4148452f67464f514a55414163516979384167384f2b664c466a316e312b2f5144702b2f6751696f4b3766503337382b766b44714f4833397839412f524a2f6745356c4141684159687a63414143435142446b675258526a503033345230496144545a54465a6e304449746f7433375339344b4c4f494e657245634937614b4841484538762f33722f392f2f7a4941316633362f522b6f347465766631414e594e564139503037524439494a514d445141437841444844337a38496734474d487a2b4171714861674b702f2f66774c564130552f2f76374c774d44514143782f4c5a69594644372f352f35332f2b2f2f2f373942714b2f454d5a2f555041435359612f762f384479583941306f547878324547674142692b612f4838462f6d333339426f436f512b67386b67526143517667504a4a6942596d417577333968786e2b7544414142784d4c77692b452f30507573526b774d76786842476f446b4834622f762f2b44324544797a2f2f2f5142312f514c62382b7350306c5145676746682b764758594d322f53503641325a6f6166333045782f4a2b5067656b48777a39675144417a2f503046597241794d667a37776344417a50447446774e4167414541643353497952697458316741414141415355564f524b35435949493d22207469746c653d22446575747363682220616c743d224465757473636822202f3e223b733a383a22686f6d655f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f64652f223b733a31303a227365617263685f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f64652f223b733a343a22686f7374223b4e3b733a353a226d6f5f6964223b733a333a22313337223b733a31333a22706167655f6f6e5f66726f6e74223b693a3137363b733a31343a22706167655f666f725f706f737473223b623a303b733a363a2266696c746572223b733a333a22726177223b733a393a22666c61675f636f6465223b733a323a226465223b7d693a333b613a32343a7b733a373a227465726d5f6964223b693a31393b733a343a226e616d65223b733a383a2245737061c3b16f6c223b733a343a22736c7567223b733a323a226573223b733a31303a227465726d5f67726f7570223b693a303b733a31363a227465726d5f7461786f6e6f6d795f6964223b693a31393b733a383a227461786f6e6f6d79223b733a383a226c616e6775616765223b733a31313a226465736372697074696f6e223b733a353a2265735f4553223b733a363a22706172656e74223b693a303b733a353a22636f756e74223b693a353b733a31303a22746c5f7465726d5f6964223b693a32303b733a31393a22746c5f7465726d5f7461786f6e6f6d795f6964223b693a32303b733a383a22746c5f636f756e74223b693a313b733a363a226c6f63616c65223b523a38313b733a363a2269735f72746c223b693a303b733a383a22666c61675f75726c223b733a38333a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f706c7567696e732f706f6c796c616e672f666c6167732f65732e706e67223b733a343a22666c6167223b733a3639363a223c696d67207372633d22646174613a696d6167652f706e673b6261736536342c6956424f5277304b47676f414141414e5355684555674141414241414141414c4341494141414435674a7075414141414247644254554541414b2f494e77574b3651414141426c30525668305532396d64486468636d554151575276596d5567535731685a3256535a57466b6558484a5a5477414141466e5355524256486a6159767a506741442f554e6c59455541416d755459414141516841455971462f7a4662653530525a31634d6d5339544c6930704a4c526a5a6f68414d544746554e3948646e48674545317344772f2f2b547030436c494e572f66304e494b506f464a482f392f2f554c794761556c515861414242414c41782f4766347a417433314634692b66666a332f634e2f587246667a4f782f2f762f2f2f662f2f4c7a41434d2f37395a6d44382f653854413041414d59486444565439353876585033386e4d44423073337839342f546a35792b5961686869414b4c66514b55414163514564744a666f44484d46324c2b76507a446d46584c656c663535317447464f4f68657634412f516751514578674877416438496446542f577a366a2b47686c706d58534f572f327a2f2f2f3845712f734a313844772f7a6451413041414d514578784a6a6a64793978322f373645664c7a344d5864502f692b777379476b6b4133417733393834634249494159667a49774d4b656c2f6274336a7745614c4e4177675a495178702f6644482f2b4d71716f764c313445534341574943655a76723968304653456853677742674179674644454d542b7777416867516763346b4145564177515149786655534d5354787844414543414151414a576b653876347531744141414141424a52553545726b4a6767673d3d22207469746c653d2245737061c3b16f6c2220616c743d2245737061c3b16f6c22202f3e223b733a383a22686f6d655f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f65732f223b733a31303a227365617263685f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f65732f223b733a343a22686f7374223b4e3b733a353a226d6f5f6964223b733a333a22313338223b733a31333a22706167655f6f6e5f66726f6e74223b693a3137393b733a31343a22706167655f666f725f706f737473223b623a303b733a363a2266696c746572223b733a333a22726177223b733a393a22666c61675f636f6465223b733a323a226573223b7d693a343b613a32343a7b733a373a227465726d5f6964223b693a32333b733a343a226e616d65223b733a383a224974616c69616e6f223b733a343a22736c7567223b733a323a226974223b733a31303a227465726d5f67726f7570223b693a303b733a31363a227465726d5f7461786f6e6f6d795f6964223b693a32333b733a383a227461786f6e6f6d79223b733a383a226c616e6775616765223b733a31313a226465736372697074696f6e223b733a353a2269745f4954223b733a363a22706172656e74223b693a303b733a353a22636f756e74223b693a353b733a31303a22746c5f7465726d5f6964223b693a32343b733a31393a22746c5f7465726d5f7461786f6e6f6d795f6964223b693a32343b733a383a22746c5f636f756e74223b693a313b733a363a226c6f63616c65223b523a3130353b733a363a2269735f72746c223b693a303b733a383a22666c61675f75726c223b733a38333a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f706c7567696e732f706f6c796c616e672f666c6167732f69742e706e67223b733a343a22666c6167223b733a3632383a223c696d67207372633d22646174613a696d6167652f706e673b6261736536342c6956424f5277304b47676f414141414e5355684555674141414241414141414c4341494141414435674a7075414141414247644254554541414b2f494e77574b3651414141426c30525668305532396d64486468636d554151575276596d5567535731685a3256535a57466b6558484a5a547741414145325355524256486a61596d5359794d4477677745452f6a45772f4746346d76543048797151556c58394235614549494141596d4834776c4474576731534477542f2f306c4b5376372f442b54392f772b6e596d4c2b2f2f37392f38386649506c6c3079614141474a685941474a502f6e36394f2b2f763043415541634874322f2f2f2f554c714a705256685a6f4130414173514374415a6f4d565030486950372b526c634e424544565941304d763338444e514145454d6a387677782f2f7743742f4164432f7a45426b676167596f41415967463646476a3237372b2f2f2f776c7041456f7a3841414545416744582f425a762f363977756f423438475272435441414b4943616a68392f2f66762f364356502f2b2b777537427244785146662f59574141434343776b30424b66304d516467312f674271415076304c39414e41414c4541592b3333767a2b53334a4967622f7a3543343543426b5a4752675934554649434b51556a6f4a4d41416f69526f5a534234524d6f6a6b48782f595068624e565a6f4d33414f4953515150554b397661514f495941674141444143355764345252776e4b664141414141456c46546b5375516d434322207469746c653d224974616c69616e6f2220616c743d224974616c69616e6f22202f3e223b733a383a22686f6d655f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f69742f223b733a31303a227365617263685f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f69742f223b733a343a22686f7374223b4e3b733a353a226d6f5f6964223b733a333a22313339223b733a31333a22706167655f6f6e5f66726f6e74223b693a3138313b733a31343a22706167655f666f725f706f737473223b623a303b733a363a2266696c746572223b733a333a22726177223b733a393a22666c61675f636f6465223b733a323a226974223b7d693a353b613a32343a7b733a373a227465726d5f6964223b693a373b733a343a226e616d65223b733a31303a224e656465726c616e6473223b733a343a22736c7567223b733a323a226e6c223b733a31303a227465726d5f67726f7570223b693a323b733a31363a227465726d5f7461786f6e6f6d795f6964223b693a373b733a383a227461786f6e6f6d79223b733a383a226c616e6775616765223b733a31313a226465736372697074696f6e223b733a353a226e6c5f4e4c223b733a363a22706172656e74223b693a303b733a353a22636f756e74223b693a363b733a31303a22746c5f7465726d5f6964223b693a383b733a31393a22746c5f7465726d5f7461786f6e6f6d795f6964223b693a383b733a383a22746c5f636f756e74223b693a313b733a363a226c6f63616c65223b523a3132393b733a363a2269735f72746c223b693a303b733a383a22666c61675f75726c223b733a38333a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f706c7567696e732f706f6c796c616e672f666c6167732f6e6c2e706e67223b733a343a22666c6167223b733a3637363a223c696d67207372633d22646174613a696d6167652f706e673b6261736536342c6956424f5277304b47676f414141414e5355684555674141414241414141414c4341494141414435674a7075414141414247644254554541414b2f494e77574b3651414141426c30525668305532396d64486468636d554151575276596d5567535731685a3256535a57466b6558484a5a547741414146585355524256486a6159767a506741442f554e6c59455541416b7554674341414942674a67677135566f417331714d3076647a6d4d7a33363276657a6a6f6b785047696d6b455135576f4151454b754b37317a7743434b794234632f2f4a382b4253686e2b2f76762f2b772f4433393941456f782b2f2f38464a482f392f7755552b63556f4b773230415343415742684544662f4c79444f77383442552f2f6b44746747492f6f41526d414852444a51534677567141416767786f3866502f4c79386f4b633950382f41786a69416f794d6a41386550414149494a5a2f2f2f354256494d304d4f42574470526c5a507a7a35773941414c483867797643627a37514272434a41414845794b4459583135722f2b6a313139392f2f7633352b2b2f586e372b2f2f2f37374453542f774d6c2f6634446b3337384b346a78374f3263414242414c77374e5037372f2b657633784230674f704f4866723939416458392f67545641534b4347502f2f2b385843794d6a433841776767466f5a6649485753777077516b3443572f41596a734b6c4138752b66662f2f2f2f7633333939382f595067426e51515151497a4161474e672b41564766354159663542452f6f436a47454979415151594147764b5a3443362b7858524141414141456c46546b5375516d434322207469746c653d224e656465726c616e64732220616c743d224e656465726c616e647322202f3e223b733a383a22686f6d655f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f6e6c2f223b733a31303a227365617263685f75726c223b733a34363a22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f6e6c2f223b733a343a22686f7374223b4e3b733a353a226d6f5f6964223b733a323a223631223b733a31333a22706167655f6f6e5f66726f6e74223b693a3138333b733a31343a22706167655f666f725f706f737473223b623a303b733a363a2266696c746572223b733a333a22726177223b733a393a22666c61675f636f6465223b733a323a226e6c223b7d7d, 'yes'),
(43711, '_site_transient_update_core', 0x4f3a383a22737464436c617373223a343a7b733a373a2275706461746573223b613a313a7b693a303b4f3a383a22737464436c617373223a31303a7b733a383a22726573706f6e7365223b733a363a226c6174657374223b733a383a22646f776e6c6f6164223b733a36353a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f72656c656173652f656e5f47422f776f726470726573732d342e372e352e7a6970223b733a363a226c6f63616c65223b733a353a22656e5f4742223b733a383a227061636b61676573223b4f3a383a22737464436c617373223a353a7b733a343a2266756c6c223b733a36353a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f72656c656173652f656e5f47422f776f726470726573732d342e372e352e7a6970223b733a31303a226e6f5f636f6e74656e74223b623a303b733a31313a226e65775f62756e646c6564223b623a303b733a373a227061727469616c223b623a303b733a383a22726f6c6c6261636b223b623a303b7d733a373a2263757272656e74223b733a353a22342e372e35223b733a373a2276657273696f6e223b733a353a22342e372e35223b733a31313a227068705f76657273696f6e223b733a353a22352e322e34223b733a31333a226d7973716c5f76657273696f6e223b733a333a22352e30223b733a31313a226e65775f62756e646c6564223b733a333a22342e37223b733a31353a227061727469616c5f76657273696f6e223b733a303a22223b7d7d733a31323a226c6173745f636865636b6564223b693a313439363330383730343b733a31353a2276657273696f6e5f636865636b6564223b733a353a22342e372e35223b733a31323a227472616e736c6174696f6e73223b613a303a7b7d7d, 'no');
INSERT INTO `wor1677_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES 
(43712, '_site_transient_update_plugins', 0x4f3a383a22737464436c617373223a353a7b733a31323a226c6173745f636865636b6564223b693a313439363330383730363b733a373a22636865636b6564223b613a31333a7b733a32353a226163636f7264696f6e732f6163636f7264696f6e732e706870223b733a363a22322e302e3138223b733a35313a22616c6c2d696e2d6f6e652d77702d73656375726974792d616e642d6669726577616c6c2f77702d73656375726974792e706870223b733a353a22342e322e37223b733a32313a226261636b777075702f6261636b777075702e706870223b733a353a22332e342e30223b733a33363a22636f6e746163742d666f726d2d372f77702d636f6e746163742d666f726d2d372e706870223b733a333a22342e38223b733a33333a22637573746f6d2d3430342d70726f2f637573746f6d2d3430342d70726f2e706870223b733a353a22322e302e33223b733a33343a2269666561747572652d736c696465722f6966656174757265736c696465722e706870223b733a333a22312e31223b733a31373a22696e667573652f696e667573652e706870223b733a353a22312e322e31223b733a33333a226e61762d6d656e752d726f6c65732f6e61762d6d656e752d726f6c65732e706870223b733a353a22312e382e36223b733a32313a22706f6c796c616e672f706f6c796c616e672e706870223b733a353a22322e312e35223b733a33303a22726f6f7473616e6473686f6f74732f696e666f5f706c7567696e2e706870223b733a333a22312e30223b733a34393a227365727665722d69702d6d656d6f72792d75736167652f7365727665722d69702d6d656d6f72792d75736167652e706870223b733a353a22322e302e33223b733a32373a227376672d737570706f72742f7376672d737570706f72742e706870223b733a353a22322e332e38223b733a34313a22776f726470726573732d696d706f727465722f776f726470726573732d696d706f727465722e706870223b733a353a22302e362e33223b7d733a383a22726573706f6e7365223b613a303a7b7d733a31323a227472616e736c6174696f6e73223b613a303a7b7d733a393a226e6f5f757064617465223b613a31323a7b733a32353a226163636f7264696f6e732f6163636f7264696f6e732e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a353a223534373432223b733a343a22736c7567223b733a31303a226163636f7264696f6e73223b733a363a22706c7567696e223b733a32353a226163636f7264696f6e732f6163636f7264696f6e732e706870223b733a31313a226e65775f76657273696f6e223b733a363a22322e302e3138223b733a333a2275726c223b733a34313a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f6163636f7264696f6e732f223b733a373a227061636b616765223b733a35333a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f6163636f7264696f6e732e7a6970223b7d733a35313a22616c6c2d696e2d6f6e652d77702d73656375726974792d616e642d6669726577616c6c2f77702d73656375726974792e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a353a223431333039223b733a343a22736c7567223b733a33353a22616c6c2d696e2d6f6e652d77702d73656375726974792d616e642d6669726577616c6c223b733a363a22706c7567696e223b733a35313a22616c6c2d696e2d6f6e652d77702d73656375726974792d616e642d6669726577616c6c2f77702d73656375726974792e706870223b733a31313a226e65775f76657273696f6e223b733a353a22342e322e37223b733a333a2275726c223b733a36363a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f616c6c2d696e2d6f6e652d77702d73656375726974792d616e642d6669726577616c6c2f223b733a373a227061636b616765223b733a37383a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f616c6c2d696e2d6f6e652d77702d73656375726974792d616e642d6669726577616c6c2e7a6970223b7d733a32313a226261636b777075702f6261636b777075702e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a343a2238373336223b733a343a22736c7567223b733a383a226261636b77707570223b733a363a22706c7567696e223b733a32313a226261636b777075702f6261636b777075702e706870223b733a31313a226e65775f76657273696f6e223b733a353a22332e342e30223b733a333a2275726c223b733a33393a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f6261636b777075702f223b733a373a227061636b616765223b733a35373a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f6261636b777075702e332e342e302e7a6970223b7d733a33363a22636f6e746163742d666f726d2d372f77702d636f6e746163742d666f726d2d372e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a333a22373930223b733a343a22736c7567223b733a31343a22636f6e746163742d666f726d2d37223b733a363a22706c7567696e223b733a33363a22636f6e746163742d666f726d2d372f77702d636f6e746163742d666f726d2d372e706870223b733a31313a226e65775f76657273696f6e223b733a333a22342e38223b733a333a2275726c223b733a34353a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f636f6e746163742d666f726d2d372f223b733a373a227061636b616765223b733a36313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f636f6e746163742d666f726d2d372e342e382e7a6970223b7d733a33333a22637573746f6d2d3430342d70726f2f637573746f6d2d3430342d70726f2e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a353a223539373739223b733a343a22736c7567223b733a31343a22637573746f6d2d3430342d70726f223b733a363a22706c7567696e223b733a33333a22637573746f6d2d3430342d70726f2f637573746f6d2d3430342d70726f2e706870223b733a31313a226e65775f76657273696f6e223b733a353a22322e302e33223b733a333a2275726c223b733a34353a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f637573746f6d2d3430342d70726f2f223b733a373a227061636b616765223b733a36333a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f637573746f6d2d3430342d70726f2e322e302e332e7a6970223b7d733a33343a2269666561747572652d736c696465722f6966656174757265736c696465722e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a353a223532393139223b733a343a22736c7567223b733a31353a2269666561747572652d736c69646572223b733a363a22706c7567696e223b733a33343a2269666561747572652d736c696465722f6966656174757265736c696465722e706870223b733a31313a226e65775f76657273696f6e223b733a333a22312e31223b733a333a2275726c223b733a34363a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f69666561747572652d736c696465722f223b733a373a227061636b616765223b733a35383a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f69666561747572652d736c696465722e7a6970223b7d733a31373a22696e667573652f696e667573652e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a353a223634393536223b733a343a22736c7567223b733a363a22696e66757365223b733a363a22706c7567696e223b733a31373a22696e667573652f696e667573652e706870223b733a31313a226e65775f76657273696f6e223b733a353a22312e322e31223b733a333a2275726c223b733a33373a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f696e667573652f223b733a373a227061636b616765223b733a34393a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f696e667573652e7a6970223b7d733a33333a226e61762d6d656e752d726f6c65732f6e61762d6d656e752d726f6c65732e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a353a223334383038223b733a343a22736c7567223b733a31343a226e61762d6d656e752d726f6c6573223b733a363a22706c7567696e223b733a33333a226e61762d6d656e752d726f6c65732f6e61762d6d656e752d726f6c65732e706870223b733a31313a226e65775f76657273696f6e223b733a353a22312e382e36223b733a333a2275726c223b733a34353a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f6e61762d6d656e752d726f6c65732f223b733a373a227061636b616765223b733a36333a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f6e61762d6d656e752d726f6c65732e312e382e362e7a6970223b7d733a32313a22706f6c796c616e672f706f6c796c616e672e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a353a223235373830223b733a343a22736c7567223b733a383a22706f6c796c616e67223b733a363a22706c7567696e223b733a32313a22706f6c796c616e672f706f6c796c616e672e706870223b733a31313a226e65775f76657273696f6e223b733a353a22322e312e35223b733a333a2275726c223b733a33393a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f706f6c796c616e672f223b733a373a227061636b616765223b733a35373a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f706f6c796c616e672e322e312e352e7a6970223b7d733a34393a227365727665722d69702d6d656d6f72792d75736167652f7365727665722d69702d6d656d6f72792d75736167652e706870223b4f3a383a22737464436c617373223a373a7b733a323a226964223b733a353a223435313035223b733a343a22736c7567223b733a32323a227365727665722d69702d6d656d6f72792d7573616765223b733a363a22706c7567696e223b733a34393a227365727665722d69702d6d656d6f72792d75736167652f7365727665722d69702d6d656d6f72792d75736167652e706870223b733a31313a226e65775f76657273696f6e223b733a353a22322e302e33223b733a333a2275726c223b733a35333a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f7365727665722d69702d6d656d6f72792d75736167652f223b733a373a227061636b616765223b733a37313a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f7365727665722d69702d6d656d6f72792d75736167652e322e302e332e7a6970223b733a31343a22757067726164655f6e6f74696365223b733a34323a22536f6c766564206572726f722077697468206d656d6f72795f6765745f7065616b5f757361676528292e223b7d733a32373a227376672d737570706f72742f7376672d737570706f72742e706870223b4f3a383a22737464436c617373223a373a7b733a323a226964223b733a353a223532323735223b733a343a22736c7567223b733a31313a227376672d737570706f7274223b733a363a22706c7567696e223b733a32373a227376672d737570706f72742f7376672d737570706f72742e706870223b733a31313a226e65775f76657273696f6e223b733a353a22322e332e38223b733a333a2275726c223b733a34323a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f7376672d737570706f72742f223b733a373a227061636b616765223b733a36303a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f7376672d737570706f72742e322e332e382e7a6970223b733a31343a22757067726164655f6e6f74696365223b733a3133333a22416464732062657474657220737570706f727420666f7220576f6f436f6d6d6572636520616e642053656e7365692e204669786573206973737565207769746820666561747572656420696d61676573206e6f742073686f77696e67207570207768656e206175746f20696e7365727420636c6173732073657474696e67206973206f6e2e223b7d733a34313a22776f726470726573732d696d706f727465722f776f726470726573732d696d706f727465722e706870223b4f3a383a22737464436c617373223a363a7b733a323a226964223b733a353a223134393735223b733a343a22736c7567223b733a31383a22776f726470726573732d696d706f72746572223b733a363a22706c7567696e223b733a34313a22776f726470726573732d696d706f727465722f776f726470726573732d696d706f727465722e706870223b733a31313a226e65775f76657273696f6e223b733a353a22302e362e33223b733a333a2275726c223b733a34393a2268747470733a2f2f776f726470726573732e6f72672f706c7567696e732f776f726470726573732d696d706f727465722f223b733a373a227061636b616765223b733a36373a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f706c7567696e2f776f726470726573732d696d706f727465722e302e362e332e7a6970223b7d7d7d, 'no'),
(43713, '_site_transient_update_themes', 0x4f3a383a22737464436c617373223a343a7b733a31323a226c6173745f636865636b6564223b693a313439363330383730363b733a373a22636865636b6564223b613a31323a7b733a31303a224578706c6f7261626c65223b733a353a22312e392e37223b733a31323a226164616d6f732d6368696c64223b733a303a22223b733a363a226164616d6f73223b733a333a22332e31223b733a31363a22626c616e6b736c6174652d6368696c64223b733a333a22312e30223b733a31303a22626c616e6b736c617465223b733a353a22342e302e33223b733a31393a22696e74756974696f6e5f70726f2d6368696c64223b733a333a22312e30223b733a31333a22696e74756974696f6e5f70726f223b733a353a22322e312e31223b733a31363a22726573706f6e736976652d6368696c64223b733a333a22312e30223b733a31303a22726573706f6e73697665223b733a333a22322e34223b733a31333a227477656e74796669667465656e223b733a333a22312e37223b733a31393a227477656e74797369787465656e2d6368696c64223b733a333a22312e30223b733a31333a227477656e74797369787465656e223b733a333a22312e33223b7d733a383a22726573706f6e7365223b613a313a7b733a31303a22726573706f6e73697665223b613a343a7b733a353a227468656d65223b733a31303a22726573706f6e73697665223b733a31313a226e65775f76657273696f6e223b733a333a22322e35223b733a333a2275726c223b733a34303a2268747470733a2f2f776f726470726573732e6f72672f7468656d65732f726573706f6e736976652f223b733a373a227061636b616765223b733a35363a2268747470733a2f2f646f776e6c6f6164732e776f726470726573732e6f72672f7468656d652f726573706f6e736976652e322e352e7a6970223b7d7d733a31323a227472616e736c6174696f6e73223b613a303a7b7d7d, 'no');
/*!40000 ALTER TABLE `wor1677_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_postmeta`
--

DROP TABLE IF EXISTS `wor1677_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=4699 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_postmeta`
--

LOCK TABLES `wor1677_postmeta` WRITE;
/*!40000 ALTER TABLE `wor1677_postmeta` DISABLE KEYS */;
INSERT INTO `wor1677_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES 
(2622, 137, '_pll_strings_translations', 0x613a303a7b7d),
(334, 102, '_menu_item_url', ''),
(333, 102, '_menu_item_xfn', ''),
(332, 102, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(331, 102, '_menu_item_target', ''),
(330, 102, '_menu_item_object', 0x70616765),
(329, 102, '_menu_item_object_id', 0x3930),
(2078, 320, '_menu_item_xfn', ''),
(2057, 318, '_menu_item_url', ''),
(2056, 318, '_menu_item_xfn', ''),
(325, 101, '_menu_item_url', ''),
(324, 101, '_menu_item_xfn', ''),
(323, 101, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(2077, 320, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(320, 101, '_menu_item_object_id', 0x3939),
(319, 101, '_menu_item_menu_item_parent', ''),
(318, 101, '_menu_item_type', 0x706f73745f74797065),
(317, 99, '_wp_page_template', 0x64656661756c74),
(315, 99, '_edit_lock', 0x313438373632343832373a32),
(2460, 339, '_wp_attached_file', 0x323031362f31312f637a2d312e737667),
(2072, 320, '_menu_item_type', 0x706f73745f74797065),
(2070, 319, '_menu_item_icon', ''),
(2071, 319, '_menu_item_style', 0x6e6f726d616c),
(2067, 319, '_menu_item_xfn', ''),
(2068, 319, '_menu_item_url', ''),
(2066, 319, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(316, 99, '_edit_last', 0x32),
(2609, 297, 'layout_sidebar', 0x6e6f6e65),
(302, 97, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(301, 97, '_menu_item_target', ''),
(300, 97, '_menu_item_object', 0x70616765),
(299, 97, '_menu_item_object_id', 0x3934),
(298, 97, '_menu_item_menu_item_parent', ''),
(297, 97, '_menu_item_type', 0x706f73745f74797065),
(2605, 295, 'layout_sidebar', 0x6e6f6e65),
(2029, 316, '_menu_item_menu_item_parent', ''),
(2023, 315, '_menu_item_xfn', ''),
(2065, 319, '_menu_item_target', ''),
(2064, 319, '_menu_item_object', 0x70616765),
(2063, 319, '_menu_item_object_id', 0x323939),
(2017, 315, '_menu_item_type', 0x706f73745f74797065),
(2018, 315, '_menu_item_menu_item_parent', ''),
(2019, 315, '_menu_item_object_id', 0x323839),
(2020, 315, '_menu_item_object', 0x70616765),
(2021, 315, '_menu_item_target', ''),
(2022, 315, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(2239, 90, 'page_header', 0x6e6f726d616c),
(2060, 318, '_menu_item_style', 0x6e6f726d616c),
(2073, 320, '_menu_item_menu_item_parent', ''),
(2038, 316, '_menu_item_style', 0x6e6f726d616c),
(2039, 317, '_menu_item_type', 0x706f73745f74797065),
(2024, 315, '_menu_item_url', ''),
(2026, 315, '_menu_item_icon', ''),
(2027, 315, '_menu_item_style', 0x6e6f726d616c),
(2028, 316, '_menu_item_type', 0x706f73745f74797065),
(266, 88, '_edit_lock', 0x313437373935303738353a32),
(2037, 316, '_menu_item_icon', ''),
(1390, 88, '_et_single_header_bg', ''),
(2035, 316, '_menu_item_url', ''),
(2030, 316, '_menu_item_object_id', 0x323931),
(2031, 316, '_menu_item_object', 0x70616765),
(2032, 316, '_menu_item_target', ''),
(2033, 316, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(2034, 316, '_menu_item_xfn', ''),
(242, 67, '_edit_last', 0x32),
(241, 67, '_edit_lock', 0x313437333234393739303a32),
(265, 86, '_wp_page_template', 0x706167652d66756c6c2e706870),
(250, 77, '_edit_lock', 0x313437333038323534373a32),
(2623, 56, '_pll_strings_translations', 0x613a393a7b693a303b613a323a7b693a303b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b693a313b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b7d693a313b613a323a7b693a303b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b693a313b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b7d693a323b613a323a7b693a303b733a363a2246206a2c2059223b693a313b733a363a2246206a2c2059223b7d693a333b613a323a7b693a303b733a353a22673a692061223b693a313b733a353a22673a692061223b7d693a343b613a323a7b693a303b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b693a313b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b7d693a353b613a323a7b693a303b733a31383a22756e64657220636f6e737472756374696f6e223b693a313b733a31383a22756e64657220636f6e737472756374696f6e223b7d693a363b613a323a7b693a303b733a3232393a2220506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e0d0a223b693a313b733a3232363a22506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e223b7d693a373b613a323a7b693a303b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b693a313b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b7d693a383b613a323a7b693a303b733a363a224167656e6461223b693a313b733a363a224167656e6461223b7d7d),
(2617, 293, 'layout_sidebar', 0x6e6f6e65),
(2613, 299, 'layout_sidebar', 0x6e6f6e65),
(2601, 289, 'layout_sidebar', 0x6e6f6e65),
(2585, 291, 'layout_sidebar', 0x6e6f6e65),
(249, 72, '_wp_page_template', 0x706167652d74656d706c617465732f70726f6a6563742d636f6e74726f6c2d706167652e706870),
(248, 72, '_edit_last', 0x32),
(247, 72, '_edit_lock', 0x313437333036333736393a32),
(246, 70, '_wp_page_template', 0x706167652d74656d706c617465732f70726f6a6563742d666f726d2d706167652e706870),
(245, 70, '_edit_last', 0x32),
(244, 70, '_edit_lock', 0x313437333036363330333a32),
(2005, 313, '_wp_attached_file', 0x323031362f31312f65732e737667),
(2004, 312, '_wp_attached_file', 0x323031362f31312f70742e737667),
(304, 97, '_menu_item_url', ''),
(303, 97, '_menu_item_xfn', ''),
(2076, 320, '_menu_item_target', ''),
(295, 94, '_wp_page_template', 0x64656661756c74),
(293, 94, '_edit_lock', 0x313437373935313830393a32),
(294, 94, '_edit_last', 0x32),
(321, 101, '_menu_item_object', 0x70616765),
(322, 101, '_menu_item_target', ''),
(328, 102, '_menu_item_menu_item_parent', ''),
(327, 102, '_menu_item_type', 0x706f73745f74797065),
(1392, 94, 'layout_sidebar', 0x6e6f6e65),
(995, 94, 'page_header', 0x6e6f726d616c),
(2440, 99, 'page_header', 0x6e6f726d616c),
(264, 86, '_edit_last', 0x32),
(2082, 320, '_menu_item_style', 0x6e6f726d616c),
(263, 86, '_edit_lock', 0x313437373935303439313a32),
(2079, 320, '_menu_item_url', ''),
(2081, 320, '_menu_item_icon', ''),
(252, 77, '_wp_page_template', 0x706167652d74656d706c617465732f61646d696e2d70726f6a6563742d636f6e74726f6c2d706167652e706870),
(251, 77, '_edit_last', 0x32),
(217, 47, 'c4p_log_redirect_to', ''),
(218, 47, '_edit_lock', 0x313437333235373933323a32),
(219, 47, '_edit_last', 0x32),
(220, 47, '_wp_page_template', 0x706167652d74656d706c617465732f70726f6a65637474797065732d706167652e706870),
(221, 49, 'c4p_log_redirect_to', ''),
(222, 49, '_edit_lock', 0x313437323930333836303a32),
(223, 49, '_edit_last', 0x32),
(224, 49, '_wp_page_template', 0x706167652d74656d706c617465732f70726f6a656374747970652d666f726d2d706167652e706870),
(225, 51, 'c4p_log_redirect_to', ''),
(226, 51, '_edit_lock', 0x313437313938353231333a32),
(227, 51, '_edit_last', 0x32),
(228, 51, '_wp_page_template', 0x706167652d74656d706c617465732f70726f6a656374747970652d636f6e74726f6c2d706167652e706870),
(229, 53, '_edit_lock', 0x313437333235333830323a32),
(230, 53, '_edit_last', 0x32),
(231, 53, '_wp_page_template', 0x706167652d74656d706c617465732f67656e6572616c2d746573742d706167652e706870),
(232, 62, '_edit_lock', 0x313437313938353933373a32),
(233, 62, '_edit_last', 0x32),
(234, 62, '_wp_page_template', 0x64656661756c74),
(268, 88, '_wp_page_template', 0x706167652d66756c6c2e706870),
(267, 88, '_edit_last', 0x32),
(2075, 320, '_menu_item_object', 0x70616765),
(238, 64, '_edit_lock', 0x313437333235333933303a32),
(239, 64, '_edit_last', 0x32),
(240, 64, '_wp_page_template', 0x706167652d74656d706c617465732f636f6e66696775726174696f6e2d706167652e706870),
(243, 67, '_wp_page_template', 0x706167652d74656d706c617465732f616c6c2d70726f6a656374732d706167652e706870),
(253, 79, '_edit_lock', 0x313437333038303132303a32),
(254, 79, '_edit_last', 0x32),
(255, 79, '_wp_page_template', 0x706167652d74656d706c617465732f70726f6a6563742d64657461696c732d706167652e706870),
(256, 81, '_edit_lock', 0x313437333235323835353a32),
(257, 81, '_edit_last', 0x32),
(258, 81, '_wp_page_template', 0x706167652d74656d706c617465732f6d792d70726f6a656374732d706167652e706870),
(269, 90, '_edit_lock', 0x313437383939393430383a32),
(270, 90, '_edit_last', 0x32),
(271, 90, '_wp_page_template', 0x64656661756c74),
(2439, 99, 'layout_sidebar', 0x6e6f6e65),
(415, 99, 'page_featured', 0x6e6f6e65),
(2442, 99, 'page_footer', 0x6e6f726d616c),
(2441, 99, 'page_title', 0x6d696e696d616c),
(2074, 320, '_menu_item_object_id', 0x323933),
(2040, 317, '_menu_item_menu_item_parent', ''),
(281, 93, '_menu_item_type', 0x706f73745f74797065),
(282, 93, '_menu_item_menu_item_parent', ''),
(283, 93, '_menu_item_object_id', 0x3836),
(284, 93, '_menu_item_object', 0x70616765),
(285, 93, '_menu_item_target', ''),
(286, 93, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(287, 93, '_menu_item_xfn', ''),
(288, 93, '_menu_item_url', ''),
(2044, 317, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(2045, 317, '_menu_item_xfn', ''),
(2046, 317, '_menu_item_url', ''),
(2048, 317, '_menu_item_icon', ''),
(2049, 317, '_menu_item_style', 0x6e6f726d616c),
(2050, 318, '_menu_item_type', 0x706f73745f74797065),
(2061, 319, '_menu_item_type', 0x706f73745f74797065),
(2001, 309, '_wp_attached_file', 0x323031362f31312f66722e737667),
(2000, 308, '_wp_attached_file', 0x323031362f31312f637a2e737667),
(1879, 299, '_edit_last', 0x32),
(1878, 299, '_edit_lock', 0x313437393035343330323a32),
(1877, 299, '_wp_page_template', 0x64656661756c74),
(1876, 299, 'page_featured', 0x6e6f6e65),
(2615, 299, 'page_title', 0x6e6f726d616c),
(2616, 299, 'page_footer', 0x6e6f726d616c),
(1808, 289, '_edit_lock', 0x313437393035343438383a32),
(2614, 299, 'page_header', 0x6e6f726d616c),
(1859, 297, '_edit_lock', 0x313437393035343234363a32),
(1860, 297, '_edit_last', 0x32),
(2587, 291, 'page_title', 0x6e6f726d616c),
(2588, 291, 'page_footer', 0x6e6f726d616c),
(1818, 291, 'page_featured', 0x6e6f6e65),
(1819, 291, '_wp_page_template', 0x64656661756c74),
(1820, 291, '_edit_lock', 0x313437393035343530343a32),
(1821, 291, '_edit_last', 0x32),
(2618, 293, 'page_header', 0x6e6f726d616c),
(2619, 293, 'page_title', 0x6e6f726d616c),
(2620, 293, 'page_footer', 0x6e6f726d616c),
(1828, 293, 'page_featured', 0x6e6f6e65),
(1829, 293, '_wp_page_template', 0x64656661756c74),
(1830, 293, '_edit_lock', 0x313437393035343335323a32),
(1831, 293, '_edit_last', 0x32),
(2606, 295, 'page_header', 0x6e6f726d616c),
(2607, 295, 'page_title', 0x6e6f726d616c),
(2608, 295, 'page_footer', 0x6e6f726d616c),
(1841, 295, 'page_featured', 0x6e6f6e65),
(1842, 295, '_wp_page_template', 0x64656661756c74),
(1843, 295, '_edit_lock', 0x313437393035343138383a32),
(1844, 295, '_edit_last', 0x32),
(2610, 297, 'page_header', 0x6e6f726d616c),
(2611, 297, 'page_title', 0x6e6f726d616c),
(2612, 297, 'page_footer', 0x6e6f726d616c),
(1857, 297, 'page_featured', 0x6e6f6e65),
(1858, 297, '_wp_page_template', 0x64656661756c74),
(996, 94, 'page_title', 0x6e6f726d616c),
(997, 94, 'page_footer', 0x6e6f726d616c),
(433, 94, 'page_featured', 0x6e6f6e65),
(434, 161, '_wp_attached_file', 0x323031362f31302f6c6f676f2d52532e6a7067),
(435, 161, '_wp_attachment_metadata', 0x613a353a7b733a353a227769647468223b693a3535353b733a363a22686569676874223b693a3131333b733a343a2266696c65223b733a31393a22323031362f31302f6c6f676f2d52532e6a7067223b733a353a2273697a6573223b613a313a7b733a393a227468756d626e61696c223b613a343a7b733a343a2266696c65223b733a31393a226c6f676f2d52532d323030783131332e6a7067223b733a353a227769647468223b693a3230303b733a363a22686569676874223b693a3131333b733a393a226d696d652d74797065223b733a31303a22696d6167652f6a706567223b7d7d733a31303a22696d6167655f6d657461223b613a31323a7b733a383a226170657274757265223b733a313a2230223b733a363a22637265646974223b733a303a22223b733a363a2263616d657261223b733a303a22223b733a373a2263617074696f6e223b733a303a22223b733a31373a22637265617465645f74696d657374616d70223b733a313a2230223b733a393a22636f70797269676874223b733a303a22223b733a31323a22666f63616c5f6c656e677468223b733a313a2230223b733a333a2269736f223b733a313a2230223b733a31333a22736875747465725f7370656564223b733a313a2230223b733a353a227469746c65223b733a303a22223b733a31313a226f7269656e746174696f6e223b733a313a2230223b733a383a226b6579776f726473223b613a303a7b7d7d7d),
(436, 162, '_wp_attached_file', 0x323031362f31302f6c6f676f2d52532d312e6a7067),
(437, 162, '_wp_attachment_metadata', 0x613a353a7b733a353a227769647468223b693a3535353b733a363a22686569676874223b693a3131333b733a343a2266696c65223b733a32313a22323031362f31302f6c6f676f2d52532d312e6a7067223b733a353a2273697a6573223b613a313a7b733a393a227468756d626e61696c223b613a343a7b733a343a2266696c65223b733a32313a226c6f676f2d52532d312d323030783131332e6a7067223b733a353a227769647468223b693a3230303b733a363a22686569676874223b693a3131333b733a393a226d696d652d74797065223b733a31303a22696d6167652f6a706567223b7d7d733a31303a22696d6167655f6d657461223b613a31323a7b733a383a226170657274757265223b733a313a2230223b733a363a22637265646974223b733a303a22223b733a363a2263616d657261223b733a303a22223b733a373a2263617074696f6e223b733a303a22223b733a31373a22637265617465645f74696d657374616d70223b733a313a2230223b733a393a22636f70797269676874223b733a303a22223b733a31323a22666f63616c5f6c656e677468223b733a313a2230223b733a333a2269736f223b733a313a2230223b733a31333a22736875747465725f7370656564223b733a313a2230223b733a353a227469746c65223b733a303a22223b733a31313a226f7269656e746174696f6e223b733a313a2230223b733a383a226b6579776f726473223b613a303a7b7d7d7d),
(438, 163, '_wp_attached_file', 0x323031362f31302f6c6f676f2d52532e706e67),
(439, 163, '_wp_attachment_metadata', 0x613a353a7b733a353a227769647468223b693a3535353b733a363a22686569676874223b693a3131333b733a343a2266696c65223b733a31393a22323031362f31302f6c6f676f2d52532e706e67223b733a353a2273697a6573223b613a313a7b733a393a227468756d626e61696c223b613a343a7b733a343a2266696c65223b733a31393a226c6f676f2d52532d323030783131332e706e67223b733a353a227769647468223b693a3230303b733a363a22686569676874223b693a3131333b733a393a226d696d652d74797065223b733a393a22696d6167652f706e67223b7d7d733a31303a22696d6167655f6d657461223b613a31323a7b733a383a226170657274757265223b733a313a2230223b733a363a22637265646974223b733a303a22223b733a363a2263616d657261223b733a303a22223b733a373a2263617074696f6e223b733a303a22223b733a31373a22637265617465645f74696d657374616d70223b733a313a2230223b733a393a22636f70797269676874223b733a303a22223b733a31323a22666f63616c5f6c656e677468223b733a313a2230223b733a333a2269736f223b733a313a2230223b733a31333a22736875747465725f7370656564223b733a313a2230223b733a353a227469746c65223b733a303a22223b733a31313a226f7269656e746174696f6e223b733a313a2230223b733a383a226b6579776f726473223b613a303a7b7d7d7d),
(2621, 137, '_pll_strings_translations', 0x613a303a7b7d),
(2240, 90, 'page_title', 0x6e6f726d616c),
(2241, 90, 'page_footer', 0x6e6f726d616c),
(443, 90, 'page_featured', 0x6e6f6e65),
(487, 174, '_wp_page_template', 0x64656661756c74),
(486, 174, '_edit_last', 0x32),
(485, 174, '_edit_lock', 0x313437383131323537303a32),
(1373, 255, '_pll_menu_item', 0x613a363a7b733a32323a22686964655f69665f6e6f5f7472616e736c6174696f6e223b693a303b733a31323a22686964655f63757272656e74223b693a303b733a31303a22666f7263655f686f6d65223b693a303b733a31303a2273686f775f666c616773223b693a313b733a31303a2273686f775f6e616d6573223b693a313b733a383a2264726f70646f776e223b693a303b7d),
(453, 101, '_menu_item_icon', ''),
(454, 101, '_menu_item_style', 0x6e6f726d616c),
(455, 97, '_menu_item_icon', ''),
(456, 97, '_menu_item_style', 0x6e6f726d616c),
(457, 93, '_menu_item_icon', ''),
(458, 93, '_menu_item_style', 0x6e6f726d616c),
(2003, 311, '_wp_attached_file', 0x323031362f31312f69742e737667),
(2002, 310, '_wp_attached_file', 0x323031362f31312f67622e737667),
(2062, 319, '_menu_item_menu_item_parent', ''),
(1809, 289, '_edit_last', 0x32),
(1810, 289, '_wp_page_template', 0x64656661756c74),
(2602, 289, 'page_header', 0x6e6f726d616c),
(2603, 289, 'page_title', 0x6e6f726d616c),
(2604, 289, 'page_footer', 0x6e6f726d616c),
(1814, 289, 'page_featured', 0x6e6f6e65),
(2586, 291, 'page_header', 0x6e6f726d616c),
(473, 102, '_menu_item_icon', ''),
(474, 102, '_menu_item_style', 0x6e6f726d616c),
(1371, 255, '_menu_item_url', 0x23706c6c5f7377697463686572),
(1370, 255, '_menu_item_xfn', ''),
(1369, 255, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1368, 255, '_menu_item_target', ''),
(3486, 174, 'page_header', 0x6e6f726d616c),
(3487, 174, 'page_title', 0x6d696e696d616c),
(3488, 174, 'page_footer', 0x6e6f726d616c),
(491, 174, 'page_featured', 0x6e6f6e65),
(3490, 176, 'page_header', 0x6e6f726d616c),
(3491, 176, 'page_title', 0x6d696e696d616c),
(3492, 176, 'page_footer', 0x6e6f726d616c),
(495, 176, 'page_featured', 0x6e6f6e65),
(496, 176, '_wp_page_template', 0x64656661756c74),
(497, 176, '_edit_lock', 0x313437393030303134323a32),
(498, 176, '_edit_last', 0x32),
(1367, 255, '_menu_item_object', 0x637573746f6d),
(1366, 255, '_menu_item_object_id', 0x323535),
(1365, 255, '_menu_item_menu_item_parent', ''),
(1364, 255, '_menu_item_type', 0x637573746f6d),
(3485, 174, 'layout_sidebar', 0x6e6f6e65),
(3489, 176, 'layout_sidebar', 0x6e6f6e65),
(3494, 179, 'page_header', 0x6e6f726d616c),
(3495, 179, 'page_title', 0x6d696e696d616c),
(3496, 179, 'page_footer', 0x6e6f726d616c),
(522, 179, 'page_featured', 0x6e6f6e65),
(3493, 179, 'layout_sidebar', 0x6e6f6e65),
(524, 179, '_wp_page_template', 0x64656661756c74),
(525, 179, '_edit_lock', 0x313437363930323939373a32),
(526, 179, '_edit_last', 0x32),
(3498, 181, 'page_header', 0x6e6f726d616c),
(3499, 181, 'page_title', 0x6d696e696d616c),
(3500, 181, 'page_footer', 0x6e6f726d616c),
(542, 181, 'page_featured', 0x6e6f6e65),
(3497, 181, 'layout_sidebar', 0x6e6f6e65),
(544, 181, '_wp_page_template', 0x64656661756c74),
(545, 181, '_edit_lock', 0x313437363930323339373a32),
(546, 181, '_edit_last', 0x32),
(3502, 183, 'page_header', 0x6e6f726d616c),
(3503, 183, 'page_title', 0x6d696e696d616c),
(3504, 183, 'page_footer', 0x6e6f726d616c),
(566, 183, 'page_featured', 0x6e6f6e65),
(3501, 183, 'layout_sidebar', 0x6e6f6e65),
(568, 183, '_wp_page_template', 0x64656661756c74),
(569, 183, '_edit_lock', 0x313437363930333038393a32),
(570, 183, '_edit_last', 0x32),
(2225, 188, 'page_footer', 0x6e6f726d616c),
(2224, 188, 'page_title', 0x6e6f726d616c),
(2223, 188, 'page_header', 0x6e6f726d616c),
(700, 188, 'page_featured', 0x6e6f6e65),
(701, 188, '_wp_page_template', 0x64656661756c74),
(702, 188, '_edit_lock', 0x313437383939393632363a32),
(703, 188, '_edit_last', 0x32),
(2243, 190, 'page_header', 0x6e6f726d616c),
(2244, 190, 'page_title', 0x6e6f726d616c),
(2245, 190, 'page_footer', 0x6e6f726d616c),
(710, 190, 'page_featured', 0x6e6f6e65),
(711, 190, '_wp_page_template', 0x64656661756c74),
(712, 190, '_edit_lock', 0x313437383939393534303a32),
(713, 190, '_edit_last', 0x32),
(2247, 192, 'page_header', 0x6e6f726d616c),
(2248, 192, 'page_title', 0x6e6f726d616c),
(2249, 192, 'page_footer', 0x6e6f726d616c),
(723, 192, 'page_featured', 0x6e6f6e65),
(724, 192, '_wp_page_template', 0x64656661756c74),
(725, 192, '_edit_lock', 0x313437383939393537323a32),
(726, 192, '_edit_last', 0x32),
(2251, 194, 'page_header', 0x6e6f726d616c),
(2252, 194, 'page_title', 0x6e6f726d616c),
(2253, 194, 'page_footer', 0x6e6f726d616c),
(739, 194, 'page_featured', 0x6e6f6e65),
(740, 194, '_wp_page_template', 0x64656661756c74),
(741, 194, '_edit_lock', 0x313437383939393535343a32),
(742, 194, '_edit_last', 0x32),
(2255, 196, 'page_header', 0x6e6f726d616c),
(2256, 196, 'page_title', 0x6e6f726d616c),
(2257, 196, 'page_footer', 0x6e6f726d616c),
(758, 196, 'page_featured', 0x6e6f6e65),
(759, 196, '_wp_page_template', 0x64656661756c74),
(760, 196, '_edit_lock', 0x313437383939393532313a32),
(761, 196, '_edit_last', 0x32),
(1394, 201, 'page_header', 0x6e6f726d616c),
(1395, 201, 'page_title', 0x6e6f726d616c),
(1396, 201, 'page_footer', 0x6e6f726d616c),
(840, 201, 'page_featured', 0x6e6f6e65),
(841, 201, '_wp_page_template', 0x64656661756c74),
(842, 201, '_edit_lock', 0x313437363930353133303a32),
(843, 201, '_edit_last', 0x32),
(1398, 204, 'page_header', 0x6e6f726d616c),
(1399, 204, 'page_title', 0x6e6f726d616c),
(1400, 204, 'page_footer', 0x6e6f726d616c),
(853, 204, 'page_featured', 0x6e6f6e65),
(854, 204, '_wp_page_template', 0x64656661756c74),
(855, 204, '_edit_lock', 0x313437383131323135373a32),
(856, 204, '_edit_last', 0x32),
(1402, 206, 'page_header', 0x6e6f726d616c),
(1403, 206, 'page_title', 0x6e6f726d616c),
(1404, 206, 'page_footer', 0x6e6f726d616c),
(866, 206, 'page_featured', 0x6e6f6e65),
(867, 206, '_wp_page_template', 0x64656661756c74),
(868, 206, '_edit_lock', 0x313437363930353137353a32),
(869, 206, '_edit_last', 0x32),
(1406, 208, 'page_header', 0x6e6f726d616c),
(1407, 208, 'page_title', 0x6e6f726d616c),
(1408, 208, 'page_footer', 0x6e6f726d616c),
(882, 208, 'page_featured', 0x6e6f6e65),
(883, 208, '_wp_page_template', 0x64656661756c74),
(884, 208, '_edit_lock', 0x313437363930353138363a32),
(885, 208, '_edit_last', 0x32),
(1410, 210, 'page_header', 0x6e6f726d616c),
(1411, 210, 'page_title', 0x6e6f726d616c),
(1412, 210, 'page_footer', 0x6e6f726d616c),
(901, 210, 'page_featured', 0x6e6f6e65),
(902, 210, '_wp_page_template', 0x64656661756c74),
(903, 210, '_edit_lock', 0x313437363930353139363a32),
(904, 210, '_edit_last', 0x32),
(1088, 227, '_menu_item_object_id', 0x323130),
(1087, 227, '_menu_item_menu_item_parent', ''),
(1086, 227, '_menu_item_type', 0x706f73745f74797065),
(1115, 226, '_menu_item_icon', ''),
(1084, 226, '_menu_item_url', ''),
(1083, 226, '_menu_item_xfn', ''),
(1082, 226, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1081, 226, '_menu_item_target', ''),
(1080, 226, '_menu_item_object', 0x70616765),
(1079, 226, '_menu_item_object_id', 0x323234),
(1078, 226, '_menu_item_menu_item_parent', ''),
(1070, 224, '_edit_last', 0x32),
(1069, 224, '_edit_lock', 0x313437363930393431313a32),
(1068, 224, '_wp_page_template', 0x64656661756c74),
(1067, 224, 'page_featured', 0x6e6f6e65),
(1265, 224, 'page_footer', 0x6e6f726d616c),
(1264, 224, 'page_title', 0x6e6f726d616c),
(1263, 224, 'page_header', 0x6e6f726d616c),
(1253, 86, 'page_footer', 0x6e6f726d616c),
(1252, 86, 'page_title', 0x6e6f726d616c),
(1251, 86, 'page_header', 0x6e6f726d616c),
(1060, 222, 'page_featured', 0x6e6f6e65),
(1256, 222, 'page_footer', 0x6e6f726d616c),
(1255, 222, 'page_title', 0x6e6f726d616c),
(1077, 226, '_menu_item_type', 0x706f73745f74797065),
(1055, 222, '_edit_lock', 0x313437363930393339353a32),
(1056, 222, '_edit_last', 0x32),
(1254, 222, 'page_header', 0x6e6f726d616c),
(1054, 222, '_wp_page_template', 0x64656661756c74),
(1089, 227, '_menu_item_object', 0x70616765),
(1090, 227, '_menu_item_target', ''),
(1091, 227, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1092, 227, '_menu_item_xfn', ''),
(1093, 227, '_menu_item_url', ''),
(1117, 227, '_menu_item_icon', ''),
(1095, 228, '_menu_item_type', 0x706f73745f74797065),
(1096, 228, '_menu_item_menu_item_parent', ''),
(1097, 228, '_menu_item_object_id', 0x313936),
(1098, 228, '_menu_item_object', 0x70616765),
(1099, 228, '_menu_item_target', ''),
(1100, 228, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1101, 228, '_menu_item_xfn', ''),
(1102, 228, '_menu_item_url', ''),
(1119, 228, '_menu_item_icon', ''),
(1104, 229, '_menu_item_type', 0x706f73745f74797065),
(1105, 229, '_menu_item_menu_item_parent', ''),
(1106, 229, '_menu_item_object_id', 0x313833),
(1107, 229, '_menu_item_object', 0x70616765),
(1108, 229, '_menu_item_target', ''),
(1109, 229, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1110, 229, '_menu_item_xfn', ''),
(1111, 229, '_menu_item_url', ''),
(1113, 229, '_menu_item_icon', ''),
(1114, 229, '_menu_item_style', 0x6e6f726d616c),
(1116, 226, '_menu_item_style', 0x6e6f726d616c),
(1118, 227, '_menu_item_style', 0x6e6f726d616c),
(1120, 228, '_menu_item_style', 0x6e6f726d616c),
(1121, 230, '_menu_item_type', 0x706f73745f74797065),
(1122, 230, '_menu_item_menu_item_parent', ''),
(1123, 230, '_menu_item_object_id', 0x323232),
(1124, 230, '_menu_item_object', 0x70616765),
(1125, 230, '_menu_item_target', ''),
(1126, 230, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1127, 230, '_menu_item_xfn', ''),
(1128, 230, '_menu_item_url', ''),
(1159, 230, '_menu_item_icon', ''),
(1130, 231, '_menu_item_type', 0x706f73745f74797065),
(1131, 231, '_menu_item_menu_item_parent', ''),
(1132, 231, '_menu_item_object_id', 0x323031),
(1133, 231, '_menu_item_object', 0x70616765),
(1134, 231, '_menu_item_target', ''),
(1135, 231, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1136, 231, '_menu_item_xfn', ''),
(1137, 231, '_menu_item_url', ''),
(1161, 231, '_menu_item_icon', ''),
(1139, 232, '_menu_item_type', 0x706f73745f74797065),
(1140, 232, '_menu_item_menu_item_parent', ''),
(1141, 232, '_menu_item_object_id', 0x313838),
(1142, 232, '_menu_item_object', 0x70616765),
(1143, 232, '_menu_item_target', ''),
(1144, 232, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1145, 232, '_menu_item_xfn', ''),
(1146, 232, '_menu_item_url', ''),
(1163, 232, '_menu_item_icon', ''),
(1148, 233, '_menu_item_type', 0x706f73745f74797065),
(1149, 233, '_menu_item_menu_item_parent', ''),
(1150, 233, '_menu_item_object_id', 0x313734),
(1151, 233, '_menu_item_object', 0x70616765),
(1152, 233, '_menu_item_target', ''),
(1153, 233, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1154, 233, '_menu_item_xfn', ''),
(1155, 233, '_menu_item_url', ''),
(1157, 233, '_menu_item_icon', ''),
(1158, 233, '_menu_item_style', 0x6e6f726d616c),
(1160, 230, '_menu_item_style', 0x6e6f726d616c),
(1162, 231, '_menu_item_style', 0x6e6f726d616c),
(1164, 232, '_menu_item_style', 0x6e6f726d616c),
(1165, 234, 'page_featured', 0x6e6f6e65),
(1257, 234, 'page_header', 0x6e6f726d616c),
(1258, 234, 'page_title', 0x6e6f726d616c),
(1259, 234, 'page_footer', 0x6e6f726d616c),
(1169, 234, '_wp_page_template', 0x64656661756c74),
(1170, 234, '_edit_lock', 0x313437373030333532323a32),
(1171, 234, '_edit_last', 0x32),
(1181, 236, '_menu_item_type', 0x706f73745f74797065),
(1182, 236, '_menu_item_menu_item_parent', ''),
(1183, 236, '_menu_item_object_id', 0x323334),
(1184, 236, '_menu_item_object', 0x70616765),
(1185, 236, '_menu_item_target', ''),
(1186, 236, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1187, 236, '_menu_item_xfn', ''),
(1188, 236, '_menu_item_url', ''),
(1221, 236, '_menu_item_icon', ''),
(1190, 237, '_menu_item_type', 0x706f73745f74797065),
(1191, 237, '_menu_item_menu_item_parent', ''),
(1192, 237, '_menu_item_object_id', 0x323034),
(1193, 237, '_menu_item_object', 0x70616765),
(1194, 237, '_menu_item_target', ''),
(1195, 237, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1196, 237, '_menu_item_xfn', ''),
(1197, 237, '_menu_item_url', ''),
(1219, 237, '_menu_item_icon', ''),
(1199, 238, '_menu_item_type', 0x706f73745f74797065),
(1200, 238, '_menu_item_menu_item_parent', ''),
(1201, 238, '_menu_item_object_id', 0x313930),
(1202, 238, '_menu_item_object', 0x70616765),
(1203, 238, '_menu_item_target', ''),
(1204, 238, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1205, 238, '_menu_item_xfn', ''),
(1206, 238, '_menu_item_url', ''),
(1223, 238, '_menu_item_icon', ''),
(1208, 239, '_menu_item_type', 0x706f73745f74797065),
(1209, 239, '_menu_item_menu_item_parent', ''),
(1210, 239, '_menu_item_object_id', 0x313736),
(1211, 239, '_menu_item_object', 0x70616765),
(1212, 239, '_menu_item_target', ''),
(1213, 239, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1214, 239, '_menu_item_xfn', ''),
(1215, 239, '_menu_item_url', ''),
(1217, 239, '_menu_item_icon', ''),
(1218, 239, '_menu_item_style', 0x6e6f726d616c),
(1220, 237, '_menu_item_style', 0x6e6f726d616c),
(1222, 236, '_menu_item_style', 0x6e6f726d616c),
(1224, 238, '_menu_item_style', 0x6e6f726d616c),
(1225, 240, 'page_featured', 0x6e6f6e65),
(1260, 240, 'page_header', 0x6e6f726d616c),
(1261, 240, 'page_title', 0x6e6f726d616c),
(1262, 240, 'page_footer', 0x6e6f726d616c),
(1229, 240, '_wp_page_template', 0x64656661756c74),
(1230, 240, '_edit_lock', 0x313437373030333733343a32),
(1231, 240, '_edit_last', 0x32),
(1244, 242, 'page_featured', 0x6e6f6e65),
(1245, 242, 'page_header', 0x6e6f726d616c),
(1246, 242, 'page_title', 0x6e6f726d616c),
(1247, 242, 'page_footer', 0x6e6f726d616c),
(1248, 242, '_wp_page_template', 0x64656661756c74),
(1249, 242, '_edit_lock', 0x313437373030333735383a32),
(1250, 242, '_edit_last', 0x32),
(1266, 244, '_menu_item_type', 0x706f73745f74797065),
(1267, 244, '_menu_item_menu_item_parent', ''),
(1268, 244, '_menu_item_object_id', 0x323430),
(1269, 244, '_menu_item_object', 0x70616765),
(1270, 244, '_menu_item_target', ''),
(1271, 244, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1272, 244, '_menu_item_xfn', ''),
(1273, 244, '_menu_item_url', ''),
(1306, 244, '_menu_item_icon', ''),
(1275, 245, '_menu_item_type', 0x706f73745f74797065),
(1276, 245, '_menu_item_menu_item_parent', ''),
(1277, 245, '_menu_item_object_id', 0x323036),
(1278, 245, '_menu_item_object', 0x70616765),
(1279, 245, '_menu_item_target', ''),
(1280, 245, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1281, 245, '_menu_item_xfn', ''),
(1282, 245, '_menu_item_url', ''),
(1304, 245, '_menu_item_icon', ''),
(1284, 246, '_menu_item_type', 0x706f73745f74797065),
(1285, 246, '_menu_item_menu_item_parent', ''),
(1286, 246, '_menu_item_object_id', 0x313932),
(1287, 246, '_menu_item_object', 0x70616765),
(1288, 246, '_menu_item_target', ''),
(1289, 246, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1290, 246, '_menu_item_xfn', ''),
(1291, 246, '_menu_item_url', ''),
(1308, 246, '_menu_item_icon', ''),
(1293, 247, '_menu_item_type', 0x706f73745f74797065),
(1294, 247, '_menu_item_menu_item_parent', ''),
(1295, 247, '_menu_item_object_id', 0x313739),
(1296, 247, '_menu_item_object', 0x70616765),
(1297, 247, '_menu_item_target', ''),
(1298, 247, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1299, 247, '_menu_item_xfn', ''),
(1300, 247, '_menu_item_url', ''),
(1302, 247, '_menu_item_icon', ''),
(1303, 247, '_menu_item_style', 0x6e6f726d616c),
(1305, 245, '_menu_item_style', 0x6e6f726d616c),
(1307, 244, '_menu_item_style', 0x6e6f726d616c),
(1309, 246, '_menu_item_style', 0x6e6f726d616c),
(1310, 248, '_menu_item_type', 0x706f73745f74797065),
(1311, 248, '_menu_item_menu_item_parent', ''),
(1312, 248, '_menu_item_object_id', 0x323432),
(1313, 248, '_menu_item_object', 0x70616765),
(1314, 248, '_menu_item_target', ''),
(1315, 248, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1316, 248, '_menu_item_xfn', ''),
(1317, 248, '_menu_item_url', ''),
(1350, 248, '_menu_item_icon', ''),
(1319, 249, '_menu_item_type', 0x706f73745f74797065),
(1320, 249, '_menu_item_menu_item_parent', ''),
(1321, 249, '_menu_item_object_id', 0x323038),
(1322, 249, '_menu_item_object', 0x70616765),
(1323, 249, '_menu_item_target', ''),
(1324, 249, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1325, 249, '_menu_item_xfn', ''),
(1326, 249, '_menu_item_url', ''),
(1348, 249, '_menu_item_icon', ''),
(1328, 250, '_menu_item_type', 0x706f73745f74797065),
(1329, 250, '_menu_item_menu_item_parent', ''),
(1330, 250, '_menu_item_object_id', 0x313934),
(1331, 250, '_menu_item_object', 0x70616765),
(1332, 250, '_menu_item_target', ''),
(1333, 250, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1334, 250, '_menu_item_xfn', ''),
(1335, 250, '_menu_item_url', ''),
(1352, 250, '_menu_item_icon', ''),
(1337, 251, '_menu_item_type', 0x706f73745f74797065),
(1338, 251, '_menu_item_menu_item_parent', ''),
(1339, 251, '_menu_item_object_id', 0x313831),
(1340, 251, '_menu_item_object', 0x70616765),
(1341, 251, '_menu_item_target', ''),
(1342, 251, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1343, 251, '_menu_item_xfn', ''),
(1344, 251, '_menu_item_url', ''),
(1346, 251, '_menu_item_icon', ''),
(1347, 251, '_menu_item_style', 0x6e6f726d616c),
(1349, 249, '_menu_item_style', 0x6e6f726d616c),
(1351, 248, '_menu_item_style', 0x6e6f726d616c),
(1353, 250, '_menu_item_style', 0x6e6f726d616c),
(1354, 252, '_edit_lock', 0x313437373035353838343a32),
(1355, 252, '_edit_last', 0x32),
(1356, 252, 'block_pages', 0x613a313a7b733a363a22616c77617973223b733a313a2231223b7d),
(1357, 252, 'block_color', 0x6c69676874),
(1358, 252, 'block_location', 0x63706f7468656d655f6265666f72655f666f6f746572),
(2043, 317, '_menu_item_target', ''),
(2042, 317, '_menu_item_object', 0x70616765),
(2041, 317, '_menu_item_object_id', 0x323935),
(1377, 99, '_et_single_header_bg', ''),
(1379, 94, '_et_single_header_bg', ''),
(2238, 90, 'layout_sidebar', 0x6e6f6e65),
(2059, 318, '_menu_item_icon', ''),
(1378, 86, '_et_single_header_bg', ''),
(1380, 90, '_et_single_header_bg', ''),
(1381, 90, 'et_ptemplate_settings', 0x613a333a7b733a31363a2265745f66756c6c776964746870616765223b693a313b733a32313a2265745f726567656e65726174655f6e756d62657273223b693a313b733a31313a2265745f656d61696c5f746f223b733a303a22223b7d),
(2055, 318, '_menu_item_classes', 0x613a313a7b693a303b733a303a22223b7d),
(1383, 259, '_edit_lock', 0x313437373935303538383a32),
(1384, 259, '_edit_last', 0x32),
(1385, 259, '_et_listing_lat', 0x35312e3032363238393735383035333132),
(1386, 259, '_et_listing_lng', 0x342e343831343133383031323639343638),
(1387, 259, '_et_listing_custom_address', ''),
(1388, 259, '_et_listing_description', ''),
(1389, 259, '_et_explorable_comments_rating', ''),
(1391, 88, 'et_ptemplate_settings', 0x613a323a7b733a31363a2265745f66756c6c776964746870616765223b693a303b733a32383a2265745f7074656d706c6174655f67616c6c6572795f70657270616765223b693a31303b7d),
(1393, 201, 'layout_sidebar', 0x6e6f6e65),
(1397, 204, 'layout_sidebar', 0x6e6f6e65),
(1401, 206, 'layout_sidebar', 0x6e6f6e65),
(1405, 208, 'layout_sidebar', 0x6e6f6e65),
(1409, 210, 'layout_sidebar', 0x6e6f6e65),
(1430, 265, '_wp_attached_file', 0x323031362f31312f4c6561666c65745f52532e706466),
(1431, 266, '_wp_attached_file', 0x323031362f31312f50726f737065637475735f52532e706466),
(1432, 267, '_wp_attached_file', 0x323031362f31312f70646669636f6e2e706e67),
(1433, 267, '_wp_attachment_metadata', 0x613a353a7b733a353a227769647468223b693a35303b733a363a22686569676874223b693a35303b733a343a2266696c65223b733a31393a22323031362f31312f70646669636f6e2e706e67223b733a353a2273697a6573223b613a303a7b7d733a31303a22696d6167655f6d657461223b613a31323a7b733a383a226170657274757265223b733a313a2230223b733a363a22637265646974223b733a303a22223b733a363a2263616d657261223b733a303a22223b733a373a2263617074696f6e223b733a303a22223b733a31373a22637265617465645f74696d657374616d70223b733a313a2230223b733a393a22636f70797269676874223b733a303a22223b733a31323a22666f63616c5f6c656e677468223b733a313a2230223b733a333a2269736f223b733a313a2230223b733a31333a22736875747465725f7370656564223b733a313a2230223b733a353a227469746c65223b733a303a22223b733a31313a226f7269656e746174696f6e223b733a313a2230223b733a383a226b6579776f726473223b613a303a7b7d7d7d),
(1480, 270, '_wp_attached_file', 0x323031362f31312f466f6c6465725f52532e706466),
(2222, 188, 'layout_sidebar', 0x6e6f6e65),
(2242, 190, 'layout_sidebar', 0x6e6f6e65),
(2246, 192, 'layout_sidebar', 0x6e6f6e65),
(2250, 194, 'layout_sidebar', 0x6e6f6e65),
(2254, 196, 'layout_sidebar', 0x6e6f6e65),
(1602, 276, '_form', 0x3c6c6162656c3e20596f7572204e616d6520287265717569726564290a202020205b746578742a20796f75722d6e616d655d203c2f6c6162656c3e0a0a3c6c6162656c3e20596f757220456d61696c20287265717569726564290a202020205b656d61696c2a20796f75722d656d61696c5d203c2f6c6162656c3e0a0a3c6c6162656c3e205375626a6563740a202020205b7465787420796f75722d7375626a6563745d203c2f6c6162656c3e0a0a3c6c6162656c3e20596f7572204d6573736167650a202020205b746578746172656120796f75722d6d6573736167655d203c2f6c6162656c3e0a0a5b7375626d6974202253656e64225d),
(1603, 276, '_mail', 0x613a383a7b733a373a227375626a656374223b733a36303a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f706520225b796f75722d7375626a6563745d22223b733a363a2273656e646572223b733a35393a225b796f75722d6e616d655d203c776f72647072657373406c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70653e223b733a343a22626f6479223b733a3232333a2246726f6d3a205b796f75722d6e616d655d203c5b796f75722d656d61696c5d3e0a5375626a6563743a205b796f75722d7375626a6563745d0a0a4d65737361676520426f64793a0a5b796f75722d6d6573736167655d0a0a2d2d0a5468697320652d6d61696c207761732073656e742066726f6d206120636f6e7461637420666f726d206f6e204a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f70652028687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f706529223b733a393a22726563697069656e74223b733a31383a22696374406a616e65676f6f64616c6c2e6265223b733a31383a226164646974696f6e616c5f68656164657273223b733a32323a225265706c792d546f3a205b796f75722d656d61696c5d223b733a31313a226174746163686d656e7473223b733a303a22223b733a383a227573655f68746d6c223b693a303b733a31333a226578636c7564655f626c616e6b223b693a303b7d),
(1604, 276, '_mail_2', 0x613a393a7b733a363a22616374697665223b623a303b733a373a227375626a656374223b733a36303a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f706520225b796f75722d7375626a6563745d22223b733a363a2273656e646572223b733a39313a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065203c776f72647072657373406c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70653e223b733a343a22626f6479223b733a3136353a224d65737361676520426f64793a0a5b796f75722d6d6573736167655d0a0a2d2d0a5468697320652d6d61696c207761732073656e742066726f6d206120636f6e7461637420666f726d206f6e204a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f70652028687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f706529223b733a393a22726563697069656e74223b733a31323a225b796f75722d656d61696c5d223b733a31383a226164646974696f6e616c5f68656164657273223b733a32383a225265706c792d546f3a20696374406a616e65676f6f64616c6c2e6265223b733a31313a226174746163686d656e7473223b733a303a22223b733a383a227573655f68746d6c223b693a303b733a31333a226578636c7564655f626c616e6b223b693a303b7d),
(1605, 276, '_messages', 0x613a383a7b733a31323a226d61696c5f73656e745f6f6b223b733a34353a225468616e6b20796f7520666f7220796f7572206d6573736167652e20497420686173206265656e2073656e742e223b733a31323a226d61696c5f73656e745f6e67223b733a37313a2254686572652077617320616e206572726f7220747279696e6720746f2073656e6420796f7572206d6573736167652e20506c656173652074727920616761696e206c617465722e223b733a31363a2276616c69646174696f6e5f6572726f72223b733a36313a224f6e65206f72206d6f7265206669656c6473206861766520616e206572726f722e20506c6561736520636865636b20616e642074727920616761696e2e223b733a343a227370616d223b733a37313a2254686572652077617320616e206572726f7220747279696e6720746f2073656e6420796f7572206d6573736167652e20506c656173652074727920616761696e206c617465722e223b733a31323a226163636570745f7465726d73223b733a36393a22596f75206d7573742061636365707420746865207465726d7320616e6420636f6e646974696f6e73206265666f72652073656e64696e6720796f7572206d6573736167652e223b733a31363a22696e76616c69645f7265717569726564223b733a32323a22546865206669656c642069732072657175697265642e223b733a31363a22696e76616c69645f746f6f5f6c6f6e67223b733a32323a22546865206669656c6420697320746f6f206c6f6e672e223b733a31373a22696e76616c69645f746f6f5f73686f7274223b733a32333a22546865206669656c6420697320746f6f2073686f72742e223b7d),
(1606, 276, '_additional_settings', NULL),
(1607, 276, '_locale', 0x656e5f4742),
(1608, 277, '_form', 0x3c6c6162656c3e20596f7572204e616d6520287265717569726564290a202020205b746578742a20796f75722d6e616d655d203c2f6c6162656c3e0a0a3c6c6162656c3e20596f757220456d61696c20287265717569726564290a202020205b656d61696c2a20796f75722d656d61696c5d203c2f6c6162656c3e0a0a3c6c6162656c3e205375626a6563740a202020205b7465787420796f75722d7375626a6563745d203c2f6c6162656c3e0a0a3c6c6162656c3e20596f7572204d6573736167650a202020205b746578746172656120796f75722d6d6573736167655d203c2f6c6162656c3e0a0a5b7375626d6974202253656e64225d),
(1609, 277, '_mail', 0x613a383a7b733a373a227375626a656374223b733a31363a22225b796f75722d7375626a6563745d22223b733a363a2273656e646572223b733a37353a22526f6f74732653686f6f7473204575726f70652077656273697465203c776f72647072657373406c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70653e223b733a343a22626f6479223b733a32373a225b796f75722d6d6573736167655d0a0a5b796f75722d6e616d655d223b733a393a22726563697069656e74223b733a32393a22726f6f7473616e6473686f6f7473406a616e65676f6f64616c6c2e6265223b733a31383a226164646974696f6e616c5f68656164657273223b733a32323a225265706c792d546f3a205b796f75722d656d61696c5d223b733a31313a226174746163686d656e7473223b733a303a22223b733a383a227573655f68746d6c223b623a303b733a31333a226578636c7564655f626c616e6b223b623a303b7d),
(1610, 277, '_mail_2', 0x613a393a7b733a363a22616374697665223b623a303b733a373a227375626a656374223b733a35313a224a616e6520476f6f64616c6c277320526f6f74732653686f6f7473204575726f706520225b796f75722d7375626a6563745d22223b733a363a2273656e646572223b733a38323a224a616e6520476f6f64616c6c277320526f6f74732653686f6f7473204575726f7065203c776f72647072657373406c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70653e223b733a343a22626f6479223b733a3136353a224d65737361676520426f64793a0a5b796f75722d6d6573736167655d0a0a2d2d0a5468697320652d6d61696c207761732073656e742066726f6d206120636f6e7461637420666f726d206f6e204a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f70652028687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f706529223b733a393a22726563697069656e74223b733a31323a225b796f75722d656d61696c5d223b733a31383a226164646974696f6e616c5f68656164657273223b733a32383a225265706c792d546f3a20696374406a616e65676f6f64616c6c2e6265223b733a31313a226174746163686d656e7473223b733a303a22223b733a383a227573655f68746d6c223b623a303b733a31333a226578636c7564655f626c616e6b223b623a303b7d),
(1611, 277, '_messages', 0x613a32333a7b733a31323a226d61696c5f73656e745f6f6b223b733a34353a225468616e6b20796f7520666f7220796f7572206d6573736167652e20497420686173206265656e2073656e742e223b733a31323a226d61696c5f73656e745f6e67223b733a37313a2254686572652077617320616e206572726f7220747279696e6720746f2073656e6420796f7572206d6573736167652e20506c656173652074727920616761696e206c617465722e223b733a31363a2276616c69646174696f6e5f6572726f72223b733a36313a224f6e65206f72206d6f7265206669656c6473206861766520616e206572726f722e20506c6561736520636865636b20616e642074727920616761696e2e223b733a343a227370616d223b733a37313a2254686572652077617320616e206572726f7220747279696e6720746f2073656e6420796f7572206d6573736167652e20506c656173652074727920616761696e206c617465722e223b733a31323a226163636570745f7465726d73223b733a36393a22596f75206d7573742061636365707420746865207465726d7320616e6420636f6e646974696f6e73206265666f72652073656e64696e6720796f7572206d6573736167652e223b733a31363a22696e76616c69645f7265717569726564223b733a32323a22546865206669656c642069732072657175697265642e223b733a31363a22696e76616c69645f746f6f5f6c6f6e67223b733a32323a22546865206669656c6420697320746f6f206c6f6e672e223b733a31373a22696e76616c69645f746f6f5f73686f7274223b733a32333a22546865206669656c6420697320746f6f2073686f72742e223b733a31323a22696e76616c69645f64617465223b733a32393a22546865206461746520666f726d617420697320696e636f72726563742e223b733a31343a22646174655f746f6f5f6561726c79223b733a34343a225468652064617465206973206265666f726520746865206561726c69657374206f6e6520616c6c6f7765642e223b733a31333a22646174655f746f6f5f6c617465223b733a34313a22546865206461746520697320616674657220746865206c6174657374206f6e6520616c6c6f7765642e223b733a31333a2275706c6f61645f6661696c6564223b733a34363a2254686572652077617320616e20756e6b6e6f776e206572726f722075706c6f6164696e67207468652066696c652e223b733a32343a2275706c6f61645f66696c655f747970655f696e76616c6964223b733a34393a22596f7520617265206e6f7420616c6c6f77656420746f2075706c6f61642066696c6573206f66207468697320747970652e223b733a32313a2275706c6f61645f66696c655f746f6f5f6c61726765223b733a32303a225468652066696c6520697320746f6f206269672e223b733a32333a2275706c6f61645f6661696c65645f7068705f6572726f72223b733a33383a2254686572652077617320616e206572726f722075706c6f6164696e67207468652066696c652e223b733a31343a22696e76616c69645f6e756d626572223b733a32393a22546865206e756d62657220666f726d617420697320696e76616c69642e223b733a31363a226e756d6265725f746f6f5f736d616c6c223b733a34373a22546865206e756d62657220697320736d616c6c6572207468616e20746865206d696e696d756d20616c6c6f7765642e223b733a31363a226e756d6265725f746f6f5f6c61726765223b733a34363a22546865206e756d626572206973206c6172676572207468616e20746865206d6178696d756d20616c6c6f7765642e223b733a32333a227175697a5f616e737765725f6e6f745f636f7272656374223b733a33363a2254686520616e7377657220746f20746865207175697a20697320696e636f72726563742e223b733a31373a22636170746368615f6e6f745f6d61746368223b733a33313a22596f757220656e746572656420636f646520697320696e636f72726563742e223b733a31333a22696e76616c69645f656d61696c223b733a33383a2254686520652d6d61696c206164647265737320656e746572656420697320696e76616c69642e223b733a31313a22696e76616c69645f75726c223b733a31393a225468652055524c20697320696e76616c69642e223b733a31313a22696e76616c69645f74656c223b733a33323a225468652074656c6570686f6e65206e756d62657220697320696e76616c69642e223b7d),
(1612, 277, '_additional_settings', ''),
(1613, 277, '_locale', 0x656e5f4742),
(2051, 318, '_menu_item_menu_item_parent', ''),
(2052, 318, '_menu_item_object_id', 0x323937),
(2053, 318, '_menu_item_object', 0x70616765),
(2054, 318, '_menu_item_target', ''),
(2624, 56, '_pll_strings_translations', 0x613a393a7b693a303b613a323a7b693a303b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b693a313b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b7d693a313b613a323a7b693a303b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b693a313b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b7d693a323b613a323a7b693a303b733a363a2246206a2c2059223b693a313b733a363a2246206a2c2059223b7d693a333b613a323a7b693a303b733a353a22673a692061223b693a313b733a353a22673a692061223b7d693a343b613a323a7b693a303b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b693a313b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b7d693a353b613a323a7b693a303b733a31383a22756e64657220636f6e737472756374696f6e223b693a313b733a31383a22756e64657220636f6e737472756374696f6e223b7d693a363b613a323a7b693a303b733a3232393a2220506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e0d0a223b693a313b733a3232363a22506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e223b7d693a373b613a323a7b693a303b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b693a313b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b7d693a383b613a323a7b693a303b733a363a224167656e6461223b693a313b733a363a224167656e6461223b7d7d),
(2625, 138, '_pll_strings_translations', 0x613a303a7b7d),
(2626, 138, '_pll_strings_translations', 0x613a303a7b7d),
(2627, 136, '_pll_strings_translations', 0x613a393a7b693a303b613a323a7b693a303b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b693a313b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b7d693a313b613a323a7b693a303b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b693a313b733a33373a224c612070726f6772616d6d65206a65756e6e657365206465204a616e6520476f6f64616c6c223b7d693a323b613a323a7b693a303b733a363a2246206a2c2059223b693a313b733a363a2246206a2c2059223b7d693a333b613a323a7b693a303b733a353a22673a692061223b693a313b733a353a22673a692061223b7d693a343b613a323a7b693a303b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b693a313b733a31343a2250726f6a6574206475206d6f6973223b7d693a353b613a323a7b693a303b733a31383a22756e64657220636f6e737472756374696f6e223b693a313b733a31353a22656e20636f6e737472756374696f6e223b7d693a363b613a323a7b693a303b733a3232393a2220506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e0d0a223b693a313b733a3233313a22566575696c6c657a2076697369746572206175737369203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e223b7d693a373b613a323a7b693a303b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b693a313b733a33373a22526f6f74732653686f6f7473206e6f7576656c6c6573206465206c612042656c6769717565223b7d693a383b613a323a7b693a303b733a363a224167656e6461223b693a313b733a363a224167656e6461223b7d7d),
(2628, 136, '_pll_strings_translations', 0x613a393a7b693a303b613a323a7b693a303b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b693a313b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b7d693a313b613a323a7b693a303b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b693a313b733a33373a224c612070726f6772616d6d65206a65756e6e657365206465204a616e6520476f6f64616c6c223b7d693a323b613a323a7b693a303b733a363a2246206a2c2059223b693a313b733a363a2246206a2c2059223b7d693a333b613a323a7b693a303b733a353a22673a692061223b693a313b733a353a22673a692061223b7d693a343b613a323a7b693a303b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b693a313b733a31343a2250726f6a6574206475206d6f6973223b7d693a353b613a323a7b693a303b733a31383a22756e64657220636f6e737472756374696f6e223b693a313b733a31353a22656e20636f6e737472756374696f6e223b7d693a363b613a323a7b693a303b733a3232393a2220506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e0d0a223b693a313b733a3233313a22566575696c6c657a2076697369746572206175737369203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e223b7d693a373b613a323a7b693a303b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b693a313b733a33373a22526f6f74732653686f6f7473206e6f7576656c6c6573206465206c612042656c6769717565223b7d693a383b613a323a7b693a303b733a363a224167656e6461223b693a313b733a363a224167656e6461223b7d7d);
INSERT INTO `wor1677_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES 
(2629, 139, '_pll_strings_translations', 0x613a303a7b7d),
(2630, 139, '_pll_strings_translations', 0x613a303a7b7d),
(2631, 61, '_pll_strings_translations', 0x613a303a7b7d),
(2632, 61, '_pll_strings_translations', 0x613a303a7b7d),
(2633, 99, 'inline_featured_image', ''),
(4697, 339, '_edit_lock', 0x313439323032363739323a32),
(4133, 807, 'accordions_icons_font_size', ''),
(4132, 807, 'accordions_icons_color', 0x23353635363536),
(4131, 807, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4130, 807, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4129, 807, 'accordions_themes', 0x666c6174),
(4128, 807, 'accordions_bg_img', ''),
(4127, 807, 'accordions_container_text_align', 0x6c656674),
(4126, 807, 'accordions_container_bg_color', ''),
(4125, 807, 'accordions_container_padding', ''),
(4124, 807, 'accordions_active_event', 0x636c69636b),
(4123, 807, 'accordions_heightStyle', 0x636f6e74656e74),
(4122, 807, 'accordions_collapsible', 0x74727565),
(4121, 807, '_edit_last', 0x32),
(4120, 807, 'inline_featured_image', ''),
(4119, 798, 'accordions_tabs_collapsible', 0x74727565),
(4118, 798, 'accordions_custom_css', 0x236163636f7264696f6e732d3739387b7d0a236163636f7264696f6e732d373938202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d373938202e6163636f7264696f6e2d636f6e74656e747b0a666f6e742d66616d696c793a47656e6576612c2056657264616e612c202244656a6156752053616e73222c2073616e732d73657269663b0a7d),
(4115, 798, 'accordions_content_title', ''),
(4116, 798, 'accordions_content_body', ''),
(4117, 798, 'accordions_hide', ''),
(4113, 798, 'accordions_items_content_font_size', 0x31347078),
(4114, 798, 'accordions_items_content_bg_color', ''),
(4171, 808, 'accordions_tabs_collapsible', 0x74727565),
(4170, 808, 'accordions_custom_css', 0x236163636f7264696f6e732d3830387b7d0a236163636f7264696f6e732d383038202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d383038202e6163636f7264696f6e2d636f6e74656e747b0a666f6e742d66616d696c793a47656e6576612c2056657264616e612c202244656a6156752053616e73222c2073616e732d73657269663b0a7d),
(4169, 808, 'accordions_hide', ''),
(4168, 808, 'accordions_content_body', ''),
(4167, 808, 'accordions_content_title', ''),
(4166, 808, 'accordions_items_content_bg_color', 0x23666666666666),
(4165, 808, 'accordions_items_content_font_size', 0x31347078),
(4164, 808, 'accordions_items_content_color', 0x23333333333333),
(4163, 808, 'accordions_items_title_font_size', 0x31347078),
(4162, 808, 'accordions_items_title_color', 0x23333333333333),
(4161, 808, 'accordions_active_bg_color', 0x23346238666533),
(4160, 808, 'accordions_default_bg_color', 0x23633962313864),
(4159, 808, 'accordions_icons_font_size', ''),
(4156, 808, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4157, 808, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4158, 808, 'accordions_icons_color', 0x23353635363536),
(4154, 808, 'accordions_bg_img', ''),
(4155, 808, 'accordions_themes', 0x666c6174),
(4215, 1118, 'accordions_items_title_font_size', 0x31347078),
(4214, 1118, 'accordions_items_title_color', 0x23333333333333),
(4213, 1118, 'accordions_active_bg_color', 0x23346238666533),
(4212, 1118, 'accordions_default_bg_color', 0x23633962313864),
(4211, 1118, 'accordions_icons_font_size', ''),
(4210, 1118, 'accordions_icons_color', 0x23353635363536),
(4209, 1118, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4208, 1118, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4207, 1118, 'accordions_themes', 0x666c6174),
(4206, 1118, 'accordions_bg_img', ''),
(4205, 1118, 'accordions_container_text_align', 0x6c656674),
(4204, 1118, 'accordions_container_bg_color', ''),
(4203, 1118, 'accordions_container_padding', ''),
(4202, 1118, 'accordions_active_event', 0x636c69636b),
(4201, 1118, 'accordions_heightStyle', 0x636f6e74656e74),
(4200, 1118, 'accordions_collapsible', 0x74727565),
(4197, 1116, 'accordions_tabs_collapsible', 0x74727565),
(4198, 1118, 'inline_featured_image', ''),
(4199, 1118, '_edit_last', 0x32),
(4257, 1411, 'accordions_container_text_align', 0x6c656674),
(4256, 1411, 'accordions_container_bg_color', ''),
(4255, 1411, 'accordions_container_padding', ''),
(4254, 1411, 'accordions_active_event', 0x636c69636b),
(4253, 1411, 'accordions_heightStyle', 0x636f6e74656e74),
(4252, 1411, 'accordions_collapsible', 0x74727565),
(4251, 1411, '_edit_last', 0x32),
(4250, 1411, 'inline_featured_image', ''),
(4249, 1409, 'accordions_tabs_collapsible', 0x74727565),
(4248, 1409, 'accordions_custom_css', 0x236163636f7264696f6e732d313430397b7d0a236163636f7264696f6e732d31343039202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d31343039202e6163636f7264696f6e2d636f6e74656e747b7d),
(4247, 1409, 'accordions_hide', ''),
(4246, 1409, 'accordions_content_body', ''),
(4245, 1409, 'accordions_content_title', ''),
(4244, 1409, 'accordions_items_content_bg_color', ''),
(4243, 1409, 'accordions_items_content_font_size', 0x31347078),
(4242, 1409, 'accordions_items_content_color', 0x23333333333333),
(4241, 1409, 'accordions_items_title_font_size', 0x31347078),
(4240, 1409, 'accordions_items_title_color', 0x23333333333333),
(4238, 1409, 'accordions_default_bg_color', 0x23633962313864),
(4239, 1409, 'accordions_active_bg_color', 0x23346238666533),
(4236, 1409, 'accordions_icons_color', 0x23353635363536),
(4237, 1409, 'accordions_icons_font_size', ''),
(4294, 1412, 'accordions_items_content_color', 0x23333333333333),
(4293, 1412, 'accordions_items_title_font_size', 0x31347078),
(4292, 1412, 'accordions_items_title_color', 0x23333333333333),
(4291, 1412, 'accordions_active_bg_color', 0x23346238666533),
(4290, 1412, 'accordions_default_bg_color', 0x23633962313864),
(4289, 1412, 'accordions_icons_font_size', ''),
(4288, 1412, 'accordions_icons_color', 0x23353635363536),
(4287, 1412, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4286, 1412, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4285, 1412, 'accordions_themes', 0x666c6174),
(4284, 1412, 'accordions_bg_img', ''),
(4283, 1412, 'accordions_container_text_align', 0x6c656674),
(4282, 1412, 'accordions_container_bg_color', ''),
(4281, 1412, 'accordions_container_padding', ''),
(4279, 1412, 'accordions_heightStyle', 0x636f6e74656e74),
(4280, 1412, 'accordions_active_event', 0x636c69636b),
(4276, 1412, 'inline_featured_image', ''),
(4277, 1412, '_edit_last', 0x32),
(4278, 1412, 'accordions_collapsible', 0x74727565),
(4338, 1414, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4337, 1414, 'accordions_themes', 0x666c6174),
(4336, 1414, 'accordions_bg_img', ''),
(4335, 1414, 'accordions_container_text_align', 0x6c656674),
(4334, 1414, 'accordions_container_bg_color', ''),
(4333, 1414, 'accordions_container_padding', ''),
(4332, 1414, 'accordions_active_event', 0x636c69636b),
(4331, 1414, 'accordions_heightStyle', 0x636f6e74656e74),
(4330, 1414, 'accordions_collapsible', 0x74727565),
(4329, 1414, '_edit_last', 0x32),
(4328, 1414, 'inline_featured_image', ''),
(4327, 1413, 'accordions_tabs_collapsible', 0x74727565),
(4326, 1413, 'accordions_custom_css', 0x236163636f7264696f6e732d313431337b7d0a236163636f7264696f6e732d31343133202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d31343133202e6163636f7264696f6e2d636f6e74656e747b7d),
(4325, 1413, 'accordions_hide', ''),
(4324, 1413, 'accordions_content_body', ''),
(4322, 1413, 'accordions_items_content_bg_color', ''),
(4323, 1413, 'accordions_content_title', ''),
(4321, 1413, 'accordions_items_content_font_size', 0x31347078),
(4378, 1415, 'accordions_custom_css', 0x236163636f7264696f6e732d313431357b7d0a236163636f7264696f6e732d31343135202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d31343135202e6163636f7264696f6e2d636f6e74656e747b7d),
(4377, 1415, 'accordions_hide', ''),
(4376, 1415, 'accordions_content_body', ''),
(4375, 1415, 'accordions_content_title', ''),
(4374, 1415, 'accordions_items_content_bg_color', ''),
(4373, 1415, 'accordions_items_content_font_size', 0x31347078),
(4372, 1415, 'accordions_items_content_color', 0x23333333333333),
(4371, 1415, 'accordions_items_title_font_size', 0x31347078),
(4370, 1415, 'accordions_items_title_color', 0x23333333333333),
(4369, 1415, 'accordions_active_bg_color', 0x23346238666533),
(4368, 1415, 'accordions_default_bg_color', 0x23633962313864),
(4367, 1415, 'accordions_icons_font_size', ''),
(4366, 1415, 'accordions_icons_color', 0x23353635363536),
(4365, 1415, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4364, 1415, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4363, 1415, 'accordions_themes', 0x666c6174),
(4362, 1415, 'accordions_bg_img', ''),
(4360, 1415, 'accordions_container_bg_color', ''),
(4361, 1415, 'accordions_container_text_align', 0x6c656674),
(4358, 1415, 'accordions_active_event', 0x636c69636b),
(4359, 1415, 'accordions_container_padding', ''),
(4416, 5464, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4415, 5464, 'accordions_themes', 0x666c6174),
(4414, 5464, 'accordions_bg_img', ''),
(4413, 5464, 'accordions_container_text_align', 0x6c656674),
(4412, 5464, 'accordions_container_bg_color', ''),
(4411, 5464, 'accordions_container_padding', ''),
(4410, 5464, 'accordions_active_event', 0x636c69636b),
(4409, 5464, 'accordions_heightStyle', 0x636f6e74656e74),
(4408, 5464, 'accordions_collapsible', 0x74727565),
(4407, 5464, '_edit_last', 0x32),
(4406, 5464, 'inline_featured_image', ''),
(4405, 5463, 'accordions_tabs_collapsible', 0x74727565),
(4404, 5463, 'accordions_custom_css', 0x236163636f7264696f6e732d353436337b7d0a236163636f7264696f6e732d35343633202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35343633202e6163636f7264696f6e2d636f6e74656e747b7d),
(4403, 5463, 'accordions_hide', ''),
(4402, 5463, 'accordions_content_body', ''),
(4401, 5463, 'accordions_content_title', ''),
(4399, 5463, 'accordions_items_content_font_size', 0x31347078),
(4400, 5463, 'accordions_items_content_bg_color', ''),
(4397, 5463, 'accordions_items_title_font_size', 0x31347078),
(4398, 5463, 'accordions_items_content_color', 0x23333333333333),
(4456, 5467, 'accordions_custom_css', 0x236163636f7264696f6e732d353436377b7d0a236163636f7264696f6e732d35343637202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35343637202e6163636f7264696f6e2d636f6e74656e747b7d),
(4455, 5467, 'accordions_hide', ''),
(4454, 5467, 'accordions_content_body', ''),
(4453, 5467, 'accordions_content_title', ''),
(4452, 5467, 'accordions_items_content_bg_color', ''),
(4451, 5467, 'accordions_items_content_font_size', 0x31347078),
(4450, 5467, 'accordions_items_content_color', 0x23333333333333),
(4449, 5467, 'accordions_items_title_font_size', 0x31347078),
(4448, 5467, 'accordions_items_title_color', 0x23333333333333),
(4447, 5467, 'accordions_active_bg_color', 0x23346238666533),
(4446, 5467, 'accordions_default_bg_color', 0x23633962313864),
(4445, 5467, 'accordions_icons_font_size', ''),
(4444, 5467, 'accordions_icons_color', 0x23353635363536),
(4443, 5467, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4442, 5467, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4440, 5467, 'accordions_bg_img', ''),
(4441, 5467, 'accordions_themes', 0x666c6174),
(4438, 5467, 'accordions_container_bg_color', ''),
(4439, 5467, 'accordions_container_text_align', 0x6c656674),
(4500, 5508, 'accordions_items_title_color', 0x23333333333333),
(4499, 5508, 'accordions_active_bg_color', 0x23346238666533),
(4498, 5508, 'accordions_default_bg_color', 0x23633962313864),
(4497, 5508, 'accordions_icons_font_size', ''),
(4496, 5508, 'accordions_icons_color', 0x23353635363536),
(4495, 5508, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4494, 5508, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4493, 5508, 'accordions_themes', 0x666c6174),
(4492, 5508, 'accordions_bg_img', ''),
(4491, 5508, 'accordions_container_text_align', 0x6c656674),
(4490, 5508, 'accordions_container_bg_color', ''),
(4489, 5508, 'accordions_container_padding', ''),
(4488, 5508, 'accordions_active_event', 0x636c69636b),
(4487, 5508, 'accordions_heightStyle', 0x636f6e74656e74),
(4486, 5508, 'accordions_collapsible', 0x74727565),
(4485, 5508, '_edit_last', 0x32),
(4483, 5506, 'accordions_tabs_collapsible', 0x74727565),
(4484, 5508, 'inline_featured_image', ''),
(4537, 5921, '_edit_last', 0x32),
(4536, 5921, 'inline_featured_image', ''),
(4535, 5509, 'accordions_tabs_collapsible', 0x74727565),
(4534, 5509, 'accordions_custom_css', 0x236163636f7264696f6e732d353530397b7d0a236163636f7264696f6e732d35353039202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35353039202e6163636f7264696f6e2d636f6e74656e747b7d),
(4533, 5509, 'accordions_hide', ''),
(4532, 5509, 'accordions_content_body', ''),
(4531, 5509, 'accordions_content_title', ''),
(4530, 5509, 'accordions_items_content_bg_color', ''),
(4529, 5509, 'accordions_items_content_font_size', 0x31347078),
(4528, 5509, 'accordions_items_content_color', 0x23333333333333),
(4527, 5509, 'accordions_items_title_font_size', 0x31347078),
(4526, 5509, 'accordions_items_title_color', 0x23333333333333),
(4525, 5509, 'accordions_active_bg_color', 0x23346238666533),
(4524, 5509, 'accordions_default_bg_color', 0x23633962313864),
(4523, 5509, 'accordions_icons_font_size', ''),
(4522, 5509, 'accordions_icons_color', 0x23353635363536),
(4520, 5509, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4521, 5509, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4518, 5509, 'accordions_bg_img', ''),
(4519, 5509, 'accordions_themes', 0x666c6174),
(4577, 5923, 'accordions_active_bg_color', 0x23346238666533),
(4576, 5923, 'accordions_default_bg_color', 0x23633962313864),
(4575, 5923, 'accordions_icons_font_size', ''),
(4574, 5923, 'accordions_icons_color', 0x23353635363536),
(4573, 5923, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4572, 5923, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4571, 5923, 'accordions_themes', 0x666c6174),
(4570, 5923, 'accordions_bg_img', ''),
(4569, 5923, 'accordions_container_text_align', 0x6c656674),
(4568, 5923, 'accordions_container_bg_color', ''),
(4567, 5923, 'accordions_container_padding', ''),
(4566, 5923, 'accordions_active_event', 0x636c69636b),
(4565, 5923, 'accordions_heightStyle', 0x636f6e74656e74),
(4564, 5923, 'accordions_collapsible', 0x74727565),
(4563, 5923, '_edit_last', 0x32),
(4562, 5923, 'inline_featured_image', ''),
(4561, 5921, 'accordions_tabs_collapsible', 0x74727565),
(4560, 5921, 'accordions_custom_css', 0x236163636f7264696f6e732d353932317b7d0a236163636f7264696f6e732d35393231202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35393231202e6163636f7264696f6e2d636f6e74656e747b7d),
(4615, 5959, '_edit_last', 0x32),
(4614, 5959, 'inline_featured_image', ''),
(4613, 5953, 'accordions_tabs_collapsible', 0x74727565),
(4612, 5953, 'accordions_custom_css', 0x236163636f7264696f6e732d353935337b7d0a236163636f7264696f6e732d35393533202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35393533202e6163636f7264696f6e2d636f6e74656e747b7d),
(4611, 5953, 'accordions_hide', ''),
(4610, 5953, 'accordions_content_body', ''),
(4609, 5953, 'accordions_content_title', ''),
(4608, 5953, 'accordions_items_content_bg_color', ''),
(4607, 5953, 'accordions_items_content_font_size', 0x31347078),
(4606, 5953, 'accordions_items_content_color', 0x23333333333333),
(4605, 5953, 'accordions_items_title_font_size', 0x31347078),
(4604, 5953, 'accordions_items_title_color', 0x23333333333333),
(4603, 5953, 'accordions_active_bg_color', 0x23346238666533),
(4602, 5953, 'accordions_default_bg_color', 0x23633962313864),
(4601, 5953, 'accordions_icons_font_size', ''),
(4600, 5953, 'accordions_icons_color', 0x23353635363536),
(4598, 5953, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4599, 5953, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4596, 5953, 'accordions_bg_img', ''),
(4597, 5953, 'accordions_themes', 0x666c6174),
(4657, 5961, 'accordions_items_title_font_size', 0x31347078),
(4656, 5961, 'accordions_items_title_color', 0x23333333333333),
(4655, 5961, 'accordions_active_bg_color', 0x23346238666533),
(4654, 5961, 'accordions_default_bg_color', 0x23633962313864),
(4653, 5961, 'accordions_icons_font_size', ''),
(4652, 5961, 'accordions_icons_color', 0x23353635363536),
(4651, 5961, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4650, 5961, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4649, 5961, 'accordions_themes', 0x666c6174),
(4648, 5961, 'accordions_bg_img', ''),
(4647, 5961, 'accordions_container_text_align', 0x6c656674),
(4646, 5961, 'accordions_container_bg_color', ''),
(4645, 5961, 'accordions_container_padding', ''),
(4644, 5961, 'accordions_active_event', 0x636c69636b),
(4643, 5961, 'accordions_heightStyle', 0x636f6e74656e74),
(4642, 5961, 'accordions_collapsible', 0x74727565),
(4641, 5961, '_edit_last', 0x32),
(4639, 5959, 'accordions_tabs_collapsible', 0x74727565),
(4640, 5961, 'inline_featured_image', ''),
(4691, 8110, 'accordions_tabs_collapsible', 0x74727565),
(4690, 8110, 'accordions_custom_css', 0x236163636f7264696f6e732d383131307b7d0a236163636f7264696f6e732d38313130202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d38313130202e6163636f7264696f6e2d636f6e74656e747b7d),
(4689, 8110, 'accordions_hide', ''),
(4688, 8110, 'accordions_content_body', ''),
(4687, 8110, 'accordions_content_title', 0x613a313a7b693a303b733a32303a22436c69637175657a20706f7572206f7576726972223b7d),
(4686, 8110, 'accordions_items_content_bg_color', ''),
(4685, 8110, 'accordions_items_content_font_size', 0x31347078),
(4684, 8110, 'accordions_items_content_color', 0x23333333333333),
(4683, 8110, 'accordions_items_title_font_size', 0x31347078),
(4682, 8110, 'accordions_items_title_color', 0x23333333333333),
(4680, 8110, 'accordions_default_bg_color', 0x23633962313864),
(4681, 8110, 'accordions_active_bg_color', 0x23346238666533),
(4678, 8110, 'accordions_icons_color', 0x23353635363536),
(4679, 8110, 'accordions_icons_font_size', ''),
(4658, 5961, 'accordions_items_content_color', 0x23333333333333),
(4638, 5959, 'accordions_custom_css', 0x236163636f7264696f6e732d353935397b7d0a236163636f7264696f6e732d35393539202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35393539202e6163636f7264696f6e2d636f6e74656e747b7d),
(4617, 5959, 'accordions_heightStyle', 0x636f6e74656e74),
(4616, 5959, 'accordions_collapsible', 0x74727565),
(4595, 5953, 'accordions_container_text_align', 0x6c656674),
(4578, 5923, 'accordions_items_title_color', 0x23333333333333),
(4559, 5921, 'accordions_hide', ''),
(4539, 5921, 'accordions_heightStyle', 0x636f6e74656e74),
(4538, 5921, 'accordions_collapsible', 0x74727565),
(4517, 5509, 'accordions_container_text_align', 0x6c656674),
(4501, 5508, 'accordions_items_title_font_size', 0x31347078),
(4482, 5506, 'accordions_custom_css', 0x236163636f7264696f6e732d353530367b7d0a236163636f7264696f6e732d35353036202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35353036202e6163636f7264696f6e2d636f6e74656e747b7d),
(4457, 5467, 'accordions_tabs_collapsible', 0x74727565),
(4437, 5467, 'accordions_container_padding', ''),
(4295, 1412, 'accordions_items_content_font_size', 0x31347078),
(4258, 1411, 'accordions_bg_img', ''),
(4235, 1409, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4216, 1118, 'accordions_items_content_color', 0x23333333333333),
(4196, 1116, 'accordions_custom_css', 0x236163636f7264696f6e732d313131367b7d0a236163636f7264696f6e732d31313136202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d31313136202e6163636f7264696f6e2d636f6e74656e747b7d),
(4172, 1116, 'inline_featured_image', ''),
(4153, 808, 'accordions_container_text_align', 0x6c656674),
(4134, 807, 'accordions_default_bg_color', 0x23633962313864),
(4112, 798, 'accordions_items_content_color', 0x23333333333333),
(3421, 8115, '_wp_attached_file', 0x323031372f30322f4a616e652d616c6f6e652e6a7067),
(3422, 8115, '_wp_attachment_metadata', 0x613a353a7b733a353a227769647468223b693a3630303b733a363a22686569676874223b693a3432303b733a343a2266696c65223b733a32323a22323031372f30322f4a616e652d616c6f6e652e6a7067223b733a353a2273697a6573223b613a323a7b733a393a227468756d626e61696c223b613a343a7b733a343a2266696c65223b733a32323a224a616e652d616c6f6e652d323030783230302e6a7067223b733a353a227769647468223b693a3230303b733a363a22686569676874223b693a3230303b733a393a226d696d652d74797065223b733a31303a22696d6167652f6a706567223b7d733a393a22706f7274666f6c696f223b613a343a7b733a343a2266696c65223b733a32323a224a616e652d616c6f6e652d363030783335302e6a7067223b733a353a227769647468223b693a3630303b733a363a22686569676874223b693a3335303b733a393a226d696d652d74797065223b733a31303a22696d6167652f6a706567223b7d7d733a31303a22696d6167655f6d657461223b613a31323a7b733a383a226170657274757265223b733a333a22362e37223b733a363a22637265646974223b733a31313a22416c657820526976657374223b733a363a2263616d657261223b733a31333a2243616e6f6e20454f5320313044223b733a373a2263617074696f6e223b733a32393a224e61706c65732c20466c6f726964610a4665622e2032352c2032303036223b733a31373a22637265617465645f74696d657374616d70223b733a31303a2231313430383633363839223b733a393a22636f70797269676874223b733a33323a22416c6578205269766573740a556e72657374726963746564204a474920757365223b733a31323a22666f63616c5f6c656e677468223b733a333a22333030223b733a333a2269736f223b733a333a22343030223b733a31333a22736875747465725f7370656564223b733a31383a22302e30303238353731343238353731343239223b733a353a227469746c65223b733a32393a224e61706c65732c20466c6f726964610a4665622e2032352c2032303036223b733a31313a226f7269656e746174696f6e223b733a313a2231223b733a383a226b6579776f726473223b613a303a7b7d7d7d),
(4318, 1413, 'accordions_items_title_color', 0x23333333333333),
(4319, 1413, 'accordions_items_title_font_size', 0x31347078),
(4320, 1413, 'accordions_items_content_color', 0x23333333333333),
(4111, 798, 'accordions_items_title_font_size', 0x31347078),
(4110, 798, 'accordions_items_title_color', 0x23333333333333),
(4109, 798, 'accordions_active_bg_color', 0x23346238666533),
(4108, 798, 'accordions_default_bg_color', 0x23633962313864),
(4107, 798, 'accordions_icons_font_size', ''),
(4106, 798, 'accordions_icons_color', 0x23353635363536),
(4105, 798, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4104, 798, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4103, 798, 'accordions_themes', 0x666c6174),
(4102, 798, 'accordions_bg_img', ''),
(4101, 798, 'accordions_container_text_align', 0x6c656674),
(4100, 798, 'accordions_container_bg_color', ''),
(4099, 798, 'accordions_container_padding', 0x31307078),
(4098, 798, 'accordions_active_event', 0x636c69636b),
(4097, 798, 'accordions_heightStyle', 0x636f6e74656e74),
(4096, 798, 'accordions_collapsible', 0x74727565),
(4095, 798, '_edit_last', 0x32),
(4692, 8110, '_edit_lock', 0x313438373632353234383a32),
(4693, 5961, '_edit_lock', 0x313438373632353237323a32),
(4094, 798, 'inline_featured_image', ''),
(4694, 1413, '_edit_lock', 0x313438373632353239313a32),
(4152, 808, 'accordions_container_bg_color', ''),
(4151, 808, 'accordions_container_padding', ''),
(4150, 808, 'accordions_active_event', 0x636c69636b),
(4149, 808, 'accordions_heightStyle', 0x636f6e74656e74),
(4148, 808, 'accordions_collapsible', 0x74727565),
(4147, 808, '_edit_last', 0x32),
(4146, 808, 'inline_featured_image', ''),
(4145, 807, 'accordions_tabs_collapsible', 0x74727565),
(4144, 807, 'accordions_custom_css', 0x236163636f7264696f6e732d3830377b7d0a236163636f7264696f6e732d383037202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d383037202e6163636f7264696f6e2d636f6e74656e747b0a666f6e742d66616d696c793a47656e6576612c2056657264616e612c202244656a6156752053616e73222c2073616e732d73657269663b0a7d),
(4143, 807, 'accordions_hide', ''),
(4142, 807, 'accordions_content_body', ''),
(4141, 807, 'accordions_content_title', ''),
(4140, 807, 'accordions_items_content_bg_color', ''),
(4139, 807, 'accordions_items_content_font_size', 0x31347078),
(4136, 807, 'accordions_items_title_color', 0x23333333333333),
(4137, 807, 'accordions_items_title_font_size', 0x31347078),
(4138, 807, 'accordions_items_content_color', 0x23333333333333),
(4135, 807, 'accordions_active_bg_color', 0x23346238666533);
INSERT INTO `wor1677_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES 
(4195, 1116, 'accordions_hide', ''),
(4194, 1116, 'accordions_content_body', ''),
(4193, 1116, 'accordions_content_title', ''),
(4192, 1116, 'accordions_items_content_bg_color', ''),
(4191, 1116, 'accordions_items_content_font_size', 0x31347078),
(4190, 1116, 'accordions_items_content_color', 0x23333333333333),
(4189, 1116, 'accordions_items_title_font_size', 0x31347078),
(4188, 1116, 'accordions_items_title_color', 0x23333333333333),
(4187, 1116, 'accordions_active_bg_color', 0x23346238666533),
(4186, 1116, 'accordions_default_bg_color', 0x23633962313864),
(4185, 1116, 'accordions_icons_font_size', ''),
(4184, 1116, 'accordions_icons_color', 0x23353635363536),
(4183, 1116, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4182, 1116, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4181, 1116, 'accordions_themes', 0x666c6174),
(4180, 1116, 'accordions_bg_img', ''),
(4179, 1116, 'accordions_container_text_align', 0x6c656674),
(4176, 1116, 'accordions_active_event', 0x636c69636b),
(4177, 1116, 'accordions_container_padding', ''),
(4178, 1116, 'accordions_container_bg_color', ''),
(4173, 1116, '_edit_last', 0x32),
(4174, 1116, 'accordions_collapsible', 0x74727565),
(4175, 1116, 'accordions_heightStyle', 0x636f6e74656e74),
(4234, 1409, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4233, 1409, 'accordions_themes', 0x666c6174),
(4232, 1409, 'accordions_bg_img', ''),
(4231, 1409, 'accordions_container_text_align', 0x6c656674),
(4230, 1409, 'accordions_container_bg_color', ''),
(4229, 1409, 'accordions_container_padding', ''),
(4228, 1409, 'accordions_active_event', 0x636c69636b),
(4227, 1409, 'accordions_heightStyle', 0x636f6e74656e74),
(4226, 1409, 'accordions_collapsible', 0x74727565),
(4225, 1409, '_edit_last', 0x32),
(4224, 1409, 'inline_featured_image', ''),
(4223, 1118, 'accordions_tabs_collapsible', 0x74727565),
(4222, 1118, 'accordions_custom_css', 0x236163636f7264696f6e732d313131387b7d0a236163636f7264696f6e732d31313138202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d31313138202e6163636f7264696f6e2d636f6e74656e747b7d),
(4221, 1118, 'accordions_hide', ''),
(4219, 1118, 'accordions_content_title', ''),
(4220, 1118, 'accordions_content_body', ''),
(4217, 1118, 'accordions_items_content_font_size', 0x31347078),
(4218, 1118, 'accordions_items_content_bg_color', ''),
(4275, 1411, 'accordions_tabs_collapsible', 0x74727565),
(4274, 1411, 'accordions_custom_css', 0x236163636f7264696f6e732d313431317b7d0a236163636f7264696f6e732d31343131202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d31343131202e6163636f7264696f6e2d636f6e74656e747b7d),
(4273, 1411, 'accordions_hide', ''),
(4272, 1411, 'accordions_content_body', ''),
(4271, 1411, 'accordions_content_title', ''),
(4270, 1411, 'accordions_items_content_bg_color', ''),
(4269, 1411, 'accordions_items_content_font_size', 0x31347078),
(4268, 1411, 'accordions_items_content_color', 0x23333333333333),
(4267, 1411, 'accordions_items_title_font_size', 0x31347078),
(4266, 1411, 'accordions_items_title_color', 0x23333333333333),
(4265, 1411, 'accordions_active_bg_color', 0x23346238666533),
(4264, 1411, 'accordions_default_bg_color', 0x23633962313864),
(4263, 1411, 'accordions_icons_font_size', ''),
(4261, 1411, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4262, 1411, 'accordions_icons_color', 0x23353635363536),
(4259, 1411, 'accordions_themes', 0x666c6174),
(4260, 1411, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4317, 1413, 'accordions_active_bg_color', 0x23346238666533),
(4316, 1413, 'accordions_default_bg_color', 0x23633962313864),
(4315, 1413, 'accordions_icons_font_size', ''),
(4314, 1413, 'accordions_icons_color', 0x23353635363536),
(4313, 1413, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4312, 1413, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4311, 1413, 'accordions_themes', 0x666c6174),
(4310, 1413, 'accordions_bg_img', ''),
(4309, 1413, 'accordions_container_text_align', 0x6c656674),
(4308, 1413, 'accordions_container_bg_color', ''),
(4307, 1413, 'accordions_container_padding', ''),
(4306, 1413, 'accordions_active_event', 0x636c69636b),
(4305, 1413, 'accordions_heightStyle', 0x636f6e74656e74),
(4304, 1413, 'accordions_collapsible', 0x74727565),
(4303, 1413, '_edit_last', 0x32),
(4302, 1413, 'inline_featured_image', ''),
(4301, 1412, 'accordions_tabs_collapsible', 0x74727565),
(4297, 1412, 'accordions_content_title', ''),
(4298, 1412, 'accordions_content_body', ''),
(4299, 1412, 'accordions_hide', ''),
(4300, 1412, 'accordions_custom_css', 0x236163636f7264696f6e732d313431327b7d0a236163636f7264696f6e732d31343132202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d31343132202e6163636f7264696f6e2d636f6e74656e747b7d),
(4357, 1415, 'accordions_heightStyle', 0x636f6e74656e74),
(4356, 1415, 'accordions_collapsible', 0x74727565),
(4355, 1415, '_edit_last', 0x32),
(4354, 1415, 'inline_featured_image', ''),
(4353, 1414, 'accordions_tabs_collapsible', 0x74727565),
(4352, 1414, 'accordions_custom_css', 0x236163636f7264696f6e732d313431347b7d0a236163636f7264696f6e732d31343134202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d31343134202e6163636f7264696f6e2d636f6e74656e747b7d),
(4351, 1414, 'accordions_hide', ''),
(4350, 1414, 'accordions_content_body', ''),
(4349, 1414, 'accordions_content_title', ''),
(4348, 1414, 'accordions_items_content_bg_color', ''),
(4347, 1414, 'accordions_items_content_font_size', 0x31347078),
(4346, 1414, 'accordions_items_content_color', 0x23333333333333),
(4345, 1414, 'accordions_items_title_font_size', 0x31347078),
(4343, 1414, 'accordions_active_bg_color', 0x23346238666533),
(4344, 1414, 'accordions_items_title_color', 0x23333333333333),
(4341, 1414, 'accordions_icons_font_size', ''),
(4342, 1414, 'accordions_default_bg_color', 0x23633962313864),
(4396, 5463, 'accordions_items_title_color', 0x23333333333333),
(4395, 5463, 'accordions_active_bg_color', 0x23346238666533),
(4394, 5463, 'accordions_default_bg_color', 0x23633962313864),
(4393, 5463, 'accordions_icons_font_size', ''),
(4392, 5463, 'accordions_icons_color', 0x23353635363536),
(4391, 5463, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4390, 5463, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4389, 5463, 'accordions_themes', 0x666c6174),
(4388, 5463, 'accordions_bg_img', ''),
(4387, 5463, 'accordions_container_text_align', 0x6c656674),
(4386, 5463, 'accordions_container_bg_color', ''),
(4385, 5463, 'accordions_container_padding', ''),
(4384, 5463, 'accordions_active_event', 0x636c69636b),
(4383, 5463, 'accordions_heightStyle', 0x636f6e74656e74),
(4382, 5463, 'accordions_collapsible', 0x74727565),
(4380, 5463, 'inline_featured_image', ''),
(4381, 5463, '_edit_last', 0x32),
(4379, 1415, 'accordions_tabs_collapsible', 0x74727565),
(4436, 5467, 'accordions_active_event', 0x636c69636b),
(4435, 5467, 'accordions_heightStyle', 0x636f6e74656e74),
(4434, 5467, 'accordions_collapsible', 0x74727565),
(4433, 5467, '_edit_last', 0x32),
(4432, 5467, 'inline_featured_image', ''),
(4431, 5464, 'accordions_tabs_collapsible', 0x74727565),
(4430, 5464, 'accordions_custom_css', 0x236163636f7264696f6e732d353436347b7d0a236163636f7264696f6e732d35343634202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35343634202e6163636f7264696f6e2d636f6e74656e747b7d),
(4429, 5464, 'accordions_hide', ''),
(4428, 5464, 'accordions_content_body', ''),
(4427, 5464, 'accordions_content_title', ''),
(4426, 5464, 'accordions_items_content_bg_color', ''),
(4425, 5464, 'accordions_items_content_font_size', 0x31347078),
(4424, 5464, 'accordions_items_content_color', 0x23333333333333),
(4423, 5464, 'accordions_items_title_font_size', 0x31347078),
(4422, 5464, 'accordions_items_title_color', 0x23333333333333),
(4421, 5464, 'accordions_active_bg_color', 0x23346238666533),
(4420, 5464, 'accordions_default_bg_color', 0x23633962313864),
(4418, 5464, 'accordions_icons_color', 0x23353635363536),
(4419, 5464, 'accordions_icons_font_size', ''),
(4417, 5464, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4481, 5506, 'accordions_hide', ''),
(4480, 5506, 'accordions_content_body', ''),
(4479, 5506, 'accordions_content_title', ''),
(4478, 5506, 'accordions_items_content_bg_color', ''),
(4477, 5506, 'accordions_items_content_font_size', 0x31347078),
(4476, 5506, 'accordions_items_content_color', 0x23333333333333),
(4475, 5506, 'accordions_items_title_font_size', 0x31347078),
(4474, 5506, 'accordions_items_title_color', 0x23333333333333),
(4473, 5506, 'accordions_active_bg_color', 0x23346238666533),
(4472, 5506, 'accordions_default_bg_color', 0x23633962313864),
(4471, 5506, 'accordions_icons_font_size', ''),
(4470, 5506, 'accordions_icons_color', 0x23353635363536),
(4469, 5506, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4468, 5506, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4467, 5506, 'accordions_themes', 0x666c6174),
(4466, 5506, 'accordions_bg_img', ''),
(4465, 5506, 'accordions_container_text_align', 0x6c656674),
(4463, 5506, 'accordions_container_padding', ''),
(4464, 5506, 'accordions_container_bg_color', ''),
(4458, 5506, 'inline_featured_image', ''),
(4459, 5506, '_edit_last', 0x32),
(4460, 5506, 'accordions_collapsible', 0x74727565),
(4461, 5506, 'accordions_heightStyle', 0x636f6e74656e74),
(4462, 5506, 'accordions_active_event', 0x636c69636b),
(4516, 5509, 'accordions_container_bg_color', ''),
(4515, 5509, 'accordions_container_padding', ''),
(4514, 5509, 'accordions_active_event', 0x636c69636b),
(4513, 5509, 'accordions_heightStyle', 0x636f6e74656e74),
(4512, 5509, 'accordions_collapsible', 0x74727565),
(4511, 5509, '_edit_last', 0x32),
(4510, 5509, 'inline_featured_image', ''),
(4509, 5508, 'accordions_tabs_collapsible', 0x74727565),
(4508, 5508, 'accordions_custom_css', 0x236163636f7264696f6e732d353530387b7d0a236163636f7264696f6e732d35353038202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35353038202e6163636f7264696f6e2d636f6e74656e747b7d),
(4507, 5508, 'accordions_hide', ''),
(4506, 5508, 'accordions_content_body', ''),
(4505, 5508, 'accordions_content_title', ''),
(4503, 5508, 'accordions_items_content_font_size', 0x31347078),
(4504, 5508, 'accordions_items_content_bg_color', ''),
(4502, 5508, 'accordions_items_content_color', 0x23333333333333),
(4558, 5921, 'accordions_content_body', ''),
(4557, 5921, 'accordions_content_title', 0x613a313a7b693a303b733a31353a22436c69636b20746f20657870616e64223b7d),
(4556, 5921, 'accordions_items_content_bg_color', ''),
(4555, 5921, 'accordions_items_content_font_size', 0x31347078),
(4554, 5921, 'accordions_items_content_color', 0x23333333333333),
(4553, 5921, 'accordions_items_title_font_size', 0x31347078),
(4552, 5921, 'accordions_items_title_color', 0x23333333333333),
(4551, 5921, 'accordions_active_bg_color', 0x23346238666533),
(4550, 5921, 'accordions_default_bg_color', 0x23633962313864),
(4549, 5921, 'accordions_icons_font_size', ''),
(4548, 5921, 'accordions_icons_color', 0x23353635363536),
(4547, 5921, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4546, 5921, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4545, 5921, 'accordions_themes', 0x666c6174),
(4544, 5921, 'accordions_bg_img', ''),
(4542, 5921, 'accordions_container_bg_color', ''),
(4543, 5921, 'accordions_container_text_align', 0x6c656674),
(4540, 5921, 'accordions_active_event', 0x636c69636b),
(4541, 5921, 'accordions_container_padding', ''),
(4594, 5953, 'accordions_container_bg_color', ''),
(4593, 5953, 'accordions_container_padding', ''),
(4592, 5953, 'accordions_active_event', 0x636c69636b),
(4591, 5953, 'accordions_heightStyle', 0x636f6e74656e74),
(4590, 5953, 'accordions_collapsible', 0x74727565),
(4589, 5953, '_edit_last', 0x32),
(4588, 5953, 'inline_featured_image', ''),
(4587, 5923, 'accordions_tabs_collapsible', 0x74727565),
(4586, 5923, 'accordions_custom_css', 0x236163636f7264696f6e732d353932337b7d0a236163636f7264696f6e732d35393233202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35393233202e6163636f7264696f6e2d636f6e74656e747b7d),
(4585, 5923, 'accordions_hide', ''),
(4584, 5923, 'accordions_content_body', ''),
(4583, 5923, 'accordions_content_title', 0x613a313a7b693a303b733a31373a224b6c696b206f6d207465206f70656e656e223b7d),
(4582, 5923, 'accordions_items_content_bg_color', ''),
(4580, 5923, 'accordions_items_content_color', 0x23333333333333),
(4581, 5923, 'accordions_items_content_font_size', 0x31347078),
(4579, 5923, 'accordions_items_title_font_size', 0x31347078),
(4637, 5959, 'accordions_hide', ''),
(4636, 5959, 'accordions_content_body', ''),
(4635, 5959, 'accordions_content_title', ''),
(4634, 5959, 'accordions_items_content_bg_color', ''),
(4633, 5959, 'accordions_items_content_font_size', 0x31347078),
(4632, 5959, 'accordions_items_content_color', 0x23333333333333),
(4631, 5959, 'accordions_items_title_font_size', 0x31347078),
(4630, 5959, 'accordions_items_title_color', 0x23333333333333),
(4629, 5959, 'accordions_active_bg_color', 0x23346238666533),
(4628, 5959, 'accordions_default_bg_color', 0x23633962313864),
(4627, 5959, 'accordions_icons_font_size', ''),
(4626, 5959, 'accordions_icons_color', 0x23353635363536),
(4625, 5959, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4624, 5959, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4623, 5959, 'accordions_themes', 0x666c6174),
(4622, 5959, 'accordions_bg_img', ''),
(4620, 5959, 'accordions_container_bg_color', ''),
(4621, 5959, 'accordions_container_text_align', 0x6c656674),
(4618, 5959, 'accordions_active_event', 0x636c69636b),
(4619, 5959, 'accordions_container_padding', ''),
(4677, 8110, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4676, 8110, 'accordions_icons_plus', 0x66612d63686576726f6e2d7570),
(4675, 8110, 'accordions_themes', 0x666c6174),
(4674, 8110, 'accordions_bg_img', ''),
(4673, 8110, 'accordions_container_text_align', 0x6c656674),
(4672, 8110, 'accordions_container_bg_color', ''),
(4671, 8110, 'accordions_container_padding', ''),
(4670, 8110, 'accordions_active_event', 0x636c69636b),
(4669, 8110, 'accordions_heightStyle', 0x636f6e74656e74),
(4668, 8110, 'accordions_collapsible', 0x74727565),
(4667, 8110, '_edit_last', 0x32),
(4666, 8110, 'inline_featured_image', ''),
(4665, 5961, 'accordions_tabs_collapsible', 0x74727565),
(4664, 5961, 'accordions_custom_css', 0x236163636f7264696f6e732d353936317b7d0a236163636f7264696f6e732d35393631202e6163636f7264696f6e732d686561647b7d0a236163636f7264696f6e732d35393631202e6163636f7264696f6e2d636f6e74656e747b7d),
(4663, 5961, 'accordions_hide', ''),
(4661, 5961, 'accordions_content_title', ''),
(4662, 5961, 'accordions_content_body', ''),
(4659, 5961, 'accordions_items_content_font_size', 0x31347078),
(4660, 5961, 'accordions_items_content_bg_color', ''),
(4340, 1414, 'accordions_icons_color', 0x23353635363536),
(4339, 1414, 'accordions_icons_minus', 0x66612d63686576726f6e2d646f776e),
(4296, 1412, 'accordions_items_content_bg_color', ''),
(4698, 8124, 'inline_featured_image', '');
/*!40000 ALTER TABLE `wor1677_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_posts`
--

DROP TABLE IF EXISTS `wor1677_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=8125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_posts`
--

LOCK TABLES `wor1677_posts` WRITE;
/*!40000 ALTER TABLE `wor1677_posts` DISABLE KEYS */;
INSERT INTO `wor1677_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES 
(57, 2, 0x323031362d30382d32332032323a34383a3531, 0x323031362d30382d32332032303a34383a3531, '', 0x47656e6572616c20746573742070616765, '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', 0x323031362d30382d32332032323a34383a3531, 0x323031362d30382d32332032303a34383a3531, '', 53, 'http://localhost:8080/rootsandshootseurope/53-revision-v1/', 0, 'revision', '', 0),
(58, 2, 0x323031362d30382d32332032323a34393a3132, 0x323031362d30382d32332032303a34393a3132, '', 0x50726f6a656374207479706520636f6e74726f6c, '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', 0x323031362d30382d32332032323a34393a3132, 0x323031362d30382d32332032303a34393a3132, '', 51, 'http://localhost:8080/rootsandshootseurope/51-revision-v1/', 0, 'revision', '', 0),
(55, 2, 0x323031362d30382d32332032323a34353a3236, 0x323031362d30382d32332032303a34353a3236, '', 0x50726f6a656374207479706573, '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', 0x323031362d30382d32332032323a34353a3236, 0x323031362d30382d32332032303a34353a3236, '', 47, 'http://localhost:8080/rootsandshootseurope/47-revision-v1/', 0, 'revision', '', 0),
(56, 2, 0x323031362d30382d32332032323a34363a3439, 0x323031362d30382d32332032303a34363a3439, 0x613a393a7b693a303b613a323a7b693a303b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b693a313b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b7d693a313b613a323a7b693a303b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b693a313b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b7d693a323b613a323a7b693a303b733a363a2246206a2c2059223b693a313b733a363a2246206a2c2059223b7d693a333b613a323a7b693a303b733a353a22673a692061223b693a313b733a353a22673a692061223b7d693a343b613a323a7b693a303b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b693a313b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b7d693a353b613a323a7b693a303b733a31383a22756e64657220636f6e737472756374696f6e223b693a313b733a31383a22756e64657220636f6e737472756374696f6e223b7d693a363b613a323a7b693a303b733a3232393a2220506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e0d0a223b693a313b733a3232363a22506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e223b7d693a373b613a323a7b693a303b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b693a313b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b7d693a383b613a323a7b693a303b733a363a224167656e6461223b693a313b733a363a224167656e6461223b7d7d, 0x706f6c796c616e675f6d6f5f34, '', 'private', 'closed', 'closed', '', 'polylang_mo_4', '', '', 0x323031362d31302d31392032313a34383a3135, 0x323031362d31302d31392031393a34383a3135, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=polylang_mo&#038;p=56', 0, 'polylang_mo', '', 0),
(346, 2, 0x323031362d31312d31332031383a33303a3434, 0x323031362d31312d31332031363a33303a3434, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d2252c3a97075626c6971756520746368c3a871756522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c696522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22526f7961756d6520556e6922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x44616e7320766f7472652070617973, '', 'inherit', 'closed', 'closed', '', '291-revision-v1', '', '', 0x323031362d31312d31332031383a33303a3434, 0x323031362d31312d31332031363a33303a3434, '', 291, 'http://localhost:8080/rootsandshootseurope/291-revision-v1/', 0, 'revision', '', 0),
(101, 2, 0x323031362d31302d30392032323a32343a3231, 0x323031362d31302d30392032303a32343a3231, 0x20, '', '', 'publish', 'closed', 'closed', '', '101', '', '', 0x323031362d31312d31332030323a35323a3038, 0x323031362d31312d31332030303a35323a3038, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=101', 1, 'nav_menu_item', '', 0),
(86, 2, 0x323031362d31302d30392032323a30343a3336, 0x323031362d31302d30392032303a30343a3336, 0x756e64657220636f6e737472756374696f6e, 0x4564756361746f72277320546f6f6c73, '', 'publish', 'closed', 'closed', '', 'educators-tools', '', '', 0x323031362d31302d33312032333a32333a3037, 0x323031362d31302d33312032313a32333a3037, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=86', 0, 'page', '', 0),
(49, 2, 0x323031362d30382d32312032323a32323a3539, 0x323031362d30382d32312032303a32323a3539, '', 0x50726f6a656374207479706520666f726d, '', 'private', 'closed', 'closed', '', 'project-type-form', '', '', 0x323031362d30382d32332032323a35323a3533, 0x323031362d30382d32332032303a35323a3533, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=49', 0, 'page', '', 0),
(50, 2, 0x323031362d30382d32312032323a32323a3539, 0x323031362d30382d32312032303a32323a3539, '', 0x5b3a656e5d50726f6a656374207479706520666f726d5b3a5d, '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', 0x323031362d30382d32312032323a32323a3539, 0x323031362d30382d32312032303a32323a3539, '', 49, 'http://localhost:8080/rootsandshootseurope/49-revision-v1/', 0, 'revision', '', 0),
(51, 2, 0x323031362d30382d32312032323a32333a3531, 0x323031362d30382d32312032303a32333a3531, '', 0x50726f6a656374207479706520636f6e74726f6c, '', 'private', 'closed', 'closed', '', 'project-type-control', '', '', 0x323031362d30382d32332032323a34393a3132, 0x323031362d30382d32332032303a34393a3132, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=51', 0, 'page', '', 0),
(52, 2, 0x323031362d30382d32312032323a32333a3531, 0x323031362d30382d32312032303a32333a3531, '', 0x5b3a656e5d50726f6a656374207479706520636f6e74726f6c5b3a5d, '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', 0x323031362d30382d32312032323a32333a3531, 0x323031362d30382d32312032303a32333a3531, '', 51, 'http://localhost:8080/rootsandshootseurope/51-revision-v1/', 0, 'revision', '', 0),
(53, 2, 0x323031362d30382d32322031313a32323a3039, 0x323031362d30382d32322030393a32323a3039, '', 0x47656e6572616c20746573742070616765, '', 'private', 'closed', 'closed', '', 'general-test-page', '', '', 0x323031362d30382d32332032323a34383a3531, 0x323031362d30382d32332032303a34383a3531, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=53', 0, 'page', '', 0),
(54, 2, 0x323031362d30382d32322031313a32323a3039, 0x323031362d30382d32322030393a32323a3039, '', 0x5b3a656e5d47656e6572616c207465737420706167655b3a5d, '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', 0x323031362d30382d32322031313a32323a3039, 0x323031362d30382d32322030393a32323a3039, '', 53, 'http://localhost:8080/rootsandshootseurope/53-revision-v1/', 0, 'revision', '', 0),
(48, 2, 0x323031362d30382d32312032323a32323a3239, 0x323031362d30382d32312032303a32323a3239, '', 0x5b3a656e5d50726f6a6563742074797065735b3a5d, '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', 0x323031362d30382d32312032323a32323a3239, 0x323031362d30382d32312032303a32323a3239, '', 47, 'http://localhost:8080/rootsandshootseurope/47-revision-v1/', 0, 'revision', '', 0),
(102, 2, 0x323031362d31302d30392032323a32353a3034, 0x323031362d31302d30392032303a32353a3034, 0x20, '', '', 'publish', 'closed', 'closed', '', '102', '', '', 0x323031362d31312d31332030323a35323a3038, 0x323031362d31312d31332030303a35323a3038, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=102', 5, 'nav_menu_item', '', 0),
(99, 2, 0x323031362d31302d30392032323a32323a3333, 0x323031362d31302d30392032303a32323a3333, 0x3c64697620636c6173733d22766964656f223e3c696672616d65207372633d2268747470733a2f2f706c617965722e76696d656f2e636f6d2f766964656f2f31393932383837323f7469746c653d3026616d703b62796c696e653d3026616d703b706f7274726169743d3022206865696768743d22333630222077696474683d223634302220616c6c6f7766756c6c73637265656e3d22223e3c2f696672616d653e3c2f6469763e0d0a0d0a3c646976207374796c653d22666c6f61743a2072696768743b206d61782d77696474683a2034303070783b206d617267696e3a20302e3735656d20302e3735656d20302e3735656d2032656d3b223e0d0a3c64697620636c6173733d22637573746f6d71756f7465223e0d0a0d0a3c696d6720636c6173733d22616c69676e6c6566742073697a652d66756c6c2077702d696d6167652d363035302220616c743d224a616e6522207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031372f30322f4a616e652d616c6f6e652e6a7067222077696474683d2232303022206865696768743d2231333922202f3e3c7374726f6e673e51756f74653a3c2f7374726f6e673e203c656d3e22526f6f747320637265657020756e64657267726f756e64206576657279776865726520616e64206d616b652061206669726d20666f756e646174696f6e2e2053686f6f7473207365656d2076657279207765616b2c2062757420746f20726561636820746865206c696768742c20746865792063616e20627265616b206f70656e20627269636b2077616c6c732e20496d6167696e6520746861742074686520627269636b2077616c6c732061726520616c6c207468652070726f626c656d73207765206861766520696e666c6963746564206f6e206f757220706c616e65742e2048756e6472656473206f662074686f7573616e6473206f6620726f6f747326616d703b73686f6f74732c2068756e6472656473206f662074686f7573616e6473206f6620796f756e672070656f706c652061726f756e642074686520776f726c642c2063616e20627265616b207468726f7567682074686573652077616c6c732e2057652043414e206368616e67652074686520776f726c643c2f656d3e220d0a3c70207374796c653d22746578742d616c69676e3a2072696768743b223e44722e204a616e6520476f6f64616c6c2c205068442c204442453c2f703e0d0a0d0a3c2f6469763e0d0a3c2f6469763e0d0a0d0a526f6f747326616d703b53686f6f747320697320746865204a616e6520476f6f64616c6c20496e73746974757465e280997320636974697a656ee280997320656475636174696f6e616c2070726f6772616d207468617420636f6e6e6563747320796f75746820746f206e617475726520616e6420656d706f77657273207468656d20746f206d616b6520706f736974697665206368616e676520696e20746865697220636f6d6d756e697469657320616e642074686520776f726c642e204974206973206261736564206f6e207468726565206d61696e2070696c6c6172733a20416e696d616c732c2050656f706c6520616e642074686520456e7669726f6e6d656e742028415045292e0d0a5468726f75676820526f6f747326616d703b53686f6f747320796f75746820646576656c6f707320616e20756e6465727374616e64696e67206f662074686520776f726c642061726f756e64207468656d20616e6420617265206368616c6c656e67656420746f20736f6c76652070726f626c656d732c207468657265666f726520616371756972696e672061206469766572736520736574206f6620736b696c6c7320616e64206b6e6f776c656467652e2054686973206769766573207468656d2070726163746963616c20657870657269656e63652c2061206e65772073656e7365206f662073656c6620616e6420612064656570657220636f6e6e656374696f6e20746f20746865206e61747572616c20776f726c642061732077656c6c2061732061206e6577206c6576656c206f6620636f6d6d69746d656e7420616e6420636f6d70617373696f6e20746861742072656d61696e732077697468207468656d20666f722074686520796561727320746f20636f6d652e0d0a0d0a576974682074686f7573616e6473206f6620796f756e672070656f706c6520696e206d6f7265207468616e2031333020636f756e74726965732c2074686520526f6f74732653686f6f747320676c6f62616c206e6574776f726b20636f6e6e6563747320796f757468206f6620616c6c20616765732077686f20736861726520612064657369726520746f2068656c70206d616b65206f757220776f726c6420612062657474657220706c6163652e204f757220706f77657266756c2c20796f7574682d64726976656e206e6574776f726b206973206120706c61636520776865726520796f75746820616e64206164756c747320636f6d6520746f67657468657220746f20736861726520696465617320616e6420696e737069726174696f6e2c20696d706c656d656e74207375636365737366756c20636f6d6d756e69747920736572766963652070726f6a6563747320616e6420706172746963697061746520696e207370656369616c206576656e747320616e6420676c6f62616c2063616d706169676e732e0d0a0d0a090d0a, 0x486f6d65, '', 'publish', 'closed', 'closed', '', 'home', '', '', 0x323031372d30322d32302032333a30393a3230, 0x323031372d30322d32302032313a30393a3230, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=99', 0, 'page', '', 0),
(8119, 2, 0x323031372d30322d32302032333a30393a3230, 0x323031372d30322d32302032313a30393a3230, 0x3c64697620636c6173733d22766964656f223e3c696672616d65207372633d2268747470733a2f2f706c617965722e76696d656f2e636f6d2f766964656f2f31393932383837323f7469746c653d3026616d703b62796c696e653d3026616d703b706f7274726169743d3022206865696768743d22333630222077696474683d223634302220616c6c6f7766756c6c73637265656e3d22223e3c2f696672616d653e3c2f6469763e0d0a0d0a3c646976207374796c653d22666c6f61743a2072696768743b206d61782d77696474683a2034303070783b206d617267696e3a20302e3735656d20302e3735656d20302e3735656d2032656d3b223e0d0a3c64697620636c6173733d22637573746f6d71756f7465223e0d0a0d0a3c696d6720636c6173733d22616c69676e6c6566742073697a652d66756c6c2077702d696d6167652d363035302220616c743d224a616e6522207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031372f30322f4a616e652d616c6f6e652e6a7067222077696474683d2232303022206865696768743d2231333922202f3e3c7374726f6e673e51756f74653a3c2f7374726f6e673e203c656d3e22526f6f747320637265657020756e64657267726f756e64206576657279776865726520616e64206d616b652061206669726d20666f756e646174696f6e2e2053686f6f7473207365656d2076657279207765616b2c2062757420746f20726561636820746865206c696768742c20746865792063616e20627265616b206f70656e20627269636b2077616c6c732e20496d6167696e6520746861742074686520627269636b2077616c6c732061726520616c6c207468652070726f626c656d73207765206861766520696e666c6963746564206f6e206f757220706c616e65742e2048756e6472656473206f662074686f7573616e6473206f6620726f6f747326616d703b73686f6f74732c2068756e6472656473206f662074686f7573616e6473206f6620796f756e672070656f706c652061726f756e642074686520776f726c642c2063616e20627265616b207468726f7567682074686573652077616c6c732e2057652043414e206368616e67652074686520776f726c643c2f656d3e220d0a3c70207374796c653d22746578742d616c69676e3a2072696768743b223e44722e204a616e6520476f6f64616c6c2c205068442c204442453c2f703e0d0a0d0a3c2f6469763e0d0a3c2f6469763e0d0a0d0a526f6f747326616d703b53686f6f747320697320746865204a616e6520476f6f64616c6c20496e73746974757465e280997320636974697a656ee280997320656475636174696f6e616c2070726f6772616d207468617420636f6e6e6563747320796f75746820746f206e617475726520616e6420656d706f77657273207468656d20746f206d616b6520706f736974697665206368616e676520696e20746865697220636f6d6d756e697469657320616e642074686520776f726c642e204974206973206261736564206f6e207468726565206d61696e2070696c6c6172733a20416e696d616c732c2050656f706c6520616e642074686520456e7669726f6e6d656e742028415045292e0d0a5468726f75676820526f6f747326616d703b53686f6f747320796f75746820646576656c6f707320616e20756e6465727374616e64696e67206f662074686520776f726c642061726f756e64207468656d20616e6420617265206368616c6c656e67656420746f20736f6c76652070726f626c656d732c207468657265666f726520616371756972696e672061206469766572736520736574206f6620736b696c6c7320616e64206b6e6f776c656467652e2054686973206769766573207468656d2070726163746963616c20657870657269656e63652c2061206e65772073656e7365206f662073656c6620616e6420612064656570657220636f6e6e656374696f6e20746f20746865206e61747572616c20776f726c642061732077656c6c2061732061206e6577206c6576656c206f6620636f6d6d69746d656e7420616e6420636f6d70617373696f6e20746861742072656d61696e732077697468207468656d20666f722074686520796561727320746f20636f6d652e0d0a0d0a576974682074686f7573616e6473206f6620796f756e672070656f706c6520696e206d6f7265207468616e2031333020636f756e74726965732c2074686520526f6f74732653686f6f747320676c6f62616c206e6574776f726b20636f6e6e6563747320796f757468206f6620616c6c20616765732077686f20736861726520612064657369726520746f2068656c70206d616b65206f757220776f726c6420612062657474657220706c6163652e204f757220706f77657266756c2c20796f7574682d64726976656e206e6574776f726b206973206120706c61636520776865726520796f75746820616e64206164756c747320636f6d6520746f67657468657220746f20736861726520696465617320616e6420696e737069726174696f6e2c20696d706c656d656e74207375636365737366756c20636f6d6d756e69747920736572766963652070726f6a6563747320616e6420706172746963697061746520696e207370656369616c206576656e747320616e6420676c6f62616c2063616d706169676e732e0d0a0d0a090d0a, 0x486f6d65, '', 'inherit', 'closed', 'closed', '', '99-revision-v1', '', '', 0x323031372d30322d32302032333a30393a3230, 0x323031372d30322d32302032313a30393a3230, '', 99, 'http://localhost:8080/rootsandshootseurope/99-revision-v1/', 0, 'revision', '', 0),
(293, 2, 0x323031362d31312d31332030323a34313a3230, 0x323031362d31312d31332030303a34313a3230, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d2254736a65636869c3ab22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e6b72696a6b22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c69c3ab22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d225370616e6a6522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22566572656e696764204b6f6e696e6b72696a6b22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e206a6f7577206c616e64, '', 'publish', 'closed', 'closed', '', 'in-jouw-land', '', '', 0x323031362d31312d31332031383a32383a3133, 0x323031362d31312d31332031363a32383a3133, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=293', 0, 'page', '', 0),
(180, 2, 0x323031362d31302d31392032303a34313a3431, 0x323031362d31302d31392031383a34313a3431, '', 0x43617361, '', 'inherit', 'closed', 'closed', '', '179-revision-v1', '', '', 0x323031362d31302d31392032303a34313a3431, 0x323031362d31302d31392031383a34313a3431, '', 179, 'http://localhost:8080/rootsandshootseurope/179-revision-v1/', 0, 'revision', '', 0),
(97, 2, 0x323031362d31302d30392032323a31353a3330, 0x323031362d31302d30392032303a31353a3330, '', 0x50726f6a65637473, '', 'publish', 'closed', 'closed', '', '97', '', '', 0x323031362d31312d31332030323a35323a3038, 0x323031362d31312d31332030303a35323a3038, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=97', 2, 'nav_menu_item', '', 0),
(71, 2, 0x323031362d30392d30312031303a32373a3534, 0x323031362d30392d30312030383a32373a3534, '', 0x50726f6a65637420666f726d, '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', 0x323031362d30392d30312031303a32373a3534, 0x323031362d30392d30312030383a32373a3534, '', 70, 'http://localhost:8080/rootsandshootseurope/70-revision-v1/', 0, 'revision', '', 0),
(47, 2, 0x323031362d30382d32312032323a32323a3239, 0x323031362d30382d32312032303a32323a3239, '', 0x50726f6a656374207479706573, '', 'private', 'closed', 'closed', '', 'project-types', '', '', 0x323031362d30382d32332032323a34353a3338, 0x323031362d30382d32332032303a34353a3338, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=47', 0, 'page', '', 0),
(212, 2, 0x323031362d31302d31392032313a32373a3339, 0x323031362d31302d31392031393a32373a3339, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a65637473, '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', 0x323031362d31302d31392032313a32373a3339, 0x323031362d31302d31392031393a32373a3339, '', 94, 'http://localhost:8080/rootsandshootseurope/94-revision-v1/', 0, 'revision', '', 0),
(169, 2, 0x323031362d31302d31392031363a30313a3433, 0x323031362d31302d31392031343a30313a3433, 0x3c68323e50726f6a656374732066726f6d2061726f756e642074686520776f726c643c2f68323e0d0a3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a65637473, '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', 0x323031362d31302d31392031363a30313a3433, 0x323031362d31302d31392031343a30313a3433, '', 94, 'http://localhost:8080/rootsandshootseurope/94-revision-v1/', 0, 'revision', '', 0),
(70, 2, 0x323031362d30392d30312031303a32373a3534, 0x323031362d30392d30312030383a32373a3534, '', 0x50726f6a65637420666f726d, '', 'publish', 'closed', 'closed', '', 'project-form', '', '', 0x323031362d30392d30312031303a33313a3034, 0x323031362d30392d30312030383a33313a3034, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=70', 0, 'page', '', 0),
(94, 2, 0x323031362d31302d30392032323a31343a3239, 0x323031362d31302d30392032303a31343a3239, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a656374732066726f6d2061726f756e642074686520776f726c64, '', 'publish', 'closed', 'closed', '', 'projects', '', '', 0x323031362d31312d30312030303a31323a3330, 0x323031362d31302d33312032323a31323a3330, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=94', 0, 'page', '', 0),
(66, 2, 0x323031362d30382d32352031333a35333a3137, 0x323031362d30382d32352031313a35333a3137, '', 0x436f6e66696775726174696f6e, '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', 0x323031362d30382d32352031333a35333a3137, 0x323031362d30382d32352031313a35333a3137, '', 64, 'http://localhost:8080/rootsandshootseurope/64-revision-v1/', 0, 'revision', '', 0),
(67, 2, 0x323031362d30382d32352031353a34343a3032, 0x323031362d30382d32352031333a34343a3032, '', 0x416c6c2050726f6a65637473, '', 'private', 'closed', 'closed', '', 'all-projects', '', '', 0x323031362d30392d30352031343a31373a3234, 0x323031362d30392d30352031323a31373a3234, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=67', 0, 'page', '', 0),
(59, 2, 0x323031362d30382d32332032323a34393a3437, 0x323031362d30382d32332032303a34393a3437, '', 0x50726f6a656374207479706520666f726d, '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', 0x323031362d30382d32332032323a34393a3437, 0x323031362d30382d32332032303a34393a3437, '', 49, 'http://localhost:8080/rootsandshootseurope/49-revision-v1/', 0, 'revision', '', 0),
(61, 2, 0x323031362d30382d32332032323a35393a3439, 0x323031362d30382d32332032303a35393a3439, 0x613a303a7b7d, 0x706f6c796c616e675f6d6f5f37, '', 'private', 'closed', 'closed', '', 'polylang_mo_7', '', '', 0x323031362d30382d32332032323a35393a3439, 0x323031362d30382d32332032303a35393a3439, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=polylang_mo&p=61', 0, 'polylang_mo', '', 0),
(62, 2, 0x323031362d30382d32332032333a30303a3535, 0x323031362d30382d32332032313a30303a3535, 0x6e656465726c616e6473, 0x4e656465726c616e6473652074657374706167696e61, '', 'publish', 'closed', 'closed', '', 'nederlandse-testpagina', '', '', 0x323031362d30382d32332032333a30303a3535, 0x323031362d30382d32332032313a30303a3535, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=62', 0, 'page', '', 0),
(63, 2, 0x323031362d30382d32332032333a30303a3535, 0x323031362d30382d32332032313a30303a3535, 0x6e656465726c616e6473, 0x4e656465726c616e6473652074657374706167696e61, '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', 0x323031362d30382d32332032333a30303a3535, 0x323031362d30382d32332032313a30303a3535, '', 62, 'http://localhost:8080/rootsandshootseurope/62-revision-v1/', 0, 'revision', '', 0),
(64, 2, 0x323031362d30382d32352031313a34323a3039, 0x323031362d30382d32352030393a34323a3039, '', 0x436f6e66696775726174696f6e, '', 'private', 'closed', 'closed', '', 'configuration', '', '', 0x323031362d30382d32352031333a35333a3330, 0x323031362d30382d32352031313a35333a3330, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=64', 0, 'page', '', 0),
(65, 2, 0x323031362d30382d32352031313a34323a3039, 0x323031362d30382d32352030393a34323a3039, '', 0x5461726765742067726f757073, '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', 0x323031362d30382d32352031313a34323a3039, 0x323031362d30382d32352030393a34323a3039, '', 64, 'http://localhost:8080/rootsandshootseurope/64-revision-v1/', 0, 'revision', '', 0),
(68, 2, 0x323031362d30382d32352031353a34343a3032, 0x323031362d30382d32352031333a34343a3032, '', 0x50726f6a65637473, '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', 0x323031362d30382d32352031353a34343a3032, 0x323031362d30382d32352031333a34343a3032, '', 67, 'http://localhost:8080/rootsandshootseurope/67-revision-v1/', 0, 'revision', '', 0),
(74, 2, 0x323031362d30392d30322031343a34303a3533, 0x323031362d30392d30322031323a34303a3533, '', 0x50726f6a65637420636f6e74726f6c, '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', 0x323031362d30392d30322031343a34303a3533, 0x323031362d30392d30322031323a34303a3533, '', 72, 'http://localhost:8080/rootsandshootseurope/72-revision-v1/', 0, 'revision', '', 0),
(72, 2, 0x323031362d30392d30312032323a33353a3530, 0x323031362d30392d30312032303a33353a3530, '', 0x50726f6a65637420636f6e74726f6c, '', 'private', 'closed', 'closed', '', 'project-control', '', '', 0x323031362d30392d30322031343a34303a3533, 0x323031362d30392d30322031323a34303a3533, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=72', 0, 'page', '', 0),
(73, 2, 0x323031362d30392d30312032323a33353a3530, 0x323031362d30392d30312032303a33353a3530, '', 0x50726f6a65637420636f6e74726f6c2070616765, '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', 0x323031362d30392d30312032323a33353a3530, 0x323031362d30392d30312032303a33353a3530, '', 72, 'http://localhost:8080/rootsandshootseurope/72-revision-v1/', 0, 'revision', '', 0),
(76, 2, 0x323031362d30392d30352031303a35363a3133, 0x323031362d30392d30352030383a35363a3133, '', 0x416c6c2050726f6a65637473, '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', 0x323031362d30392d30352031303a35363a3133, 0x323031362d30392d30352030383a35363a3133, '', 67, 'http://localhost:8080/rootsandshootseurope/67-revision-v1/', 0, 'revision', '', 0),
(77, 2, 0x323031362d30392d30352031343a31373a3536, 0x323031362d30392d30352031323a31373a3536, '', 0x41646d696e2070726f6a65637420636f6e74726f6c, '', 'private', 'closed', 'closed', '', 'admin-project-control', '', '', 0x323031362d30392d30352031343a33383a3337, 0x323031362d30392d30352031323a33383a3337, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=77', 0, 'page', '', 0),
(78, 2, 0x323031362d30392d30352031343a31373a3536, 0x323031362d30392d30352031323a31373a3536, '', 0x41646d696e2070726f6a65637420636f6e74726f6c, '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', 0x323031362d30392d30352031343a31373a3536, 0x323031362d30392d30352031323a31373a3536, '', 77, 'http://localhost:8080/rootsandshootseurope/77-revision-v1/', 0, 'revision', '', 0),
(79, 2, 0x323031362d30392d30352031343a32333a3538, 0x323031362d30392d30352031323a32333a3538, '', 0x50726f6a6563742064657461696c73, '', 'private', 'closed', 'closed', '', 'project-details', '', '', 0x323031362d30392d30352031343a32353a3531, 0x323031362d30392d30352031323a32353a3531, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=79', 0, 'page', '', 0),
(80, 2, 0x323031362d30392d30352031343a32333a3538, 0x323031362d30392d30352031323a32333a3538, '', 0x50726f6a6563742064657461696c73, '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', 0x323031362d30392d30352031343a32333a3538, 0x323031362d30392d30352031323a32333a3538, '', 79, 'http://localhost:8080/rootsandshootseurope/79-revision-v1/', 0, 'revision', '', 0),
(81, 2, 0x323031362d30392d30352031353a35363a3339, 0x323031362d30392d30352031333a35363a3339, '', 0x4d792070726f6a65637473, '', 'publish', 'closed', 'closed', '', 'my-projects', '', '', 0x323031362d30392d30352031353a35383a3334, 0x323031362d30392d30352031333a35383a3334, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=81', 0, 'page', '', 0),
(82, 2, 0x323031362d30392d30352031353a35363a3339, 0x323031362d30392d30352031333a35363a3339, '', 0x4d792070726f6a65637473, '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', 0x323031362d30392d30352031353a35363a3339, 0x323031362d30392d30352031333a35363a3339, '', 81, 'http://localhost:8080/rootsandshootseurope/81-revision-v1/', 0, 'revision', '', 0),
(87, 2, 0x323031362d31302d30392032323a30343a3336, 0x323031362d31302d30392032303a30343a3336, 0x756e64657220636f6e737472756374696f6e, 0x4564756361746f72277320546f6f6c73, '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', 0x323031362d31302d30392032323a30343a3336, 0x323031362d31302d30392032303a30343a3336, '', 86, 'http://localhost:8080/rootsandshootseurope/86-revision-v1/', 0, 'revision', '', 0),
(88, 2, 0x323031362d31302d30392032323a30353a3030, 0x323031362d31302d30392032303a30353a3030, 0x756e64657220636f6e737472756374696f6e, 0x43616d706169676e73, '', 'publish', 'closed', 'closed', '', 'campaigns', '', '', 0x323031362d31302d33312032333a35353a3231, 0x323031362d31302d33312032313a35353a3231, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=88', 0, 'page', '', 0),
(89, 2, 0x323031362d31302d30392032323a30353a3030, 0x323031362d31302d30392032303a30353a3030, 0x756e64657220636f6e737472756374696f6e, 0x43616d706169676e73, '', 'inherit', 'closed', 'closed', '', '88-revision-v1', '', '', 0x323031362d31302d30392032323a30353a3030, 0x323031362d31302d30392032303a30353a3030, '', 88, 'http://localhost:8080/rootsandshootseurope/88-revision-v1/', 0, 'revision', '', 0),
(90, 2, 0x323031362d31302d30392032323a30363a3034, 0x323031362d31302d30392032303a30363a3034, 0x54616e696120506572657a2069732074686520526f6f74732653686f6f747320636f6f7264696e61746f7220666f7220746865204a616e6520476f6f64616c6c20496e7374697469746520696e2042656c6769756d2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a3c7020636c6173733d226a757374696679223e446f776e6c6f61642074686520666c7965727320526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e456e676c697368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4475746368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4672656e6368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b0d0a, 0x436f6e74616374, '', 'publish', 'closed', 'closed', '', 'contact', '', '', 0x323031362d31312d31332030333a31323a3138, 0x323031362d31312d31332030313a31323a3138, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=90', 0, 'page', '', 0),
(93, 2, 0x323031362d31302d30392032323a30373a3431, 0x323031362d31302d30392032303a30373a3431, '', 0x4564756361746f72277320546f6f6c73, '', 'publish', 'closed', 'closed', '', 'educators-tools', '', '', 0x323031362d31312d31332030323a35323a3038, 0x323031362d31312d31332030303a35323a3038, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=93', 3, 'nav_menu_item', '', 0),
(136, 2, 0x323031362d31302d31332031323a32323a3037, 0x323031362d31302d31332031303a32323a3037, 0x613a393a7b693a303b613a323a7b693a303b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b693a313b733a34333a224a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065223b7d693a313b613a323a7b693a303b733a33353a224a616e6520476f6f64616c6c26233033393b7320796f7574682070726f6772616d6d65223b693a313b733a33373a224c612070726f6772616d6d65206a65756e6e657365206465204a616e6520476f6f64616c6c223b7d693a323b613a323a7b693a303b733a363a2246206a2c2059223b693a313b733a363a2246206a2c2059223b7d693a333b613a323a7b693a303b733a353a22673a692061223b693a313b733a353a22673a692061223b7d693a343b613a323a7b693a303b733a32303a2250726f6a656374206f6620746865206d6f6e7468223b693a313b733a31343a2250726f6a6574206475206d6f6973223b7d693a353b613a323a7b693a303b733a31383a22756e64657220636f6e737472756374696f6e223b693a313b733a31353a22656e20636f6e737472756374696f6e223b7d693a363b613a323a7b693a303b733a3232393a2220506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e0d0a223b693a313b733a3233313a22566575696c6c657a2076697369746572206175737369203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e223b7d693a373b613a323a7b693a303b733a33303a22526f6f74732653686f6f7473206e6577732066726f6d2042656c6769756d223b693a313b733a33373a22526f6f74732653686f6f7473206e6f7576656c6c6573206465206c612042656c6769717565223b7d693a383b613a323a7b693a303b733a363a224167656e6461223b693a313b733a363a224167656e6461223b7d7d, 0x706f6c796c616e675f6d6f5f3131, '', 'private', 'closed', 'closed', '', 'polylang_mo_11', '', '', 0x323031362d31302d32312030313a30373a3235, 0x323031362d31302d32302032333a30373a3235, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=polylang_mo&#038;p=136', 0, 'polylang_mo', '', 0),
(299, 2, 0x323031362d31312d31332030323a34323a3231, 0x323031362d31312d31332030303a34323a3231, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279202d204954, '', 'publish', 'closed', 'closed', '', 'in-your-country-it', '', '', 0x323031362d31312d31332031383a32373a3232, 0x323031362d31312d31332031363a32373a3232, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=299', 0, 'page', '', 0),
(345, 2, 0x323031362d31312d31332031383a32383a3133, 0x323031362d31312d31332031363a32383a3133, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d2254736a65636869c3ab22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e6b72696a6b22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c69c3ab22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d225370616e6a6522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22566572656e696764204b6f6e696e6b72696a6b22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e206a6f7577206c616e64, '', 'inherit', 'closed', 'closed', '', '293-revision-v1', '', '', 0x323031362d31312d31332031383a32383a3133, 0x323031362d31312d31332031363a32383a3133, '', 293, 'http://localhost:8080/rootsandshootseurope/293-revision-v1/', 0, 'revision', '', 0),
(289, 2, 0x323031362d31312d31332030323a34303a3531, 0x323031362d31312d31332030303a34303a3531, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2269742d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279, '', 'publish', 'closed', 'closed', '', 'in-your-country', '', '', 0x323031362d31312d31332031383a32313a3538, 0x323031362d31312d31332031363a32313a3538, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=289', 0, 'page', '', 0),
(342, 2, 0x323031362d31312d31332031383a32353a3238, 0x323031362d31312d31332031363a32353a3238, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d225473636865636869656e22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e6b726569636822202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c69656e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d225370616e69656e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d2256657265696e6967746573204bc3b66e6967726569636822202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20696872656d204c616e64, '', 'inherit', 'closed', 'closed', '', '295-revision-v1', '', '', 0x323031362d31312d31332031383a32353a3238, 0x323031362d31312d31332031363a32353a3238, '', 295, 'http://localhost:8080/rootsandshootseurope/295-revision-v1/', 0, 'revision', '', 0),
(330, 2, 0x323031362d31312d31332030333a31393a3130, 0x323031362d31312d31332030313a31393a3130, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d2252c3a97075626c6971756520746368c3a871756522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c696522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d2245737061676e6522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22526f7961756d6520556e6922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x44616e7320766f7472652070617973, '', 'inherit', 'closed', 'closed', '', '291-revision-v1', '', '', 0x323031362d31312d31332030333a31393a3130, 0x323031362d31312d31332030313a31393a3130, '', 291, 'http://localhost:8080/rootsandshootseurope/291-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wor1677_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES 
(291, 2, 0x323031362d31312d31332030323a34313a3036, 0x323031362d31312d31332030303a34313a3036, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d2252c3a97075626c6971756520746368c3a871756522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c696522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22526f7961756d6520556e6922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x44616e7320766f7472652070617973, '', 'publish', 'closed', 'closed', '', 'dans-votre-pays', '', '', 0x323031362d31312d31332031383a33303a3434, 0x323031362d31312d31332031363a33303a3434, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=291', 0, 'page', '', 0),
(138, 2, 0x323031362d31302d31332031323a32343a3237, 0x323031362d31302d31332031303a32343a3237, 0x613a303a7b7d, 0x706f6c796c616e675f6d6f5f3139, '', 'private', 'closed', 'closed', '', 'polylang_mo_19', '', '', 0x323031362d31302d31332031323a32343a3237, 0x323031362d31302d31332031303a32343a3237, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=polylang_mo&p=138', 0, 'polylang_mo', '', 0),
(177, 2, 0x323031362d31302d31392032303a33383a3031, 0x323031362d31302d31392031383a33383a3031, '', 0x5a75204861757365, '', 'inherit', 'closed', 'closed', '', '176-revision-v1', '', '', 0x323031362d31302d31392032303a33383a3031, 0x323031362d31302d31392031383a33383a3031, '', 176, 'http://localhost:8080/rootsandshootseurope/176-revision-v1/', 0, 'revision', '', 0),
(255, 2, 0x323031362d31302d32372031343a32373a3539, 0x323031362d31302d32372031323a32373a3539, '', 0x4c616e6775616765207377697463686572, '', 'publish', 'closed', 'closed', '', 'language-switcher', '', '', 0x323031362d31302d32382030303a35373a3038, 0x323031362d31302d32372032323a35373a3038, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=255', 1, 'nav_menu_item', '', 0),
(179, 2, 0x323031362d31302d31392032303a34313a3431, 0x323031362d31302d31392031383a34313a3431, 0x5370616e69736820686f6d652070616765, 0x43617361, '', 'publish', 'closed', 'closed', '', 'casa', '', '', 0x323031362d31302d31392032303a35323a3137, 0x323031362d31302d31392031383a35323a3137, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=179', 0, 'page', '', 0),
(139, 2, 0x323031362d31302d31332031323a32343a3430, 0x323031362d31302d31332031303a32343a3430, 0x613a303a7b7d, 0x706f6c796c616e675f6d6f5f3233, '', 'private', 'closed', 'closed', '', 'polylang_mo_23', '', '', 0x323031362d31302d31332031323a32343a3430, 0x323031362d31302d31332031303a32343a3430, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=polylang_mo&p=139', 0, 'polylang_mo', '', 0),
(137, 2, 0x323031362d31302d31332031323a32343a3130, 0x323031362d31302d31332031303a32343a3130, 0x613a303a7b7d, 0x706f6c796c616e675f6d6f5f3135, '', 'private', 'closed', 'closed', '', 'polylang_mo_15', '', '', 0x323031362d31302d31332031323a32343a3130, 0x323031362d31302d31332031303a32343a3130, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=polylang_mo&p=137', 0, 'polylang_mo', '', 0),
(176, 2, 0x323031362d31302d31392032303a33383a3031, 0x323031362d31302d31392031383a33383a3031, 0x4765726d616e2070616765, 0x53746172747365697465, '', 'publish', 'closed', 'closed', '', 'startseite', '', '', 0x323031362d31312d31332030333a32343a3433, 0x323031362d31312d31332030313a32343a3433, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=176', 0, 'page', '', 0),
(295, 2, 0x323031362d31312d31332030323a34313a3339, 0x323031362d31312d31332030303a34313a3339, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d225473636865636869656e22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e6b726569636822202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c69656e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d225370616e69656e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d2256657265696e6967746573204bc3b66e6967726569636822202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20696872656d204c616e64, '', 'publish', 'closed', 'closed', '', 'in-ihrem-land', '', '', 0x323031362d31312d31332031383a32353a3238, 0x323031362d31312d31332031363a32353a3238, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=295', 0, 'page', '', 0),
(337, 2, 0x323031362d31312d31332030333a32343a3433, 0x323031362d31312d31332030313a32343a3433, 0x4765726d616e2070616765, 0x53746172747365697465, '', 'inherit', 'closed', 'closed', '', '176-revision-v1', '', '', 0x323031362d31312d31332030333a32343a3433, 0x323031362d31312d31332030313a32343a3433, '', 176, 'http://localhost:8080/rootsandshootseurope/176-revision-v1/', 0, 'revision', '', 0),
(297, 2, 0x323031362d31312d31332030323a34323a3030, 0x323031362d31312d31332030303a34323a3030, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279202d204553, '', 'publish', 'closed', 'closed', '', 'in-your-country-es', '', '', 0x323031362d31312d31332031383a32363a3237, 0x323031362d31312d31332031363a32363a3237, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=297', 0, 'page', '', 0),
(344, 2, 0x323031362d31312d31332031383a32373a3232, 0x323031362d31312d31332031363a32373a3232, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279202d204954, '', 'inherit', 'closed', 'closed', '', '299-revision-v1', '', '', 0x323031362d31312d31332031383a32373a3232, 0x323031362d31312d31332031363a32373a3232, '', 299, 'http://localhost:8080/rootsandshootseurope/299-revision-v1/', 0, 'revision', '', 0),
(259, 2, 0x323031362d31302d33312032333a35303a3034, 0x323031362d31302d33312032313a35303a3034, '', 0x4d656368656c7365207363686f6f6c, '', 'publish', 'open', 'closed', '', 'mechelse-school', '', '', 0x323031362d31302d33312032333a35303a3034, 0x323031362d31302d33312032313a35303a3034, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=listing&#038;p=259', 0, 'listing', '', 0),
(174, 2, 0x323031362d31302d31392032303a33373a3338, 0x323031362d31302d31392031383a33373a3338, 0x4672656e63682070616765206163637565696c, 0x4163637565696c, '', 'publish', 'closed', 'closed', '', 'accueil', '', '', 0x323031362d31302d31392032303a35323a3433, 0x323031362d31302d31392031383a35323a3433, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=174', 0, 'page', '', 0),
(175, 2, 0x323031362d31302d31392032303a33373a3338, 0x323031362d31302d31392031383a33373a3338, '', 0x4163637565696c, '', 'inherit', 'closed', 'closed', '', '174-revision-v1', '', '', 0x323031362d31302d31392032303a33373a3338, 0x323031362d31302d31392031383a33373a3338, '', 174, 'http://localhost:8080/rootsandshootseurope/174-revision-v1/', 0, 'revision', '', 0),
(341, 2, 0x323031362d31312d31332031383a32333a3132, 0x323031362d31312d31332031363a32333a3132, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d2252c3a97075626c6971756520746368c3a871756522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c696522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d2245737061676e6522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22526f7961756d6520556e6922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x44616e7320766f7472652070617973, '', 'inherit', 'closed', 'closed', '', '291-revision-v1', '', '', 0x323031362d31312d31332031383a32333a3132, 0x323031362d31312d31332031363a32333a3132, '', 291, 'http://localhost:8080/rootsandshootseurope/291-revision-v1/', 0, 'revision', '', 0),
(336, 2, 0x323031362d31312d31332030333a32333a3339, 0x323031362d31312d31332030313a32333a3339, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d225473636865636869656e22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e6b726569636822202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c69656e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d225370616e69656e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d2256657265696e6967746573204bc3b66e6967726569636822202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20696872656d204c616e64, '', 'inherit', 'closed', 'closed', '', '295-revision-v1', '', '', 0x323031362d31312d31332030333a32333a3339, 0x323031362d31312d31332030313a32333a3339, '', 295, 'http://localhost:8080/rootsandshootseurope/295-revision-v1/', 0, 'revision', '', 0),
(5961, 2, 0x323031362d31322d31392031313a31363a3238, 0x323031362d31322d31392031303a31363a3238, '', 0x4472204a616e6520476f6f64616c6c204652, '', 'publish', 'closed', 'closed', '', 'dr-jane-goodall-fr', '', '', 0x323031362d31322d31392031313a31363a3238, 0x323031362d31322d31392031303a31363a3238, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5961', 0, 'accordions', '', 0),
(5959, 2, 0x323031362d31322d31392031303a35393a3036, 0x323031362d31322d31392030393a35393a3036, '', 0x4472204a616e6520476f6f64616c6c204e4c, '', 'publish', 'closed', 'closed', '', 'dr-jane-goodall-nl', '', '', 0x323031362d31322d31392031303a35393a3036, 0x323031362d31322d31392030393a35393a3036, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5959', 0, 'accordions', '', 0),
(798, 2, 0x323031362d31312d32382031363a33333a3231, 0x323031362d31312d32382031353a33333a3231, '', 0x4368696d70616e7365657320616e642067726561742061706573, '', 'publish', 'closed', 'closed', '', 'accordion1', '', '', 0x323031362d31312d32382031363a33333a3231, 0x323031362d31312d32382031353a33333a3231, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=798', 0, 'accordions', '', 0),
(807, 2, 0x323031362d31312d32382031373a35363a3033, 0x323031362d31312d32382031363a35363a3033, '', 0x4368696d70616e7a65657320656e2067726f7465206170656e, '', 'publish', 'closed', 'closed', '', 'accordion-chimpanzees-en-grote-apen', '', '', 0x323031362d31312d32382031373a35363a3033, 0x323031362d31312d32382031363a35363a3033, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=807', 0, 'accordions', '', 0),
(808, 2, 0x323031362d31312d32382032303a30373a3432, 0x323031362d31312d32382031393a30373a3432, '', 0x4368696d70616e7ac3a973206574206772616e642073696e676573, '', 'publish', 'closed', 'closed', '', 'chimpanzes-et-grand-singes', '', '', 0x323031362d31312d32382032303a30373a3432, 0x323031362d31312d32382031393a30373a3432, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=808', 0, 'accordions', '', 0),
(1116, 2, 0x323031362d31322d30332031373a35363a3139, 0x323031362d31322d30332031363a35363a3139, '', 0x476f6d62652d656e, '', 'publish', 'closed', 'closed', '', 'gombe-en', '', '', 0x323031362d31322d30332031373a35363a3139, 0x323031362d31322d30332031363a35363a3139, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=1116', 0, 'accordions', '', 0),
(1118, 2, 0x323031362d31322d30332031393a32363a3536, 0x323031362d31322d30332031383a32363a3536, '', 0x476f6d62652d6e6c, '', 'publish', 'closed', 'closed', '', 'gombe-nl', '', '', 0x323031362d31322d30332031393a32363a3536, 0x323031362d31322d30332031383a32363a3536, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=1118', 0, 'accordions', '', 0),
(1409, 2, 0x323031362d31322d30352032323a34363a3130, 0x323031362d31322d30352032313a34363a3130, '', 0x526f6f747326616d703b53686f6f7473, '', 'publish', 'closed', 'closed', '', 'rootsshoots', '', '', 0x323031362d31322d30352032323a34363a3130, 0x323031362d31322d30352032313a34363a3130, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=1409', 0, 'accordions', '', 0),
(1411, 2, 0x323031362d31322d30352032333a35383a3331, 0x323031362d31322d30352032323a35383a3331, '', 0x526f6f747326616d703b53686f6f7473204e4c, '', 'publish', 'closed', 'closed', '', 'rootsshoots-nl', '', '', 0x323031362d31322d30352032333a35383a3331, 0x323031362d31322d30352032323a35383a3331, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=1411', 0, 'accordions', '', 0),
(161, 2, 0x323031362d31302d31392031353a30333a3036, 0x323031362d31302d31392031333a30333a3036, '', 0x6c6f676f2d7273, '', 'inherit', 'open', 'closed', '', 'logo-rs', '', '', 0x323031362d31302d31392031353a30333a3036, 0x323031362d31302d31392031333a30333a3036, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/10/logo-RS.jpg', 0, 'attachment', 'image/jpeg', 0),
(162, 2, 0x323031362d31302d31392031353a30333a3533, 0x323031362d31302d31392031333a30333a3533, '', 0x6c6f676f2d7273, '', 'inherit', 'open', 'closed', '', 'logo-rs-2', '', '', 0x323031362d31302d31392031353a30333a3533, 0x323031362d31302d31392031333a30333a3533, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/10/logo-RS-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(163, 2, 0x323031362d31302d31392031353a31333a3035, 0x323031362d31302d31392031333a31333a3035, '', 0x6c6f676f2d7273, '', 'inherit', 'open', 'closed', '', 'logo-rs-3', '', '', 0x323031362d31302d31392031353a31333a3035, 0x323031362d31302d31392031333a31333a3035, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/10/logo-RS.png', 0, 'attachment', 'image/png', 0),
(181, 2, 0x323031362d31302d31392032303a34323a3037, 0x323031362d31302d31392031383a34323a3037, '', 0x4361736f, '', 'publish', 'closed', 'closed', '', 'caso', '', '', 0x323031362d31302d31392032303a34323a3037, 0x323031362d31302d31392031383a34323a3037, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=181', 0, 'page', '', 0),
(182, 2, 0x323031362d31302d31392032303a34323a3037, 0x323031362d31302d31392031383a34323a3037, '', 0x4361736f, '', 'inherit', 'closed', 'closed', '', '181-revision-v1', '', '', 0x323031362d31302d31392032303a34323a3037, 0x323031362d31302d31392031383a34323a3037, '', 181, 'http://localhost:8080/rootsandshootseurope/181-revision-v1/', 0, 'revision', '', 0),
(183, 2, 0x323031362d31302d31392032303a34323a3238, 0x323031362d31302d31392031383a34323a3238, 0x4e656465726c616e64736520686f6d6520706167696e61, 0x5468756973, '', 'publish', 'closed', 'closed', '', 'thuis', '', '', 0x323031362d31302d31392032303a35323a3030, 0x323031362d31302d31392031383a35323a3030, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=183', 0, 'page', '', 0),
(184, 2, 0x323031362d31302d31392032303a34323a3238, 0x323031362d31302d31392031383a34323a3238, '', 0x5468756973, '', 'inherit', 'closed', 'closed', '', '183-revision-v1', '', '', 0x323031362d31302d31392032303a34323a3238, 0x323031362d31302d31392031383a34323a3238, '', 183, 'http://localhost:8080/rootsandshootseurope/183-revision-v1/', 0, 'revision', '', 0),
(185, 2, 0x323031362d31302d31392032303a34343a3238, 0x323031362d31302d31392031383a34343a3238, 0x4672656e63682070616765, 0x4163637565696c, '', 'inherit', 'closed', 'closed', '', '174-revision-v1', '', '', 0x323031362d31302d31392032303a34343a3238, 0x323031362d31302d31392031383a34343a3238, '', 174, 'http://localhost:8080/rootsandshootseurope/174-revision-v1/', 0, 'revision', '', 0),
(213, 2, 0x323031362d31302d31392032313a32373a3531, 0x323031362d31302d31392031393a32373a3531, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a657473, '', 'inherit', 'closed', 'closed', '', '201-revision-v1', '', '', 0x323031362d31302d31392032313a32373a3531, 0x323031362d31302d31392031393a32373a3531, '', 201, 'http://localhost:8080/rootsandshootseurope/201-revision-v1/', 0, 'revision', '', 0),
(8118, 2, 0x323031372d30322d32302032333a30373a3033, 0x323031372d30322d32302032313a30373a3033, 0x3c64697620636c6173733d22766964656f223e3c696672616d65207372633d2268747470733a2f2f706c617965722e76696d656f2e636f6d2f766964656f2f31393932383837323f7469746c653d3026616d703b62796c696e653d3026616d703b706f7274726169743d3022206865696768743d22333630222077696474683d223634302220616c6c6f7766756c6c73637265656e3d22223e3c2f696672616d653e3c2f6469763e0d0a0d0a3c646976207374796c653d22666c6f61743a2072696768743b206d61782d77696474683a2034303070783b206d617267696e3a20302e3735656d20302e3735656d20302e3735656d2032656d3b223e0d0a3c64697620636c6173733d22637573746f6d71756f7465223e0d0a0d0a3c696d6720636c6173733d22616c69676e6c6566742073697a652d66756c6c2077702d696d6167652d363035302220616c743d224a616e6522207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031372f30322f4a616e652d616c6f6e652e6a7067222077696474683d2232303022206865696768743d2231333922202f3e3c7374726f6e673e51756f74653a3c2f7374726f6e673e203c656d3e22526f6f747320637265657020756e64657267726f756e64206576657279776865726520616e64206d616b652061206669726d20666f756e646174696f6e2e2053686f6f7473207365656d2076657279207765616b2c2062757420746f20726561636820746865206c696768742c20746865792063616e20627265616b206f70656e20627269636b2077616c6c732e20496d6167696e6520746861742074686520627269636b2077616c6c732061726520616c6c207468652070726f626c656d73207765206861766520696e666c6963746564206f6e206f757220706c616e65742e2048756e6472656473206f662074686f7573616e6473206f6620726f6f747326616d703b73686f6f74732c2068756e6472656473206f662074686f7573616e6473206f6620796f756e672070656f706c652061726f756e642074686520776f726c642c2063616e20627265616b207468726f7567682074686573652077616c6c732e2057652043414e206368616e67652074686520776f726c643c2f656d3e220d0a3c70207374796c653d22746578742d616c69676e3a2072696768743b223e44722e204a616e6520476f6f64616c6c2c205068442c204442453c2f703e0d0a0d0a3c2f6469763e0d0a3c2f6469763e0d0a0d0a526f6f747326616d703b53686f6f747320697320746865204a616e6520476f6f64616c6c20496e73746974757465e280997320636974697a656ee280997320656475636174696f6e616c2070726f6772616d207468617420636f6e6e6563747320796f75746820746f206e617475726520616e6420656d706f77657273207468656d20746f206d616b6520706f736974697665206368616e676520696e20746865697220636f6d6d756e697469657320616e642074686520776f726c642e204974206973206261736564206f6e207468726565206d61696e2070696c6c6172733a20416e696d616c732c2050656f706c6520616e642074686520456e7669726f6e6d656e742028415045292e0d0a5468726f75676820526f6f747326616d703b53686f6f747320796f75746820646576656c6f707320616e20756e6465727374616e64696e67206f662074686520776f726c642061726f756e64207468656d20616e6420617265206368616c6c656e67656420746f20736f6c76652070726f626c656d732c207468657265666f726520616371756972696e672061206469766572736520736574206f6620736b696c6c7320616e64206b6e6f776c656467652e2054686973206769766573207468656d2070726163746963616c20657870657269656e63652c2061206e65772073656e7365206f662073656c6620616e6420612064656570657220636f6e6e656374696f6e20746f20746865206e61747572616c20776f726c642061732077656c6c2061732061206e6577206c6576656c206f6620636f6d6d69746d656e7420616e6420636f6d70617373696f6e20746861742072656d61696e732077697468207468656d20666f722074686520796561727320746f20636f6d652e0d0a0d0a576974682074686f7573616e6473206f6620796f756e672070656f706c6520696e206d6f7265207468616e2031333020636f756e74726965732c2074686520526f6f74732653686f6f747320676c6f62616c206e6574776f726b20636f6e6e6563747320796f757468206f6620616c6c20616765732077686f20736861726520612064657369726520746f2068656c70206d616b65206f757220776f726c6420612062657474657220706c6163652e204f757220706f77657266756c2c20796f7574682d64726976656e206e6574776f726b206973206120706c61636520776865726520796f75746820616e64206164756c747320636f6d6520746f67657468657220746f20736861726520696465617320616e6420696e737069726174696f6e2c20696d706c656d656e74207375636365737366756c20636f6d6d756e69747920736572766963652070726f6a6563747320616e6420706172746963697061746520696e207370656369616c206576656e747320616e6420676c6f62616c2063616d706169676e732e0d0a0d0a090d0a5b6163636f7264696f6e732069643d2231343039225d0d0a, 0x486f6d65, '', 'inherit', 'closed', 'closed', '', '99-revision-v1', '', '', 0x323031372d30322d32302032333a30373a3033, 0x323031372d30322d32302032313a30373a3033, '', 99, 'http://localhost:8080/rootsandshootseurope/99-revision-v1/', 0, 'revision', '', 0),
(8117, 2, 0x323031372d30322d32302032333a30343a3036, 0x323031372d30322d32302032313a30343a3036, 0x3c64697620636c6173733d22766964656f223e3c696672616d65207372633d2268747470733a2f2f706c617965722e76696d656f2e636f6d2f766964656f2f31393932383837323f7469746c653d3026616d703b62796c696e653d3026616d703b706f7274726169743d3022206865696768743d22333630222077696474683d223634302220616c6c6f7766756c6c73637265656e3d22223e3c2f696672616d653e3c2f6469763e0d0a0d0a3c646976207374796c653d22666c6f61743a2072696768743b206d61782d77696474683a2034303070783b206d617267696e3a20302e3735656d20302e3735656d20302e3735656d2032656d3b223e0d0a3c64697620636c6173733d22637573746f6d71756f7465223e0d0a0d0a3c696d6720636c6173733d22616c69676e6c6566742073697a652d66756c6c2077702d696d6167652d363035302220616c743d224a616e6522207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031372f30322f4a616e652d616c6f6e652e6a7067222077696474683d2232303022206865696768743d2231333922202f3e3c7374726f6e673e51756f74653a3c2f7374726f6e673e203c656d3e22526f6f747320637265657020756e64657267726f756e64206576657279776865726520616e64206d616b652061206669726d20666f756e646174696f6e2e2053686f6f7473207365656d2076657279207765616b2c2062757420746f20726561636820746865206c696768742c20746865792063616e20627265616b206f70656e20627269636b2077616c6c732e20496d6167696e6520746861742074686520627269636b2077616c6c732061726520616c6c207468652070726f626c656d73207765206861766520696e666c6963746564206f6e206f757220706c616e65742e2048756e6472656473206f662074686f7573616e6473206f6620726f6f747326616d703b73686f6f74732c2068756e6472656473206f662074686f7573616e6473206f6620796f756e672070656f706c652061726f756e642074686520776f726c642c2063616e20627265616b207468726f7567682074686573652077616c6c732e2057652043414e206368616e67652074686520776f726c643c2f656d3e220d0a3c70207374796c653d22746578742d616c69676e3a2072696768743b223e44722e204a616e6520476f6f64616c6c2c205068442c204442453c2f703e0d0a0d0a3c2f6469763e0d0a3c2f6469763e0d0a0d0a526f6f747326616d703b53686f6f747320697320746865204a616e6520476f6f64616c6c20496e73746974757465e280997320636974697a656ee280997320656475636174696f6e616c2070726f6772616d207468617420636f6e6e6563747320796f75746820746f206e617475726520616e6420656d706f77657273207468656d20746f206d616b6520706f736974697665206368616e676520696e20746865697220636f6d6d756e697469657320616e642074686520776f726c642e204974206973206261736564206f6e207468726565206d61696e2070696c6c6172733a20416e696d616c732c2050656f706c6520616e642074686520456e7669726f6e6d656e742028415045292e0d0a5468726f75676820526f6f747326616d703b53686f6f747320796f75746820646576656c6f707320616e20756e6465727374616e64696e67206f662074686520776f726c642061726f756e64207468656d20616e6420617265206368616c6c656e67656420746f20736f6c76652070726f626c656d732c207468657265666f726520616371756972696e672061206469766572736520736574206f6620736b696c6c7320616e64206b6e6f776c656467652e2054686973206769766573207468656d2070726163746963616c20657870657269656e63652c2061206e65772073656e7365206f662073656c6620616e6420612064656570657220636f6e6e656374696f6e20746f20746865206e61747572616c20776f726c642061732077656c6c2061732061206e6577206c6576656c206f6620636f6d6d69746d656e7420616e6420636f6d70617373696f6e20746861742072656d61696e732077697468207468656d20666f722074686520796561727320746f20636f6d652e0d0a0d0a576974682074686f7573616e6473206f6620796f756e672070656f706c6520696e206d6f7265207468616e2031333020636f756e74726965732c2074686520526f6f74732653686f6f747320676c6f62616c206e6574776f726b20636f6e6e6563747320796f757468206f6620616c6c20616765732077686f20736861726520612064657369726520746f2068656c70206d616b65206f757220776f726c6420612062657474657220706c6163652e204f757220706f77657266756c2c20796f7574682d64726976656e206e6574776f726b206973206120706c61636520776865726520796f75746820616e64206164756c747320636f6d6520746f67657468657220746f20736861726520696465617320616e6420696e737069726174696f6e2c20696d706c656d656e74207375636365737366756c20636f6d6d756e69747920736572766963652070726f6a6563747320616e6420706172746963697061746520696e207370656369616c206576656e747320616e6420676c6f62616c2063616d706169676e732e, 0x486f6d65, '', 'inherit', 'closed', 'closed', '', '99-revision-v1', '', '', 0x323031372d30322d32302032333a30343a3036, 0x323031372d30322d32302032313a30343a3036, '', 99, 'http://localhost:8080/rootsandshootseurope/99-revision-v1/', 0, 'revision', '', 0),
(186, 2, 0x323031362d31302d31392032303a34353a3430, 0x323031362d31302d31392031383a34353a3430, 0x4765726d616e2070616765, 0x5a75204861757365, '', 'inherit', 'closed', 'closed', '', '176-revision-v1', '', '', 0x323031362d31302d31392032303a34353a3430, 0x323031362d31302d31392031383a34353a3430, '', 176, 'http://localhost:8080/rootsandshootseurope/176-revision-v1/', 0, 'revision', '', 0),
(188, 2, 0x323031362d31302d31392032303a34383a3139, 0x323031362d31302d31392031383a34383a3139, 0x54616e696120506572657a20657374206c6520636f6f7264696e617465757220526f6f74732653686f6f7473206175204a616e6520476f6f64616c6c20496e7374697475746520656e2042656c67697175652e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a3c703e54656c656368617267657a206c657320666c7965727320526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f7370656374757320616e676c6169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f73706563747573206ec3a965726c616e646169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f73706563747573206672616ec3a76169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b, 0x436f6e74616374204652, '', 'publish', 'closed', 'closed', '', 'contact-fr', '', '', 0x323031362d31312d31332030333a31353a3436, 0x323031362d31312d31332030313a31353a3436, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=188', 0, 'page', '', 0),
(323, 2, 0x323031362d31312d31332030333a31343a3135, 0x323031362d31312d31332030313a31343a3135, 0x54616e696120506572657a20697320646520526f6f74732653686f6f747320636f6f7264696e61746f7220766f6f7220686574204a616e6520476f6f64616c6c20496e7374697469746520696e2042656c6769c3ab2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a0d0a3c7020636c6173733d226a757374696679223e446f776e6c6f616420646520666c79657273206f76657220526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e456e67656c736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4e656465726c616e64736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652e62652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4672616e736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652e62652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b0d0a0d0a, 0x436f6e74616374204e4c, '', 'inherit', 'closed', 'closed', '', '196-revision-v1', '', '', 0x323031362d31312d31332030333a31343a3135, 0x323031362d31312d31332030313a31343a3135, '', 196, 'http://localhost:8080/rootsandshootseurope/196-revision-v1/', 0, 'revision', '', 0),
(190, 2, 0x323031362d31302d31392032303a34393a3036, 0x323031362d31302d31392031383a34393a3036, 0x54616e696120506572657a2069732074686520526f6f74732653686f6f747320636f6f7264696e61746f7220666f7220746865204a616e6520476f6f64616c6c20496e7374697475746520696e2042656c6769756d2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e, 0x4b6f6e74616b74, '', 'publish', 'closed', 'closed', '', 'kontakt', '', '', 0x323031362d31312d31332030333a31343a3430, 0x323031362d31312d31332030313a31343a3430, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=190', 0, 'page', '', 0),
(191, 2, 0x323031362d31302d31392032303a34393a3036, 0x323031362d31302d31392031383a34393a3036, 0x446575747363686572204b6f6e7461637420536569746520696d20417566626175, 0x4b6f6e74616374, '', 'inherit', 'closed', 'closed', '', '190-revision-v1', '', '', 0x323031362d31302d31392032303a34393a3036, 0x323031362d31302d31392031383a34393a3036, '', 190, 'http://localhost:8080/rootsandshootseurope/190-revision-v1/', 0, 'revision', '', 0),
(192, 2, 0x323031362d31302d31392032303a34393a3331, 0x323031362d31302d31392031383a34393a3331, 0x54616e696120506572657a2069732074686520526f6f74732653686f6f747320636f6f7264696e61746f7220666f7220746865204a616e6520476f6f64616c6c20496e7374697475746520696e2042656c6769756d2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e, 0x436f6e746163746f73, '', 'publish', 'closed', 'closed', '', 'contactos', '', '', 0x323031362d31312d31332030333a31353a3133, 0x323031362d31312d31332030313a31353a3133, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=192', 0, 'page', '', 0),
(193, 2, 0x323031362d31302d31392032303a34393a3331, 0x323031362d31302d31392031383a34393a3331, 0x5370616e69736820636f6e746163742070616765, 0x436f6e746163746f73, '', 'inherit', 'closed', 'closed', '', '192-revision-v1', '', '', 0x323031362d31302d31392032303a34393a3331, 0x323031362d31302d31392031383a34393a3331, '', 192, 'http://localhost:8080/rootsandshootseurope/192-revision-v1/', 0, 'revision', '', 0),
(194, 2, 0x323031362d31302d31392032303a34393a3532, 0x323031362d31302d31392031383a34393a3532, 0x54616e696120506572657a2069732074686520526f6f74732653686f6f747320636f6f7264696e61746f7220666f7220746865204a616e6520476f6f64616c6c20496e7374697475746520696e2042656c6769756d2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e, 0x436f6e746163746f, '', 'publish', 'closed', 'closed', '', 'contacto', '', '', 0x323031362d31312d31332030333a31343a3536, 0x323031362d31312d31332030313a31343a3536, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=194', 0, 'page', '', 0),
(195, 2, 0x323031362d31302d31392032303a34393a3532, 0x323031362d31302d31392031383a34393a3532, 0x4974616c69616e20636f6e746163742070616765, 0x436f6e746163746f, '', 'inherit', 'closed', 'closed', '', '194-revision-v1', '', '', 0x323031362d31302d31392032303a34393a3532, 0x323031362d31302d31392031383a34393a3532, '', 194, 'http://localhost:8080/rootsandshootseurope/194-revision-v1/', 0, 'revision', '', 0),
(196, 2, 0x323031362d31302d31392032303a35303a3237, 0x323031362d31302d31392031383a35303a3237, 0x54616e696120506572657a20697320646520526f6f74732653686f6f747320636f6f7264696e61746f7220766f6f7220686574204a616e6520476f6f64616c6c20496e7374697475746520696e2042656c6769c3ab2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a0d0a3c7020636c6173733d226a757374696679223e446f776e6c6f616420646520666c79657273206f76657220526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e456e67656c736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4e656465726c616e64736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652e62652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4672616e736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652e62652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b0d0a0d0a, 0x436f6e74616374204e4c, '', 'publish', 'closed', 'closed', '', 'contact-nl', '', '', 0x323031362d31312d31332030333a31343a3232, 0x323031362d31312d31332030313a31343a3232, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=196', 0, 'page', '', 0),
(276, 2, 0x323031362d31312d30342031353a35313a3037, 0x323031362d31312d30342031333a35313a3037, 0x3c6c6162656c3e20596f7572204e616d6520287265717569726564290a202020205b746578742a20796f75722d6e616d655d203c2f6c6162656c3e0a0a3c6c6162656c3e20596f757220456d61696c20287265717569726564290a202020205b656d61696c2a20796f75722d656d61696c5d203c2f6c6162656c3e0a0a3c6c6162656c3e205375626a6563740a202020205b7465787420796f75722d7375626a6563745d203c2f6c6162656c3e0a0a3c6c6162656c3e20596f7572204d6573736167650a202020205b746578746172656120796f75722d6d6573736167655d203c2f6c6162656c3e0a0a5b7375626d6974202253656e64225d0a4a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f706520225b796f75722d7375626a6563745d220a5b796f75722d6e616d655d203c776f72647072657373406c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70653e0a46726f6d3a205b796f75722d6e616d655d203c5b796f75722d656d61696c5d3e0a5375626a6563743a205b796f75722d7375626a6563745d0a0a4d65737361676520426f64793a0a5b796f75722d6d6573736167655d0a0a2d2d0a5468697320652d6d61696c207761732073656e742066726f6d206120636f6e7461637420666f726d206f6e204a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f70652028687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f7065290a696374406a616e65676f6f64616c6c2e62650a5265706c792d546f3a205b796f75722d656d61696c5d0a0a300a300a0a4a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f706520225b796f75722d7375626a6563745d220a4a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f7065203c776f72647072657373406c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70653e0a4d65737361676520426f64793a0a5b796f75722d6d6573736167655d0a0a2d2d0a5468697320652d6d61696c207761732073656e742066726f6d206120636f6e7461637420666f726d206f6e204a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f70652028687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f7065290a5b796f75722d656d61696c5d0a5265706c792d546f3a20696374406a616e65676f6f64616c6c2e62650a0a300a300a5468616e6b20796f7520666f7220796f7572206d6573736167652e20497420686173206265656e2073656e742e0a54686572652077617320616e206572726f7220747279696e6720746f2073656e6420796f7572206d6573736167652e20506c656173652074727920616761696e206c617465722e0a4f6e65206f72206d6f7265206669656c6473206861766520616e206572726f722e20506c6561736520636865636b20616e642074727920616761696e2e0a54686572652077617320616e206572726f7220747279696e6720746f2073656e6420796f7572206d6573736167652e20506c656173652074727920616761696e206c617465722e0a596f75206d7573742061636365707420746865207465726d7320616e6420636f6e646974696f6e73206265666f72652073656e64696e6720796f7572206d6573736167652e0a546865206669656c642069732072657175697265642e0a546865206669656c6420697320746f6f206c6f6e672e0a546865206669656c6420697320746f6f2073686f72742e, 0x436f6e7461637420666f726d2031, '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', 0x323031362d31312d30342031353a35313a3037, 0x323031362d31312d30342031333a35313a3037, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=wpcf7_contact_form&p=276', 0, 'wpcf7_contact_form', '', 0),
(198, 2, 0x323031362d31302d31392032303a35323a3030, 0x323031362d31302d31392031383a35323a3030, 0x4e656465726c616e64736520686f6d6520706167696e61, 0x5468756973, '', 'inherit', 'closed', 'closed', '', '183-revision-v1', '', '', 0x323031362d31302d31392032303a35323a3030, 0x323031362d31302d31392031383a35323a3030, '', 183, 'http://localhost:8080/rootsandshootseurope/183-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wor1677_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES 
(199, 2, 0x323031362d31302d31392032303a35323a3137, 0x323031362d31302d31392031383a35323a3137, 0x5370616e69736820686f6d652070616765, 0x43617361, '', 'inherit', 'closed', 'closed', '', '179-revision-v1', '', '', 0x323031362d31302d31392032303a35323a3137, 0x323031362d31302d31392031383a35323a3137, '', 179, 'http://localhost:8080/rootsandshootseurope/179-revision-v1/', 0, 'revision', '', 0),
(200, 2, 0x323031362d31302d31392032303a35323a3433, 0x323031362d31302d31392031383a35323a3433, 0x4672656e63682070616765206163637565696c, 0x4163637565696c, '', 'inherit', 'closed', 'closed', '', '174-revision-v1', '', '', 0x323031362d31302d31392032303a35323a3433, 0x323031362d31302d31392031383a35323a3433, '', 174, 'http://localhost:8080/rootsandshootseurope/174-revision-v1/', 0, 'revision', '', 0),
(201, 2, 0x323031362d31302d31392032313a32303a3132, 0x323031362d31302d31392031393a32303a3132, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a657473, '', 'publish', 'closed', 'closed', '', 'projets', '', '', 0x323031362d31302d31392032313a32373a3531, 0x323031362d31302d31392031393a32373a3531, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=201', 0, 'page', '', 0),
(202, 2, 0x323031362d31302d31392032313a32303a3132, 0x323031362d31302d31392031393a32303a3132, '', 0x50726f6a657473, '', 'inherit', 'closed', 'closed', '', '201-revision-v1', '', '', 0x323031362d31302d31392032313a32303a3132, 0x323031362d31302d31392031393a32303a3132, '', 201, 'http://localhost:8080/rootsandshootseurope/201-revision-v1/', 0, 'revision', '', 0),
(203, 2, 0x323031362d31302d31392032313a32303a3339, 0x323031362d31302d31392031393a32303a3339, 0x3c68323e50726f6a656374732066726f6d2061726f756e642074686520776f726c643c2f68323e0d0a3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a657473, '', 'inherit', 'closed', 'closed', '', '201-revision-v1', '', '', 0x323031362d31302d31392032313a32303a3339, 0x323031362d31302d31392031393a32303a3339, '', 201, 'http://localhost:8080/rootsandshootseurope/201-revision-v1/', 0, 'revision', '', 0),
(204, 2, 0x323031362d31302d31392032313a32303a3535, 0x323031362d31302d31392031393a32303a3535, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a656b74656e, '', 'publish', 'closed', 'closed', '', 'projekten', '', '', 0x323031362d31302d31392032313a32383a3030, 0x323031362d31302d31392031393a32383a3030, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=204', 0, 'page', '', 0),
(205, 2, 0x323031362d31302d31392032313a32303a3535, 0x323031362d31302d31392031393a32303a3535, 0x3c68323e50726f6a656374732066726f6d2061726f756e642074686520776f726c643c2f68323e0d0a3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a656b74656e, '', 'inherit', 'closed', 'closed', '', '204-revision-v1', '', '', 0x323031362d31302d31392032313a32303a3535, 0x323031362d31302d31392031393a32303a3535, '', 204, 'http://localhost:8080/rootsandshootseurope/204-revision-v1/', 0, 'revision', '', 0),
(206, 2, 0x323031362d31302d31392032313a32313a3134, 0x323031362d31302d31392031393a32313a3134, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a6563746f73, '', 'publish', 'closed', 'closed', '', 'projectos', '', '', 0x323031362d31302d31392032313a32383a3130, 0x323031362d31302d31392031393a32383a3130, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=206', 0, 'page', '', 0),
(207, 2, 0x323031362d31302d31392032313a32313a3134, 0x323031362d31302d31392031393a32313a3134, 0x3c68323e50726f6a656374732066726f6d2061726f756e642074686520776f726c643c2f68323e0d0a3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a6563746f73, '', 'inherit', 'closed', 'closed', '', '206-revision-v1', '', '', 0x323031362d31302d31392032313a32313a3134, 0x323031362d31302d31392031393a32313a3134, '', 206, 'http://localhost:8080/rootsandshootseurope/206-revision-v1/', 0, 'revision', '', 0),
(208, 2, 0x323031362d31302d31392032313a32313a3330, 0x323031362d31302d31392031393a32313a3330, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a65747469, '', 'publish', 'closed', 'closed', '', 'projetti', '', '', 0x323031362d31302d31392032313a32383a3437, 0x323031362d31302d31392031393a32383a3437, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=208', 0, 'page', '', 0),
(209, 2, 0x323031362d31302d31392032313a32313a3330, 0x323031362d31302d31392031393a32313a3330, 0x3c68323e50726f6a656374732066726f6d2061726f756e642074686520776f726c643c2f68323e0d0a3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a65747469, '', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', 0x323031362d31302d31392032313a32313a3330, 0x323031362d31302d31392031393a32313a3330, '', 208, 'http://localhost:8080/rootsandshootseurope/208-revision-v1/', 0, 'revision', '', 0),
(210, 2, 0x323031362d31302d31392032313a32323a3032, 0x323031362d31302d31392031393a32323a3032, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a656374656e, '', 'publish', 'closed', 'closed', '', 'projecten', '', '', 0x323031362d31302d31392032313a32383a3537, 0x323031362d31302d31392031393a32383a3537, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=210', 0, 'page', '', 0),
(211, 2, 0x323031362d31302d31392032313a32323a3032, 0x323031362d31302d31392031393a32323a3032, 0x3c68323e50726f6a656374656e2076616e756974206865656c20646520776572656c643c2f68323e0d0a3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a656374656e, '', 'inherit', 'closed', 'closed', '', '210-revision-v1', '', '', 0x323031362d31302d31392032313a32323a3032, 0x323031362d31302d31392031393a32323a3032, '', 210, 'http://localhost:8080/rootsandshootseurope/210-revision-v1/', 0, 'revision', '', 0),
(214, 2, 0x323031362d31302d31392032313a32383a3030, 0x323031362d31302d31392031393a32383a3030, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a656b74656e, '', 'inherit', 'closed', 'closed', '', '204-revision-v1', '', '', 0x323031362d31302d31392032313a32383a3030, 0x323031362d31302d31392031393a32383a3030, '', 204, 'http://localhost:8080/rootsandshootseurope/204-revision-v1/', 0, 'revision', '', 0),
(215, 2, 0x323031362d31302d31392032313a32383a3130, 0x323031362d31302d31392031393a32383a3130, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a6563746f73, '', 'inherit', 'closed', 'closed', '', '206-revision-v1', '', '', 0x323031362d31302d31392032313a32383a3130, 0x323031362d31302d31392031393a32383a3130, '', 206, 'http://localhost:8080/rootsandshootseurope/206-revision-v1/', 0, 'revision', '', 0),
(216, 2, 0x323031362d31302d31392032313a32383a3437, 0x323031362d31302d31392031393a32383a3437, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a65747469, '', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', 0x323031362d31302d31392032313a32383a3437, 0x323031362d31302d31392031393a32383a3437, '', 208, 'http://localhost:8080/rootsandshootseurope/208-revision-v1/', 0, 'revision', '', 0),
(217, 2, 0x323031362d31302d31392032313a32383a3537, 0x323031362d31302d31392031393a32383a3537, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a656374656e, '', 'inherit', 'closed', 'closed', '', '210-revision-v1', '', '', 0x323031362d31302d31392032313a32383a3537, 0x323031362d31302d31392031393a32383a3537, '', 210, 'http://localhost:8080/rootsandshootseurope/210-revision-v1/', 0, 'revision', '', 0),
(222, 2, 0x323031362d31302d31392032323a33383a3435, 0x323031362d31302d31392032303a33383a3435, '', 0x4d6174c3a97269656c2070c3a96461676f6769717565, '', 'publish', 'closed', 'closed', '', 'materiel-pedagogique', '', '', 0x323031362d31302d31392032323a33383a3435, 0x323031362d31302d31392032303a33383a3435, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=222', 0, 'page', '', 0),
(223, 2, 0x323031362d31302d31392032323a33383a3435, 0x323031362d31302d31392032303a33383a3435, '', 0x4d6174c3a97269656c2070c3a96461676f6769717565, '', 'inherit', 'closed', 'closed', '', '222-revision-v1', '', '', 0x323031362d31302d31392032323a33383a3435, 0x323031362d31302d31392032303a33383a3435, '', 222, 'http://localhost:8080/rootsandshootseurope/222-revision-v1/', 0, 'revision', '', 0),
(224, 2, 0x323031362d31302d31392032323a33393a3131, 0x323031362d31302d31392032303a33393a3131, '', 0x50656461676f6769736368206d617465726961616c, '', 'publish', 'closed', 'closed', '', 'pedagogisch-materiaal', '', '', 0x323031362d31302d31392032323a33393a3131, 0x323031362d31302d31392032303a33393a3131, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=224', 0, 'page', '', 0),
(225, 2, 0x323031362d31302d31392032323a33393a3131, 0x323031362d31302d31392032303a33393a3131, '', 0x50656461676f6769736368206d617465726961616c, '', 'inherit', 'closed', 'closed', '', '224-revision-v1', '', '', 0x323031362d31302d31392032323a33393a3131, 0x323031362d31302d31392032303a33393a3131, '', 224, 'http://localhost:8080/rootsandshootseurope/224-revision-v1/', 0, 'revision', '', 0),
(226, 2, 0x323031362d31302d32312030303a34343a3031, 0x323031362d31302d32302032323a34343a3031, 0x20, '', '', 'publish', 'closed', 'closed', '', '226', '', '', 0x323031362d31312d31332030323a35343a3031, 0x323031362d31312d31332030303a35343a3031, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=226', 2, 'nav_menu_item', '', 0),
(227, 2, 0x323031362d31302d32312030303a34343a3031, 0x323031362d31302d32302032323a34343a3031, 0x20, '', '', 'publish', 'closed', 'closed', '', '227', '', '', 0x323031362d31312d31332030323a35343a3031, 0x323031362d31312d31332030303a35343a3031, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=227', 3, 'nav_menu_item', '', 0),
(228, 2, 0x323031362d31302d32312030303a34343a3031, 0x323031362d31302d32302032323a34343a3031, 0x20, '', '', 'publish', 'closed', 'closed', '', '228', '', '', 0x323031362d31312d31332030323a35343a3031, 0x323031362d31312d31332030303a35343a3031, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=228', 5, 'nav_menu_item', '', 0),
(229, 2, 0x323031362d31302d32312030303a34343a3031, 0x323031362d31302d32302032323a34343a3031, 0x20, '', '', 'publish', 'closed', 'closed', '', '229', '', '', 0x323031362d31312d31332030323a35343a3031, 0x323031362d31312d31332030303a35343a3031, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=229', 1, 'nav_menu_item', '', 0),
(230, 2, 0x323031362d31302d32312030303a34363a3239, 0x323031362d31302d32302032323a34363a3239, 0x20, '', '', 'publish', 'closed', 'closed', '', '230', '', '', 0x323031362d31312d31332030323a35323a3332, 0x323031362d31312d31332030303a35323a3332, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=230', 3, 'nav_menu_item', '', 0),
(231, 2, 0x323031362d31302d32312030303a34363a3330, 0x323031362d31302d32302032323a34363a3330, 0x20, '', '', 'publish', 'closed', 'closed', '', '231', '', '', 0x323031362d31312d31332030323a35323a3332, 0x323031362d31312d31332030303a35323a3332, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=231', 2, 'nav_menu_item', '', 0),
(232, 2, 0x323031362d31302d32312030303a34363a3330, 0x323031362d31302d32302032323a34363a3330, 0x20, '', '', 'publish', 'closed', 'closed', '', '232', '', '', 0x323031362d31312d31332030323a35323a3332, 0x323031362d31312d31332030303a35323a3332, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=232', 5, 'nav_menu_item', '', 0),
(233, 2, 0x323031362d31302d32312030303a34363a3239, 0x323031362d31302d32302032323a34363a3239, 0x20, '', '', 'publish', 'closed', 'closed', '', '233', '', '', 0x323031362d31312d31332030323a35323a3332, 0x323031362d31312d31332030303a35323a3332, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=233', 1, 'nav_menu_item', '', 0),
(234, 2, 0x323031362d31302d32312030303a34373a3433, 0x323031362d31302d32302032323a34373a3433, 0x70656461676f67697363686573206d6174657269616c, 0x50656461676f67697363686573204d6174657269616c, '', 'publish', 'closed', 'closed', '', 'pedagogisches-material', '', '', 0x323031362d31302d32312030303a34373a3433, 0x323031362d31302d32302032323a34373a3433, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=234', 0, 'page', '', 0),
(235, 2, 0x323031362d31302d32312030303a34373a3433, 0x323031362d31302d32302032323a34373a3433, 0x70656461676f67697363686573206d6174657269616c, 0x50656461676f67697363686573204d6174657269616c, '', 'inherit', 'closed', 'closed', '', '234-revision-v1', '', '', 0x323031362d31302d32312030303a34373a3433, 0x323031362d31302d32302032323a34373a3433, '', 234, 'http://localhost:8080/rootsandshootseurope/234-revision-v1/', 0, 'revision', '', 0),
(236, 2, 0x323031362d31302d32312030303a34383a3534, 0x323031362d31302d32302032323a34383a3534, 0x20, '', '', 'publish', 'closed', 'closed', '', '236', '', '', 0x323031362d31312d31332030323a35323a3532, 0x323031362d31312d31332030303a35323a3532, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=236', 3, 'nav_menu_item', '', 0),
(237, 2, 0x323031362d31302d32312030303a34383a3534, 0x323031362d31302d32302032323a34383a3534, 0x20, '', '', 'publish', 'closed', 'closed', '', '237', '', '', 0x323031362d31312d31332030323a35323a3532, 0x323031362d31312d31332030303a35323a3532, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=237', 2, 'nav_menu_item', '', 0),
(238, 2, 0x323031362d31302d32312030303a34383a3534, 0x323031362d31302d32302032323a34383a3534, 0x20, '', '', 'publish', 'closed', 'closed', '', '238', '', '', 0x323031362d31312d31332030323a35323a3532, 0x323031362d31312d31332030303a35323a3532, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=238', 5, 'nav_menu_item', '', 0),
(239, 2, 0x323031362d31302d32312030303a34383a3534, 0x323031362d31302d32302032323a34383a3534, 0x20, '', '', 'publish', 'closed', 'closed', '', '239', '', '', 0x323031362d31312d31332030323a35323a3532, 0x323031362d31312d31332030303a35323a3532, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=239', 1, 'nav_menu_item', '', 0),
(240, 2, 0x323031362d31302d32312030303a35313a3136, 0x323031362d31302d32302032323a35313a3136, '', 0x4d6174657269616c6f732070656461676f6769636f73, '', 'publish', 'closed', 'closed', '', 'materialos-pedagogicos', '', '', 0x323031362d31302d32312030303a35313a3136, 0x323031362d31302d32302032323a35313a3136, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=240', 0, 'page', '', 0),
(241, 2, 0x323031362d31302d32312030303a35313a3136, 0x323031362d31302d32302032323a35313a3136, '', 0x4d6174657269616c6f732070656461676f6769636f73, '', 'inherit', 'closed', 'closed', '', '240-revision-v1', '', '', 0x323031362d31302d32312030303a35313a3136, 0x323031362d31302d32302032323a35313a3136, '', 240, 'http://localhost:8080/rootsandshootseurope/240-revision-v1/', 0, 'revision', '', 0),
(242, 2, 0x323031362d31302d32312030303a35313a3337, 0x323031362d31302d32302032323a35313a3337, '', 0x4d6174657269616c612070656461676f67696361, '', 'publish', 'closed', 'closed', '', 'materiala-pedagogica', '', '', 0x323031362d31302d32312030303a35313a3337, 0x323031362d31302d32302032323a35313a3337, '', 0, 'http://localhost:8080/rootsandshootseurope/?page_id=242', 0, 'page', '', 0),
(243, 2, 0x323031362d31302d32312030303a35313a3337, 0x323031362d31302d32302032323a35313a3337, '', 0x4d6174657269616c612070656461676f67696361, '', 'inherit', 'closed', 'closed', '', '242-revision-v1', '', '', 0x323031362d31302d32312030303a35313a3337, 0x323031362d31302d32302032323a35313a3337, '', 242, 'http://localhost:8080/rootsandshootseurope/242-revision-v1/', 0, 'revision', '', 0),
(244, 2, 0x323031362d31302d32312030303a35323a3234, 0x323031362d31302d32302032323a35323a3234, 0x20, '', '', 'publish', 'closed', 'closed', '', '244', '', '', 0x323031362d31312d31332030323a35333a3230, 0x323031362d31312d31332030303a35333a3230, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=244', 3, 'nav_menu_item', '', 0),
(245, 2, 0x323031362d31302d32312030303a35323a3234, 0x323031362d31302d32302032323a35323a3234, 0x20, '', '', 'publish', 'closed', 'closed', '', '245', '', '', 0x323031362d31312d31332030323a35333a3230, 0x323031362d31312d31332030303a35333a3230, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=245', 2, 'nav_menu_item', '', 0),
(246, 2, 0x323031362d31302d32312030303a35323a3234, 0x323031362d31302d32302032323a35323a3234, 0x20, '', '', 'publish', 'closed', 'closed', '', '246', '', '', 0x323031362d31312d31332030323a35333a3230, 0x323031362d31312d31332030303a35333a3230, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=246', 5, 'nav_menu_item', '', 0),
(247, 2, 0x323031362d31302d32312030303a35323a3234, 0x323031362d31302d32302032323a35323a3234, 0x20, '', '', 'publish', 'closed', 'closed', '', '247', '', '', 0x323031362d31312d31332030323a35333a3230, 0x323031362d31312d31332030303a35333a3230, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=247', 1, 'nav_menu_item', '', 0),
(248, 2, 0x323031362d31302d32312030303a35333a3139, 0x323031362d31302d32302032323a35333a3139, 0x20, '', '', 'publish', 'closed', 'closed', '', '248', '', '', 0x323031362d31312d31332030323a35333a3337, 0x323031362d31312d31332030303a35333a3337, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=248', 3, 'nav_menu_item', '', 0),
(249, 2, 0x323031362d31302d32312030303a35333a3139, 0x323031362d31302d32302032323a35333a3139, 0x20, '', '', 'publish', 'closed', 'closed', '', '249', '', '', 0x323031362d31312d31332030323a35333a3337, 0x323031362d31312d31332030303a35333a3337, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=249', 2, 'nav_menu_item', '', 0),
(250, 2, 0x323031362d31302d32312030303a35333a3139, 0x323031362d31302d32302032323a35333a3139, 0x20, '', '', 'publish', 'closed', 'closed', '', '250', '', '', 0x323031362d31312d31332030323a35333a3337, 0x323031362d31312d31332030303a35333a3337, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=250', 5, 'nav_menu_item', '', 0),
(251, 2, 0x323031362d31302d32312030303a35333a3139, 0x323031362d31302d32302032323a35333a3139, 0x20, '', '', 'publish', 'closed', 'closed', '', '251', '', '', 0x323031362d31312d31332030323a35333a3337, 0x323031362d31312d31332030303a35333a3337, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=251', 1, 'nav_menu_item', '', 0),
(252, 2, 0x323031362d31302d32312031353a31373a3235, 0x323031362d31302d32312031333a31373a3235, 0x20506c6561736520766973697420616c736f203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6f7267223e726f6f7473616e6473686f6f74732e6f72673c2f613e2c203c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e66722f223e526f6f74732653686f6f7473204672616e63653c2f613e2c203c6120687265663d2268747470733a2f2f7777772e66616365626f6f6b2e636f6d2f726f6f7473616e6473686f6f74732f223e526f6f74732653686f6f7473206f6e2046616365626f6f6b3c2f613e, 0x4f746865726c696e6b73, '', 'publish', 'closed', 'closed', '', 'otherlinks', '', '', 0x323031362d31302d32312031353a32303a3235, 0x323031362d31302d32312031333a32303a3235, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=infuse_block&#038;p=252', 0, 'infuse_block', '', 0),
(254, 2, 0x323031362d31302d32372031323a35393a3030, 0x323031362d31302d32372031303a35393a3030, 0x3c696672616d65207372633d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e6f72672f6a67692d776964676574222069643d2270726f6a6563747366726f6d776f726c64223e3c2f696672616d653e, 0x50726f6a656374732066726f6d2061726f756e642074686520776f726c64, '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', 0x323031362d31302d32372031323a35393a3030, 0x323031362d31302d32372031303a35393a3030, '', 94, 'http://localhost:8080/rootsandshootseurope/94-revision-v1/', 0, 'revision', '', 0),
(260, 2, 0x323031362d31302d33312032333a35303a3034, 0x323031362d31302d33312032313a35303a3034, '', 0x4d656368656c7365207363686f6f6c, '', 'inherit', 'closed', 'closed', '', '259-revision-v1', '', '', 0x323031362d31302d33312032333a35303a3034, 0x323031362d31302d33312032313a35303a3034, '', 259, 'http://localhost:8080/rootsandshootseurope/259-revision-v1/', 0, 'revision', '', 0),
(270, 2, 0x323031362d31312d30342031353a33383a3530, 0x323031362d31312d30342031333a33383a3530, '', 0x666f6c6465725f7273, '', 'inherit', 'open', 'closed', '', 'folder_rs', '', '', 0x323031362d31312d30342031353a33383a3530, 0x323031362d31312d30342031333a33383a3530, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/Folder_RS.pdf', 0, 'attachment', 'application/pdf', 0),
(265, 2, 0x323031362d31312d30342031323a31343a3131, 0x323031362d31312d30342031303a31343a3131, '', 0x6c6561666c65745f7273, '', 'inherit', 'open', 'closed', '', 'leaflet_rs', '', '', 0x323031362d31312d30342031323a31343a3131, 0x323031362d31312d30342031303a31343a3131, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/Leaflet_RS.pdf', 0, 'attachment', 'application/pdf', 0),
(266, 2, 0x323031362d31312d30342031323a31343a3332, 0x323031362d31312d30342031303a31343a3332, '', 0x70726f737065637475735f7273, '', 'inherit', 'open', 'closed', '', 'prospectus_rs', '', '', 0x323031362d31312d30342031323a31343a3332, 0x323031362d31312d30342031303a31343a3332, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/Prospectus_RS.pdf', 0, 'attachment', 'application/pdf', 0),
(267, 2, 0x323031362d31312d30342031323a31363a3433, 0x323031362d31312d30342031303a31363a3433, '', 0x70646669636f6e, '', 'inherit', 'open', 'closed', '', 'pdficon', '', '', 0x323031362d31312d30342031323a31363a3433, 0x323031362d31312d30342031303a31363a3433, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/pdficon.png', 0, 'attachment', 'image/png', 0),
(279, 2, 0x323031362d31312d30342031353a35393a3534, 0x323031362d31312d30342031333a35393a3534, 0x5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a3c7020636c6173733d226a757374696679223e446f776e6c6f61642074686520666c7965727320526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e456e676c697368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4475746368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4672656e6368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b0d0a, 0x436f6e74616374, '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', 0x323031362d31312d30342031353a35393a3534, 0x323031362d31312d30342031333a35393a3534, '', 90, 'http://localhost:8080/rootsandshootseurope/90-revision-v1/', 0, 'revision', '', 0),
(280, 2, 0x323031362d31312d30342031363a33373a3438, 0x323031362d31312d30342031343a33373a3438, 0x5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a3c703e54656c656368617267657a206c657320666c7965727320526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f7370656374757320616e676c6169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f73706563747573206ec3a965726c616e646169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f73706563747573206672616ec3a76169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b, 0x436f6e74616374204652, '', 'inherit', 'closed', 'closed', '', '188-revision-v1', '', '', 0x323031362d31312d30342031363a33373a3438, 0x323031362d31312d30342031343a33373a3438, '', 188, 'http://localhost:8080/rootsandshootseurope/188-revision-v1/', 0, 'revision', '', 0),
(282, 2, 0x323031362d31312d30342031363a33383a3536, 0x323031362d31312d30342031343a33383a3536, 0x5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e, 0x4b6f6e74616b74, '', 'inherit', 'closed', 'closed', '', '190-revision-v1', '', '', 0x323031362d31312d30342031363a33383a3536, 0x323031362d31312d30342031343a33383a3536, '', 190, 'http://localhost:8080/rootsandshootseurope/190-revision-v1/', 0, 'revision', '', 0),
(283, 2, 0x323031362d31312d30342031363a33393a3237, 0x323031362d31312d30342031343a33393a3237, 0x5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e, 0x436f6e746163746f, '', 'inherit', 'closed', 'closed', '', '194-revision-v1', '', '', 0x323031362d31312d30342031363a33393a3237, 0x323031362d31312d30342031343a33393a3237, '', 194, 'http://localhost:8080/rootsandshootseurope/194-revision-v1/', 0, 'revision', '', 0),
(284, 2, 0x323031362d31312d30342031363a33393a3431, 0x323031362d31312d30342031343a33393a3431, 0x5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e, 0x436f6e746163746f73, '', 'inherit', 'closed', 'closed', '', '192-revision-v1', '', '', 0x323031362d31312d30342031363a33393a3431, 0x323031362d31312d30342031343a33393a3431, '', 192, 'http://localhost:8080/rootsandshootseurope/192-revision-v1/', 0, 'revision', '', 0),
(324, 2, 0x323031362d31312d31332030333a31343a3232, 0x323031362d31312d31332030313a31343a3232, 0x54616e696120506572657a20697320646520526f6f74732653686f6f747320636f6f7264696e61746f7220766f6f7220686574204a616e6520476f6f64616c6c20496e7374697475746520696e2042656c6769c3ab2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a0d0a3c7020636c6173733d226a757374696679223e446f776e6c6f616420646520666c79657273206f76657220526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e456e67656c736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4e656465726c616e64736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652e62652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4672616e736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652e62652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b0d0a0d0a, 0x436f6e74616374204e4c, '', 'inherit', 'closed', 'closed', '', '196-revision-v1', '', '', 0x323031362d31312d31332030333a31343a3232, 0x323031362d31312d31332030313a31343a3232, '', 196, 'http://localhost:8080/rootsandshootseurope/196-revision-v1/', 0, 'revision', '', 0),
(322, 2, 0x323031362d31312d31332030333a31333a3338, 0x323031362d31312d31332030313a31333a3338, 0x54616e696120506572657a20657374206c6520636f6f7264696e617465757220526f6f74732653686f6f747320636f6f7264696e61746f72206175204a616e6520476f6f64616c6c20496e7374697475746520656e2042656c67697175652e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a3c703e54656c656368617267657a206c657320666c7965727320526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f7370656374757320616e676c6169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f73706563747573206ec3a965726c616e646169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f73706563747573206672616ec3a76169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b, 0x436f6e74616374204652, '', 'inherit', 'closed', 'closed', '', '188-revision-v1', '', '', 0x323031362d31312d31332030333a31333a3338, 0x323031362d31312d31332030313a31333a3338, '', 188, 'http://localhost:8080/rootsandshootseurope/188-revision-v1/', 0, 'revision', '', 0),
(329, 2, 0x323031362d31312d31332030333a31383a3230, 0x323031362d31312d31332030313a31383a3230, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2269742d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279, '', 'inherit', 'closed', 'closed', '', '289-revision-v1', '', '', 0x323031362d31312d31332030333a31383a3230, 0x323031362d31312d31332030313a31383a3230, '', 289, 'http://localhost:8080/rootsandshootseurope/289-revision-v1/', 0, 'revision', '', 0),
(325, 2, 0x323031362d31312d31332030333a31343a3430, 0x323031362d31312d31332030313a31343a3430, 0x54616e696120506572657a2069732074686520526f6f74732653686f6f747320636f6f7264696e61746f7220666f7220746865204a616e6520476f6f64616c6c20496e7374697475746520696e2042656c6769756d2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e, 0x4b6f6e74616b74, '', 'inherit', 'closed', 'closed', '', '190-revision-v1', '', '', 0x323031362d31312d31332030333a31343a3430, 0x323031362d31312d31332030313a31343a3430, '', 190, 'http://localhost:8080/rootsandshootseurope/190-revision-v1/', 0, 'revision', '', 0),
(326, 2, 0x323031362d31312d31332030333a31343a3536, 0x323031362d31312d31332030313a31343a3536, 0x54616e696120506572657a2069732074686520526f6f74732653686f6f747320636f6f7264696e61746f7220666f7220746865204a616e6520476f6f64616c6c20496e7374697475746520696e2042656c6769756d2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e, 0x436f6e746163746f, '', 'inherit', 'closed', 'closed', '', '194-revision-v1', '', '', 0x323031362d31312d31332030333a31343a3536, 0x323031362d31312d31332030313a31343a3536, '', 194, 'http://localhost:8080/rootsandshootseurope/194-revision-v1/', 0, 'revision', '', 0),
(327, 2, 0x323031362d31312d31332030333a31353a3133, 0x323031362d31312d31332030313a31353a3133, 0x54616e696120506572657a2069732074686520526f6f74732653686f6f747320636f6f7264696e61746f7220666f7220746865204a616e6520476f6f64616c6c20496e7374697475746520696e2042656c6769756d2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e, 0x436f6e746163746f73, '', 'inherit', 'closed', 'closed', '', '192-revision-v1', '', '', 0x323031362d31312d31332030333a31353a3133, 0x323031362d31312d31332030313a31353a3133, '', 192, 'http://localhost:8080/rootsandshootseurope/192-revision-v1/', 0, 'revision', '', 0),
(277, 2, 0x323031362d31312d30342031353a35353a3434, 0x323031362d31312d30342031333a35353a3434, 0x3c6c6162656c3e20596f7572204e616d6520287265717569726564290d0a202020205b746578742a20796f75722d6e616d655d203c2f6c6162656c3e0d0a0d0a3c6c6162656c3e20596f757220456d61696c20287265717569726564290d0a202020205b656d61696c2a20796f75722d656d61696c5d203c2f6c6162656c3e0d0a0d0a3c6c6162656c3e205375626a6563740d0a202020205b7465787420796f75722d7375626a6563745d203c2f6c6162656c3e0d0a0d0a3c6c6162656c3e20596f7572204d6573736167650d0a202020205b746578746172656120796f75722d6d6573736167655d203c2f6c6162656c3e0d0a0d0a5b7375626d6974202253656e64225d0a225b796f75722d7375626a6563745d220a526f6f74732653686f6f7473204575726f70652077656273697465203c776f72647072657373406c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70653e0a5b796f75722d6d6573736167655d0d0a0d0a5b796f75722d6e616d655d0a726f6f7473616e6473686f6f7473406a616e65676f6f64616c6c2e62650a5265706c792d546f3a205b796f75722d656d61696c5d0a0a0a0a0a4a616e6520476f6f64616c6c277320526f6f74732653686f6f7473204575726f706520225b796f75722d7375626a6563745d220a4a616e6520476f6f64616c6c277320526f6f74732653686f6f7473204575726f7065203c776f72647072657373406c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70653e0a4d65737361676520426f64793a0d0a5b796f75722d6d6573736167655d0d0a0d0a2d2d0d0a5468697320652d6d61696c207761732073656e742066726f6d206120636f6e7461637420666f726d206f6e204a616e6520476f6f64616c6c26233033393b7320526f6f747326616d703b53686f6f7473204575726f70652028687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f7065290a5b796f75722d656d61696c5d0a5265706c792d546f3a20696374406a616e65676f6f64616c6c2e62650a0a0a0a5468616e6b20796f7520666f7220796f7572206d6573736167652e20497420686173206265656e2073656e742e0a54686572652077617320616e206572726f7220747279696e6720746f2073656e6420796f7572206d6573736167652e20506c656173652074727920616761696e206c617465722e0a4f6e65206f72206d6f7265206669656c6473206861766520616e206572726f722e20506c6561736520636865636b20616e642074727920616761696e2e0a54686572652077617320616e206572726f7220747279696e6720746f2073656e6420796f7572206d6573736167652e20506c656173652074727920616761696e206c617465722e0a596f75206d7573742061636365707420746865207465726d7320616e6420636f6e646974696f6e73206265666f72652073656e64696e6720796f7572206d6573736167652e0a546865206669656c642069732072657175697265642e0a546865206669656c6420697320746f6f206c6f6e672e0a546865206669656c6420697320746f6f2073686f72742e0a546865206461746520666f726d617420697320696e636f72726563742e0a5468652064617465206973206265666f726520746865206561726c69657374206f6e6520616c6c6f7765642e0a546865206461746520697320616674657220746865206c6174657374206f6e6520616c6c6f7765642e0a54686572652077617320616e20756e6b6e6f776e206572726f722075706c6f6164696e67207468652066696c652e0a596f7520617265206e6f7420616c6c6f77656420746f2075706c6f61642066696c6573206f66207468697320747970652e0a5468652066696c6520697320746f6f206269672e0a54686572652077617320616e206572726f722075706c6f6164696e67207468652066696c652e0a546865206e756d62657220666f726d617420697320696e76616c69642e0a546865206e756d62657220697320736d616c6c6572207468616e20746865206d696e696d756d20616c6c6f7765642e0a546865206e756d626572206973206c6172676572207468616e20746865206d6178696d756d20616c6c6f7765642e0a54686520616e7377657220746f20746865207175697a20697320696e636f72726563742e0a596f757220656e746572656420636f646520697320696e636f72726563742e0a54686520652d6d61696c206164647265737320656e746572656420697320696e76616c69642e0a5468652055524c20697320696e76616c69642e0a5468652074656c6570686f6e65206e756d62657220697320696e76616c69642e, 0x434631, '', 'publish', 'closed', 'closed', '', 'cf1', '', '', 0x323031362d31312d30342031363a31333a3330, 0x323031362d31312d30342031343a31333a3330, '', 0, 'http://localhost:8080/rootsandshootseurope/?post_type=wpcf7_contact_form&#038;p=277', 0, 'wpcf7_contact_form', '', 0),
(278, 2, 0x323031362d31312d30342031353a35393a3136, 0x323031362d31312d30342031333a35393a3136, 0x5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a0d0a3c7020636c6173733d226a757374696679223e446f776e6c6f61642074686520666c7965727320526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e456e676c697368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4475746368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4672656e6368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b0d0a, 0x436f6e74616374, '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', 0x323031362d31312d30342031353a35393a3136, 0x323031362d31312d30342031333a35393a3136, '', 90, 'http://localhost:8080/rootsandshootseurope/90-revision-v1/', 0, 'revision', '', 0),
(281, 2, 0x323031362d31312d30342031363a33383a3039, 0x323031362d31312d30342031343a33383a3039, 0x5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a0d0a3c7020636c6173733d226a757374696679223e446f776e6c6f616420646520666c79657273206f76657220526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e456e67656c736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4e656465726c616e64736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652e62652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4672616e736520666f6c6465723c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652e62652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b0d0a0d0a, 0x436f6e74616374204e4c, '', 'inherit', 'closed', 'closed', '', '196-revision-v1', '', '', 0x323031362d31312d30342031363a33383a3039, 0x323031362d31312d30342031343a33383a3039, '', 196, 'http://localhost:8080/rootsandshootseurope/196-revision-v1/', 0, 'revision', '', 0),
(343, 2, 0x323031362d31312d31332031383a32363a3237, 0x323031362d31312d31332031363a32363a3237, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279202d204553, '', 'inherit', 'closed', 'closed', '', '297-revision-v1', '', '', 0x323031362d31312d31332031383a32363a3237, 0x323031362d31312d31332031363a32363a3237, '', 297, 'http://localhost:8080/rootsandshootseurope/297-revision-v1/', 0, 'revision', '', 0),
(305, 2, 0x323031362d31312d31332030323a34353a3234, 0x323031362d31312d31332030303a34353a3234, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279202d204553, '', 'inherit', 'closed', 'closed', '', '297-revision-v1', '', '', 0x323031362d31312d31332030323a34353a3234, 0x323031362d31312d31332030303a34353a3234, '', 297, 'http://localhost:8080/rootsandshootseurope/297-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wor1677_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES 
(306, 2, 0x323031362d31312d31332030323a34353a3530, 0x323031362d31312d31332030303a34353a3530, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279202d204954, '', 'inherit', 'closed', 'closed', '', '299-revision-v1', '', '', 0x323031362d31312d31332030323a34353a3530, 0x323031362d31312d31332030303a34353a3530, '', 299, 'http://localhost:8080/rootsandshootseurope/299-revision-v1/', 0, 'revision', '', 0),
(307, 2, 0x323031362d31312d31332030323a34383a3031, 0x323031362d31312d31332030303a34383a3031, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2269742d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279, '', 'inherit', 'closed', 'closed', '', '289-revision-v1', '', '', 0x323031362d31312d31332030323a34383a3031, 0x323031362d31312d31332030303a34383a3031, '', 289, 'http://localhost:8080/rootsandshootseurope/289-revision-v1/', 0, 'revision', '', 0),
(308, 2, 0x323031362d31312d31332030323a34393a3137, 0x323031362d31312d31332030303a34393a3137, '', 0x637a, '', 'inherit', 'open', 'closed', '', 'cz', '', '', 0x323031362d31312d31332030323a34393a3137, 0x323031362d31312d31332030303a34393a3137, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/cz.svg', 0, 'attachment', 'image/svg+xml', 0),
(309, 2, 0x323031362d31312d31332030323a34393a3332, 0x323031362d31312d31332030303a34393a3332, '', 0x6672, '', 'inherit', 'open', 'closed', '', 'fr', '', '', 0x323031362d31312d31332030323a34393a3332, 0x323031362d31312d31332030303a34393a3332, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/fr.svg', 0, 'attachment', 'image/svg+xml', 0),
(310, 2, 0x323031362d31312d31332030323a35303a3233, 0x323031362d31312d31332030303a35303a3233, '', 0x6762, '', 'inherit', 'open', 'closed', '', 'gb', '', '', 0x323031362d31312d31332030323a35303a3233, 0x323031362d31312d31332030303a35303a3233, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/gb.svg', 0, 'attachment', 'image/svg+xml', 0),
(311, 2, 0x323031362d31312d31332030323a35303a3438, 0x323031362d31312d31332030303a35303a3438, '', 0x6974, '', 'inherit', 'open', 'closed', '', 'it', '', '', 0x323031362d31312d31332030323a35303a3438, 0x323031362d31312d31332030303a35303a3438, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/it.svg', 0, 'attachment', 'image/svg+xml', 0),
(312, 2, 0x323031362d31312d31332030323a35313a3130, 0x323031362d31312d31332030303a35313a3130, '', 0x7074, '', 'inherit', 'open', 'closed', '', 'pt', '', '', 0x323031362d31312d31332030323a35313a3130, 0x323031362d31312d31332030303a35313a3130, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/pt.svg', 0, 'attachment', 'image/svg+xml', 0),
(313, 2, 0x323031362d31312d31332030323a35313a3238, 0x323031362d31312d31332030303a35313a3238, '', 0x6573, '', 'inherit', 'open', 'closed', '', 'es', '', '', 0x323031362d31312d31332030323a35313a3238, 0x323031362d31312d31332030303a35313a3238, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/es.svg', 0, 'attachment', 'image/svg+xml', 0),
(319, 2, 0x323031362d31312d31332030323a35333a3337, 0x323031362d31312d31332030303a35333a3337, '', 0x496e20796f757220636f756e74727920e28093204954, '', 'publish', 'closed', 'closed', '', 'in-your-country-it', '', '', 0x323031362d31312d31332030323a35333a3337, 0x323031362d31312d31332030303a35333a3337, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=319', 4, 'nav_menu_item', '', 0),
(315, 2, 0x323031362d31312d31332030323a35323a3038, 0x323031362d31312d31332030303a35323a3038, 0x20, '', '', 'publish', 'closed', 'closed', '', '315', '', '', 0x323031362d31312d31332030323a35323a3038, 0x323031362d31312d31332030303a35323a3038, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=315', 4, 'nav_menu_item', '', 0),
(316, 2, 0x323031362d31312d31332030323a35323a3332, 0x323031362d31312d31332030303a35323a3332, 0x20, '', '', 'publish', 'closed', 'closed', '', '316', '', '', 0x323031362d31312d31332030323a35323a3332, 0x323031362d31312d31332030303a35323a3332, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=316', 4, 'nav_menu_item', '', 0),
(317, 2, 0x323031362d31312d31332030323a35323a3532, 0x323031362d31312d31332030303a35323a3532, 0x20, '', '', 'publish', 'closed', 'closed', '', '317', '', '', 0x323031362d31312d31332030323a35323a3532, 0x323031362d31312d31332030303a35323a3532, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=317', 4, 'nav_menu_item', '', 0),
(318, 2, 0x323031362d31312d31332030323a35333a3230, 0x323031362d31312d31332030303a35333a3230, '', 0x496e20796f757220636f756e74727920e28093204553, '', 'publish', 'closed', 'closed', '', 'in-your-country-es', '', '', 0x323031362d31312d31332030323a35333a3230, 0x323031362d31312d31332030303a35333a3230, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=318', 4, 'nav_menu_item', '', 0),
(320, 2, 0x323031362d31312d31332030323a35343a3031, 0x323031362d31312d31332030303a35343a3031, 0x20, '', '', 'publish', 'closed', 'closed', '', '320', '', '', 0x323031362d31312d31332030323a35343a3031, 0x323031362d31312d31332030303a35343a3031, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=320', 4, 'nav_menu_item', '', 0),
(321, 2, 0x323031362d31312d31332030333a31323a3138, 0x323031362d31312d31332030313a31323a3138, 0x54616e696120506572657a2069732074686520526f6f74732653686f6f747320636f6f7264696e61746f7220666f7220746865204a616e6520476f6f64616c6c20496e7374697469746520696e2042656c6769756d2e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a3c7020636c6173733d226a757374696679223e446f776e6c6f61642074686520666c7965727320526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e456e676c697368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4475746368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e4672656e6368206c6561666c65743c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b0d0a, 0x436f6e74616374, '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', 0x323031362d31312d31332030333a31323a3138, 0x323031362d31312d31332030313a31323a3138, '', 90, 'http://localhost:8080/rootsandshootseurope/90-revision-v1/', 0, 'revision', '', 0),
(328, 2, 0x323031362d31312d31332030333a31353a3436, 0x323031362d31312d31332030313a31353a3436, 0x54616e696120506572657a20657374206c6520636f6f7264696e617465757220526f6f74732653686f6f7473206175204a616e6520476f6f64616c6c20496e7374697475746520656e2042656c67697175652e0d0a0d0a5b636f6e746163742d666f726d2d372069643d2232373722207469746c653d22434631225d0d0a3c6872202f3e0d0a3c703e54656c656368617267657a206c657320666c7965727320526f6f74732673686f6f74733a3c2f703e0d0a0d0a3c6469762069643d2272736c6561666c6574732220636c6173733d22726f77223e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f7370656374757320616e676c6169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f4c6561666c65745f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f73706563747573206ec3a965726c616e646169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f466f6c6465725f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c64697620636c6173733d22636f6c756d6e20636f6c33223e70726f73706563747573206672616ec3a76169733c6272202f3e0d0a3c6120687265663d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f50726f737065637475735f52532e7064662220636c6173733d2270646669636f6e223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70646669636f6e2e706e672220616c743d2270646669636f6e22202f3e3c2f613e3c2f6469763e0d0a3c2f6469763e0d0a266e6273703b, 0x436f6e74616374204652, '', 'inherit', 'closed', 'closed', '', '188-revision-v1', '', '', 0x323031362d31312d31332030333a31353a3436, 0x323031362d31312d31332030313a31353a3436, '', 188, 'http://localhost:8080/rootsandshootseurope/188-revision-v1/', 0, 'revision', '', 0),
(331, 2, 0x323031362d31312d31332030333a31393a3333, 0x323031362d31312d31332030313a31393a3333, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d225473636865636869656e22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e6b726569636822202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c69656e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d225370616e69656e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d2247726fc39f62726974616e6e69656e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20696872656d204c616e64, '', 'inherit', 'closed', 'closed', '', '295-revision-v1', '', '', 0x323031362d31312d31332030333a31393a3333, 0x323031362d31312d31332030313a31393a3333, '', 295, 'http://localhost:8080/rootsandshootseurope/295-revision-v1/', 0, 'revision', '', 0),
(332, 2, 0x323031362d31312d31332030333a31393a3538, 0x323031362d31312d31332030313a31393a3538, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279202d204553, '', 'inherit', 'closed', 'closed', '', '297-revision-v1', '', '', 0x323031362d31312d31332030333a31393a3538, 0x323031362d31312d31332030313a31393a3538, '', 297, 'http://localhost:8080/rootsandshootseurope/297-revision-v1/', 0, 'revision', '', 0),
(333, 2, 0x323031362d31312d31332030333a32303a3137, 0x323031362d31312d31332030313a32303a3137, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279202d204954, '', 'inherit', 'closed', 'closed', '', '299-revision-v1', '', '', 0x323031362d31312d31332030333a32303a3137, 0x323031362d31312d31332030313a32303a3137, '', 299, 'http://localhost:8080/rootsandshootseurope/299-revision-v1/', 0, 'revision', '', 0),
(334, 2, 0x323031362d31312d31332030333a32303a3434, 0x323031362d31312d31332030313a32303a3434, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d2254736a65636869c3ab22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e6b72696a6b22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c69c3ab22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d225370616e6a6522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d2247726f6f742d4272697474616e6e69c3ab22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e206a6f7577206c616e64, '', 'inherit', 'closed', 'closed', '', '293-revision-v1', '', '', 0x323031362d31312d31332030333a32303a3434, 0x323031362d31312d31332030313a32303a3434, '', 293, 'http://localhost:8080/rootsandshootseurope/293-revision-v1/', 0, 'revision', '', 0),
(335, 2, 0x323031362d31312d31332030333a32323a3136, 0x323031362d31312d31332030313a32323a3136, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d2254736a65636869c3ab22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e6b72696a6b22202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2267622d666c616722207469746c653d224974616c69c3ab22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d225370616e6a6522202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a373133382f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22566572656e696764204b6f6e696e6b72696a6b22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e206a6f7577206c616e64, '', 'inherit', 'closed', 'closed', '', '293-revision-v1', '', '', 0x323031362d31312d31332030333a32323a3136, 0x323031362d31312d31332030313a32323a3136, '', 293, 'http://localhost:8080/rootsandshootseurope/293-revision-v1/', 0, 'revision', '', 0),
(339, 2, 0x323031362d31312d31332031383a31393a3039, 0x323031362d31312d31332031363a31393a3039, '', 0x637a, '', 'inherit', 'open', 'closed', '', 'cz-2', '', '', 0x323031362d31312d31332031383a31393a3039, 0x323031362d31312d31332031363a31393a3039, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2016/11/cz-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(340, 2, 0x323031362d31312d31332031383a32313a3538, 0x323031362d31312d31332031363a32313a3538, 0x3c7461626c6520636c6173733d22666c6167735461626c65223e0d0a3c74626f64793e0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f7777772e726f6f7473616e6473686f6f74732e637a223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f637a2e7376672220616c743d22637a2d666c616722207469746c653d22437a6563682052657075626c696322202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f74732e6672223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f66722e7376672220616c743d2266722d666c616722207469746c653d224672616e636522202f3e3c2f613e0d0a3c2f74643e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e6a616e65676f6f64616c6c2d6974616c69612e6f72672f68746d6c2f726f6f74735f73686f6f74732e68746d6c223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f69742e7376672220616c743d2269742d666c616722207469746c653d224974616c7922202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d2268747470733a2f2f73706564682e776f726470726573732e636f6d2f70726f6772616d612d726f6f74732d73686f6f7473223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f70742e7376672220616c743d2270742d666c616722207469746c653d22506f72747567616c22202f3e3c2f613e0d0a3c2f74643e0d0a3c2f74723e0d0a0d0a3c74723e0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f7473616e6473686f6f7473737061696e2e626c6f6773706f742e6265223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f65732e7376672220616c743d2265732d666c616722207469746c653d22537061696e22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c74643e0d0a3c6120687265663d22687474703a2f2f7777772e726f6f74736e73686f6f74732e6f72672e756b223e3c696d67207372633d22687474703a2f2f6c6f63616c686f73743a383038302f726f6f7473616e6473686f6f74736575726f70652f77702d636f6e74656e742f75706c6f6164732f323031362f31312f67622e7376672220616c743d2267622d666c616722207469746c653d22556e69746564204b696e67646f6d22202f3e3c2f613e0d0a3c2f74643e0d0a0d0a3c2f74723e0d0a3c2f74626f64793e0d0a3c2f7461626c653e, 0x496e20796f757220636f756e747279, '', 'inherit', 'closed', 'closed', '', '289-revision-v1', '', '', 0x323031362d31312d31332031383a32313a3538, 0x323031362d31312d31332031363a32313a3538, '', 289, 'http://localhost:8080/rootsandshootseurope/289-revision-v1/', 0, 'revision', '', 0),
(1412, 2, 0x323031362d31322d30352032333a35393a3132, 0x323031362d31322d30352032323a35393a3132, '', 0x526f6f747326616d703b53686f6f7473204652, '', 'publish', 'closed', 'closed', '', 'rootsshoots-fr', '', '', 0x323031362d31322d30352032333a35393a3132, 0x323031362d31322d30352032323a35393a3132, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=1412', 0, 'accordions', '', 0),
(1413, 2, 0x323031362d31322d30362030303a30323a3435, 0x323031362d31322d30352032333a30323a3435, '', 0x46415120466f7265737420696e206f6e6520646179, '', 'publish', 'closed', 'closed', '', 'faq-forest-in-one-day', '', '', 0x323031362d31322d30362030303a30323a3435, 0x323031362d31322d30352032333a30323a3435, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=1413', 0, 'accordions', '', 0),
(1414, 2, 0x323031362d31322d30362030303a30333a3335, 0x323031362d31322d30352032333a30333a3335, '', 0x46415120466f7265737420696e206f6e6520646179204e4c, '', 'publish', 'closed', 'closed', '', 'faq-forest-in-one-day-nl', '', '', 0x323031362d31322d30362030303a30333a3335, 0x323031362d31322d30352032333a30333a3335, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=1414', 0, 'accordions', '', 0),
(1415, 2, 0x323031362d31322d30362030303a30343a3238, 0x323031362d31322d30352032333a30343a3238, '', 0x46415120466f7265737420696e206f6e6520646179204652, '', 'publish', 'closed', 'closed', '', 'faq-forest-in-one-day-fr', '', '', 0x323031362d31322d30362030303a30343a3238, 0x323031362d31322d30352032333a30343a3238, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=1415', 0, 'accordions', '', 0),
(5463, 2, 0x323031362d31322d31342031383a35363a3331, 0x323031362d31322d31342031373a35363a3331, '', 0x566f6c756e74656572696e67, '', 'publish', 'closed', 'closed', '', 'volunteering', '', '', 0x323031362d31322d31342031383a35363a3331, 0x323031362d31322d31342031373a35363a3331, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5463', 0, 'accordions', '', 0),
(5464, 2, 0x323031362d31322d31342031393a33323a3239, 0x323031362d31322d31342031383a33323a3239, '', 0x566f6c756e74656572696e67204e4c, '', 'publish', 'closed', 'closed', '', 'volunteering-nl', '', '', 0x323031362d31322d31342031393a33323a3239, 0x323031362d31322d31342031383a33323a3239, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5464', 0, 'accordions', '', 0),
(5467, 2, 0x323031362d31322d31342032303a30323a3539, 0x323031362d31322d31342031393a30323a3539, '', 0x566f6c756e74656572696e67204652, '', 'publish', 'closed', 'closed', '', 'volunteering-fr', '', '', 0x323031362d31322d31342032303a30323a3539, 0x323031362d31322d31342031393a30323a3539, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5467', 0, 'accordions', '', 0),
(5506, 2, 0x323031362d31322d31352031313a31313a3531, 0x323031362d31322d31352031303a31313a3531, '', 0x537475647920636f726e6572, '', 'publish', 'closed', 'closed', '', 'study-corner', '', '', 0x323031362d31322d31352031313a31313a3531, 0x323031362d31322d31352031303a31313a3531, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5506', 0, 'accordions', '', 0),
(5508, 2, 0x323031362d31322d31352031313a35303a3134, 0x323031362d31322d31352031303a35303a3134, '', 0x537475646965686f656b, '', 'publish', 'closed', 'closed', '', 'studiehoek', '', '', 0x323031362d31322d31352031313a35303a3134, 0x323031362d31322d31352031303a35303a3134, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5508', 0, 'accordions', '', 0),
(5509, 2, 0x323031362d31322d31352031323a33333a3338, 0x323031362d31322d31352031313a33333a3338, '', 0x436f696e206426233033393bc3a974756465, '', 'publish', 'closed', 'closed', '', 'coin-detude', '', '', 0x323031362d31322d31352031323a33333a3338, 0x323031362d31322d31352031313a33333a3338, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5509', 0, 'accordions', '', 0),
(5921, 2, 0x323031362d31322d31382031383a33343a3432, 0x323031362d31322d31382031373a33343a3432, '', 0x4a4749204f666669636573, '', 'publish', 'closed', 'closed', '', 'jgi-offices', '', '', 0x323031362d31322d31382031383a33343a3432, 0x323031362d31322d31382031373a33343a3432, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5921', 0, 'accordions', '', 0),
(5923, 2, 0x323031362d31322d31382031383a35313a3233, 0x323031362d31322d31382031373a35313a3233, '', 0x4a4749204f666669636573204e4c, '', 'publish', 'closed', 'closed', '', 'jgi-offices-nl', '', '', 0x323031362d31322d31382031383a35313a3233, 0x323031362d31322d31382031373a35313a3233, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5923', 0, 'accordions', '', 0),
(5953, 2, 0x323031362d31322d31382032313a35343a3138, 0x323031362d31322d31382032303a35343a3138, '', 0x4472204a616e6520476f6f64616c6c, '', 'publish', 'closed', 'closed', '', 'dr-jane-goodall', '', '', 0x323031362d31322d31382032313a35343a3138, 0x323031362d31322d31382032303a35343a3138, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=5953', 0, 'accordions', '', 0),
(8115, 2, 0x323031372d30322d32302032333a30303a3033, 0x323031372d30322d32302032313a30303a3033, '', 0x4e61706c65732c20466c6f726964614665622e2032352c2032303036, 0x4e61706c65732c20466c6f726964610a4665622e2032352c2032303036, 'inherit', 'open', 'closed', '', 'naples-floridafeb-25-2006', '', '', 0x323031372d30322d32302032333a30303a3136, 0x323031372d30322d32302032313a30303a3136, '', 0, 'http://localhost:8080/rootsandshootseurope/wp-content/uploads/2017/02/Jane-alone.jpg', 0, 'attachment', 'image/jpeg', 0),
(8110, 2, 0x323031372d30312d31342031343a31343a3336, 0x323031372d30312d31342031333a31343a3336, '', 0x4a4749204f666669636573204652, '', 'publish', 'closed', 'closed', '', 'jgi-offices-fr', '', '', 0x323031372d30312d31342031343a31343a3336, 0x323031372d30312d31342031333a31343a3336, '', 0, 'http://www.janegoodall.be/?post_type=accordions&#038;p=8110', 0, 'accordions', '', 0),
(8124, 2, 0x323031372d30362d30312031313a31313a3233, 0x303030302d30302d30302030303a30303a3030, '', 0x4175746f204472616674, '', 'auto-draft', 'open', 'open', '', '', '', '', 0x323031372d30362d30312031313a31313a3233, 0x303030302d30302d30302030303a30303a3030, '', 0, 'http://localhost:8080/rootsandshootseurope/?p=8124', 0, 'post', '', 0);
/*!40000 ALTER TABLE `wor1677_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_term_relationships`
--

DROP TABLE IF EXISTS `wor1677_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_term_relationships`
--

LOCK TABLES `wor1677_term_relationships` WRITE;
/*!40000 ALTER TABLE `wor1677_term_relationships` DISABLE KEYS */;
INSERT INTO `wor1677_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES 
(1, 5, 0),
(102, 2, 0),
(291, 37, 0),
(94, 4, 0),
(96, 4, 0),
(97, 2, 0),
(101, 2, 0),
(299, 37, 0),
(289, 37, 0),
(53, 4, 0),
(1, 6, 0),
(51, 4, 0),
(49, 4, 0),
(83, 4, 0),
(9, 8, 0),
(64, 4, 0),
(9, 6, 0),
(62, 7, 0),
(67, 4, 0),
(299, 23, 0),
(70, 4, 0),
(72, 4, 0),
(77, 4, 0),
(79, 4, 0),
(81, 4, 0),
(86, 4, 0),
(88, 4, 0),
(90, 4, 0),
(93, 2, 0),
(13, 12, 0),
(291, 11, 0),
(289, 4, 0),
(308, 4, 0),
(309, 4, 0),
(293, 7, 0),
(13, 6, 0),
(293, 37, 0),
(295, 15, 0),
(295, 37, 0),
(297, 19, 0),
(297, 37, 0),
(310, 4, 0),
(47, 4, 0),
(17, 16, 0),
(21, 20, 0),
(17, 6, 0),
(25, 24, 0),
(21, 6, 0),
(99, 4, 0),
(25, 6, 0),
(176, 15, 0),
(174, 11, 0),
(176, 27, 0),
(174, 27, 0),
(255, 36, 0),
(99, 27, 0),
(179, 19, 0),
(179, 27, 0),
(181, 23, 0),
(181, 27, 0),
(183, 7, 0),
(183, 27, 0),
(188, 11, 0),
(188, 28, 0),
(90, 28, 0),
(190, 15, 0),
(190, 28, 0),
(192, 19, 0),
(192, 28, 0),
(194, 23, 0),
(194, 28, 0),
(196, 7, 0),
(196, 28, 0),
(201, 11, 0),
(201, 29, 0),
(94, 29, 0),
(204, 15, 0),
(204, 29, 0),
(206, 19, 0),
(206, 29, 0),
(208, 23, 0),
(208, 29, 0),
(210, 7, 0),
(210, 29, 0),
(224, 7, 0),
(86, 32, 0),
(222, 32, 0),
(222, 11, 0),
(224, 32, 0),
(229, 30, 0),
(226, 30, 0),
(227, 30, 0),
(228, 30, 0),
(233, 31, 0),
(230, 31, 0),
(231, 31, 0),
(232, 31, 0),
(234, 15, 0),
(234, 32, 0),
(239, 33, 0),
(237, 33, 0),
(236, 33, 0),
(238, 33, 0),
(240, 19, 0),
(240, 32, 0),
(242, 23, 0),
(242, 32, 0),
(247, 34, 0),
(245, 34, 0),
(244, 34, 0),
(246, 34, 0),
(251, 35, 0),
(249, 35, 0),
(248, 35, 0),
(250, 35, 0),
(258, 4, 0),
(259, 4, 0),
(270, 4, 0),
(265, 4, 0),
(266, 4, 0),
(267, 4, 0),
(311, 4, 0),
(312, 4, 0),
(313, 4, 0),
(319, 35, 0),
(315, 2, 0),
(316, 31, 0),
(317, 33, 0),
(318, 34, 0),
(320, 30, 0),
(339, 7, 0),
(8115, 4, 0),
(8124, 4, 0);
/*!40000 ALTER TABLE `wor1677_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_term_taxonomy`
--

DROP TABLE IF EXISTS `wor1677_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_term_taxonomy`
--

LOCK TABLES `wor1677_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wor1677_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wor1677_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES 
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 5),
(4, 4, 'language', 0x613a333a7b733a363a226c6f63616c65223b733a353a22656e5f4742223b733a333a2272746c223b693a303b733a393a22666c61675f636f6465223b733a323a226762223b7d, 0, 8),
(5, 5, 'term_language', '', 0, 1),
(6, 6, 'term_translations', 0x613a363a7b733a323a22656e223b693a313b733a323a226e6c223b693a393b733a323a226672223b693a31333b733a323a226465223b693a31373b733a323a226573223b693a32313b733a323a226974223b693a32353b7d, 0, 6),
(7, 7, 'language', 0x613a333a7b733a363a226c6f63616c65223b733a353a226e6c5f4e4c223b733a333a2272746c223b693a303b733a393a22666c61675f636f6465223b733a323a226e6c223b7d, 0, 6),
(8, 8, 'term_language', '', 0, 1),
(9, 9, 'category', '', 0, 0),
(11, 11, 'language', 0x613a333a7b733a363a226c6f63616c65223b733a353a2266725f4652223b733a333a2272746c223b693a303b733a393a22666c61675f636f6465223b733a323a226672223b7d, 0, 5),
(12, 12, 'term_language', '', 0, 1),
(13, 13, 'category', '', 0, 0),
(15, 15, 'language', 0x613a333a7b733a363a226c6f63616c65223b733a353a2264655f4445223b733a333a2272746c223b693a303b733a393a22666c61675f636f6465223b733a323a226465223b7d, 0, 5),
(16, 16, 'term_language', '', 0, 1),
(17, 17, 'category', '', 0, 0),
(19, 19, 'language', 0x613a333a7b733a363a226c6f63616c65223b733a353a2265735f4553223b733a333a2272746c223b693a303b733a393a22666c61675f636f6465223b733a323a226573223b7d, 0, 5),
(20, 20, 'term_language', '', 0, 1),
(21, 21, 'category', '', 0, 0),
(23, 23, 'language', 0x613a333a7b733a363a226c6f63616c65223b733a353a2269745f4954223b733a333a2272746c223b693a303b733a393a22666c61675f636f6465223b733a323a226974223b7d, 0, 5),
(24, 24, 'term_language', '', 0, 1),
(25, 25, 'category', '', 0, 0),
(27, 27, 'post_translations', 0x613a363a7b733a323a22656e223b693a39393b733a323a226672223b693a3137343b733a323a226465223b693a3137363b733a323a226573223b693a3137393b733a323a226974223b693a3138313b733a323a226e6c223b693a3138333b7d, 0, 6),
(28, 28, 'post_translations', 0x613a363a7b733a323a226672223b693a3138383b733a323a22656e223b693a39303b733a323a226465223b693a3139303b733a323a226573223b693a3139323b733a323a226974223b693a3139343b733a323a226e6c223b693a3139363b7d, 0, 6),
(29, 29, 'post_translations', 0x613a363a7b733a323a22656e223b693a39343b733a323a226672223b693a3230313b733a323a226465223b693a3230343b733a323a226573223b693a3230363b733a323a226974223b693a3230383b733a323a226e6c223b693a3231303b7d, 0, 6),
(30, 30, 'nav_menu', '', 0, 5),
(31, 31, 'nav_menu', '', 0, 5),
(32, 32, 'post_translations', 0x613a363a7b733a323a22656e223b693a38363b733a323a226672223b693a3232323b733a323a226465223b693a3233343b733a323a226573223b693a3234303b733a323a226974223b693a3234323b733a323a226e6c223b693a3232343b7d, 0, 6),
(33, 33, 'nav_menu', '', 0, 5),
(34, 34, 'nav_menu', '', 0, 5),
(35, 35, 'nav_menu', '', 0, 5),
(36, 36, 'nav_menu', '', 0, 1),
(37, 37, 'post_translations', 0x613a363a7b733a323a226672223b693a3239313b733a323a22656e223b693a3238393b733a323a226465223b693a3239353b733a323a226573223b693a3239373b733a323a226974223b693a3239393b733a323a226e6c223b693a3239333b7d, 0, 6);
/*!40000 ALTER TABLE `wor1677_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_termmeta`
--

DROP TABLE IF EXISTS `wor1677_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_termmeta`
--

LOCK TABLES `wor1677_termmeta` WRITE;
/*!40000 ALTER TABLE `wor1677_termmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wor1677_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_terms`
--

DROP TABLE IF EXISTS `wor1677_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_terms`
--

LOCK TABLES `wor1677_terms` WRITE;
/*!40000 ALTER TABLE `wor1677_terms` DISABLE KEYS */;
INSERT INTO `wor1677_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES 
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main_menu_english', 'main_menu_english', 0),
(4, 'English', 'en', 0),
(5, 'English', 'pll_en', 0),
(6, 'pll_57bcb6398f2bb', 'pll_57bcb6398f2bb', 0),
(7, 'Nederlands', 'nl', 2),
(8, 'Nederlands', 'pll_nl', 0),
(9, 'Uncategorised', 'uncategorised-nl', 0),
(11, 'Français', 'fr', 0),
(12, 'Français', 'pll_fr', 0),
(13, 'Uncategorised', 'uncategorised-fr', 0),
(15, 'Deutsch', 'de', 0),
(16, 'Deutsch', 'pll_de', 0),
(17, 'Uncategorised', 'uncategorised-de', 0),
(19, 'Español', 'es', 0),
(20, 'Español', 'pll_es', 0),
(21, 'Uncategorised', 'uncategorised-es', 0),
(23, 'Italiano', 'it', 0),
(24, 'Italiano', 'pll_it', 0),
(25, 'Uncategorised', 'uncategorised-it', 0),
(27, 'pll_5807bd89c00fd', 'pll_5807bd89c00fd', 0),
(28, 'pll_5807bff3f1fa3', 'pll_5807bff3f1fa3', 0),
(29, 'pll_5807c76d01202', 'pll_5807c76d01202', 0),
(30, 'Main_menu_Dutch', 'main_menu_dutch', 0),
(31, 'Main_menu_french', 'main_menu_french', 0),
(32, 'pll_5807d9d57b488', 'pll_5807d9d57b488', 0),
(33, 'Main_menu_german', 'main_menu_german', 0),
(34, 'Main_menu_spanish', 'main_menu_spanish', 0),
(35, 'Main_menu_italian', 'main_menu_italian', 0),
(36, 'Top', 'top', 0),
(37, 'pll_5827b6a243845', 'pll_5827b6a243845', 0);
/*!40000 ALTER TABLE `wor1677_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_usermeta`
--

DROP TABLE IF EXISTS `wor1677_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=649 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_usermeta`
--

LOCK TABLES `wor1677_usermeta` WRITE;
/*!40000 ALTER TABLE `wor1677_usermeta` DISABLE KEYS */;
INSERT INTO `wor1677_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES 
(76, 2, 'metaboxhidden_page', 0x613a343a7b693a303b733a31303a22706f7374637573746f6d223b693a313b733a31363a22636f6d6d656e74737461747573646976223b693a323b733a31313a22636f6d6d656e7473646976223b693a333b733a393a22617574686f72646976223b7d),
(75, 2, 'closedpostboxes_page', 0x613a303a7b7d),
(73, 2, 'wor1677_user-settings', 0x656469746f723d68746d6c266c696272617279436f6e74656e743d62726f7773652675706c6f616465723d31),
(74, 2, 'wor1677_user-settings-time', 0x31343738323534333936),
(23, 2, 'nickname', 0x646c616e6f72),
(64, 2, 'metaboxhidden_nav-menus', 0x613a323a7b693a303b733a32313a226164642d706f73742d747970652d6334705f6c6f67223b693a313b733a31323a226164642d706f73745f746167223b7d),
(63, 2, 'managenav-menuscolumnshidden', 0x613a353a7b693a303b733a31313a226c696e6b2d746172676574223b693a313b733a31313a226373732d636c6173736573223b693a323b733a333a2278666e223b693a333b733a31313a226465736372697074696f6e223b693a343b733a31353a227469746c652d617474726962757465223b7d),
(62, 2, 'nav_menu_recently_edited', 0x3336),
(24, 2, 'first_name', ''),
(25, 2, 'last_name', ''),
(26, 2, 'description', ''),
(27, 2, 'rich_editing', 0x74727565),
(28, 2, 'comment_shortcuts', 0x66616c7365),
(29, 2, 'admin_color', 0x6672657368),
(30, 2, 'use_ssl', ''),
(31, 2, 'show_admin_bar_front', 0x74727565),
(32, 2, 'wor1677_capabilities', 0x613a313a7b733a31333a2261646d696e6973747261746f72223b623a313b7d),
(33, 2, 'wor1677_user_level', 0x3130),
(34, 2, 'aiowps_account_status', 0x617070726f766564),
(35, 2, 'aiowps_registrant_ip', 0x38372e36342e3232322e3839),
(36, 2, 'dismissed_wp_pointers', 0x706c6c5f6c6774),
(37, 2, 'default_password_nag', ''),
(54, 2, 'last_login_time', 0x323031372d30362d30312031313a31313a3232),
(55, 2, 'wor1677_dashboard_quick_press_last_post_id', 0x38313234),
(165, 2, 'metaboxhidden_dashboard', 0x613a313a7b693a303b733a32343a226261636b777075705f6265636f6d655f696e707379646572223b7d),
(164, 2, 'closedpostboxes_dashboard', 0x613a303a7b7d),
(163, 2, 'wor1677_backwpup_dinotopt_become_inpsyder', 0x31),
(85, 2, 'pll_filter_content', ''),
(99, 2, 'wor1677_media_library_mode', 0x67726964),
(100, 2, 'wor1677_media_library_mode', 0x6c697374),
(101, 2, 'wpcf7_hide_welcome_panel_on', 0x613a313a7b693a303b733a353a22342e352e31223b7d),
(97, 2, 'manageedit-pagecolumnshidden', 0x613a313a7b693a303b733a383a22636f6d6d656e7473223b7d),
(98, 2, 'edit_page_per_page', 0x3230),
(648, 2, 'session_tokens', 0x613a313a7b733a36343a2234343663613865353632653062626133353265366566313431373238383539643735316433346536366164666331613964623466313238313964663962343634223b613a343a7b733a31303a2265787069726174696f6e223b693a313439363438313038323b733a323a226970223b733a333a223a3a31223b733a323a227561223b733a37333a224d6f7a696c6c612f352e30202857696e646f7773204e542031302e303b20574f5736343b2072763a35332e3029204765636b6f2f32303130303130312046697265666f782f35332e30223b733a353a226c6f67696e223b693a313439363330383238323b7d7d),
(647, 39, 'default_password_nag', 0x31),
(646, 39, 'aiowps_registrant_ip', 0x3231372e3137302e3230312e313036),
(645, 39, 'aiowps_account_status', 0x70656e64696e67),
(644, 39, 'wor1677_user_level', ''),
(643, 39, 'wor1677_capabilities', 0x613a313a7b733a31303a2273756273637269626572223b623a313b7d),
(642, 39, 'locale', ''),
(641, 39, 'show_admin_bar_front', 0x74727565),
(640, 39, 'use_ssl', ''),
(639, 39, 'admin_color', 0x6672657368),
(638, 39, 'comment_shortcuts', 0x66616c7365),
(633, 39, 'nickname', 0x6564756172646f2e7275697a32303037),
(634, 39, 'first_name', ''),
(635, 39, 'last_name', ''),
(636, 39, 'description', ''),
(637, 39, 'rich_editing', 0x74727565);
/*!40000 ALTER TABLE `wor1677_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wor1677_users`
--

DROP TABLE IF EXISTS `wor1677_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wor1677_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wor1677_users`
--

LOCK TABLES `wor1677_users` WRITE;
/*!40000 ALTER TABLE `wor1677_users` DISABLE KEYS */;
INSERT INTO `wor1677_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES 
(2, 'dlanor', '$P$BIffwA6.OLBBvovsL27P9ddqZRuWfL/', 'dlanor', 'ict@janegoodall.be', '', 0x323031362d30352d32352031343a30323a3431, '', 0, 'dlanor'),
(39, 'eduardo.ruiz2007', '$P$BUMB911Y/sJsoZ6Phc3HYJE4sZ1aVR1', 'eduardo-ruiz2007', 'eduardo.ruiz@mpsa.com', '', 0x323031372d30342d31302031353a30393a3530, '1491836990:$P$BnjGsGoptWa7RclWBQlx6s6IoVH3T./', 0, 'eduardo.ruiz2007');
/*!40000 ALTER TABLE `wor1677_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Backup routines for database 'rootsandshoots_europe'
--

--
-- Procedure structure for CountrySelectAll
--

DROP PROCEDURE IF EXISTS `CountrySelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `CountrySelectAll`()
BEGIN
	SELECT * FROM rs_countries  order by country;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for CountrySelectById
--

DROP PROCEDURE IF EXISTS `CountrySelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `CountrySelectById`(
	IN pId INT
)
BEGIN
	SELECT * FROM rs_countries WHERE CountryId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for LanguageSelectAll
--

DROP PROCEDURE IF EXISTS `LanguageSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `LanguageSelectAll`()
BEGIN
	SELECT * FROM rs_languages;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for LanguageSelectById
--

DROP PROCEDURE IF EXISTS `LanguageSelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `LanguageSelectById`(
	IN pId INT
)
BEGIN
	SELECT * FROM rs_languages WHERE LanguageId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for MemberDelete
--

DROP PROCEDURE IF EXISTS `MemberDelete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `MemberDelete`(
	IN pId INT
)
BEGIN
DELETE FROM rs_members WHERE MemberId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for MemberInsert
--

DROP PROCEDURE IF EXISTS `MemberInsert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `MemberInsert`(
	OUT pMemberId INT ,
	IN pUserName VARCHAR (255) CHARACTER SET UTF8 ,
	IN pPassword VARCHAR (255) CHARACTER SET UTF8 ,
	IN pFirstName VARCHAR (255) CHARACTER SET UTF8 ,
	IN pLastName VARCHAR (255) CHARACTER SET UTF8 ,
	IN pBirthDate DATE ,
    IN pEmail VARCHAR (255) CHARACTER SET UTF8 ,
    IN pLanguageId INT ,
    IN pRoleId INT,
    IN pCountryId INT,
	IN pInsertedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	INSERT INTO rs_members
	(
		UserName,
		Password,
		FirstName,
		LastName,
		Email,
        BirthDate,
        LanguageId,
        RoleId,
		CountryId,
        InsertedBy,
        InsertedOn
	)
	VALUES
	(
		pUserName,
		pPassword,
		pFirstName,
		pLastName,
        pEmail,
		pBirthDate,
        pLanguageId,
        pRoleId,
		pCountryId,
		pInsertedBy,
		NOW()
	);
	SELECT LAST_INSERT_ID() INTO pMemberId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for MemberSelectAll
--

DROP PROCEDURE IF EXISTS `MemberSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `MemberSelectAll`(
)
BEGIN
	SELECT * FROM rs_members order by LastName;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for MemberSelectById
--

DROP PROCEDURE IF EXISTS `MemberSelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `MemberSelectById`(
	IN pMemberId INT 
)
BEGIN
	SELECT * FROM rs_members WHERE MemberId = pMemberId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for MemberSelectByUserName
--

DROP PROCEDURE IF EXISTS `MemberSelectByUserName`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `MemberSelectByUserName`(
	IN pUserName VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	SELECT * FROM rs_members WHERE UserName = pUserName;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for MemberUpdate
--

DROP PROCEDURE IF EXISTS `MemberUpdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `MemberUpdate`(
	IN pMemberId INT ,
	IN pUserName VARCHAR (255) CHARACTER SET UTF8 ,
	IN pPassword VARCHAR (255) CHARACTER SET UTF8 ,
	IN pFirstName VARCHAR (255) CHARACTER SET UTF8 ,
	IN pLastName VARCHAR (255) CHARACTER SET UTF8 ,
	IN pBirthDate DATE ,
    IN pEmail VARCHAR (255) CHARACTER SET UTF8 ,
    IN pLanguageId INT ,
    IN pRoleId INT,
	IN pCountryId INT ,
	IN pModifiedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
UPDATE rs_members
SET
	UserName = pUserName,
	Password = pPassword,
	FirstName = pFirstName,
	LastName = pLastName,
	BirthDate = pBirthDate,
    Email = pEmail,
    LanguageId = pLanguageId,
    RoleId = pRoleId,
	CountryId = pCountryId,
	ModifiedBy = pModifiedBy,
	ModifiedOn = NOW()
WHERE MemberId = pMemberId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectDelete
--

DROP PROCEDURE IF EXISTS `ProjectDelete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectDelete`(
	IN pId INT
)
BEGIN
DELETE FROM `rs_projects`
WHERE ProjectId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectFilter1
--

DROP PROCEDURE IF EXISTS `ProjectFilter1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectFilter1`(
   IN pLanguageId INT,
   IN pCountryId INT,
   IN pProjectTypeId INT,
   IN pTitle VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
if ((pLanguageId is NULL) AND (pCountryId is NULL) AND (pProjectTypeId is NULL) AND (pTitle is not NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and ProjectTitle like CONCAT('%', pTitle,'%');

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NULL) AND (pProjectTypeId is NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and LanguageId = pLanguageId;

elseif ((pLanguageId is NULL) AND (pCountryId is NOT NULL) AND (pProjectTypeId is NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and CountryId = pCountryId;

elseif ((pLanguageId is NULL) AND (pCountryId is NULL) AND (pProjectTypeId is NOT NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and rs_projecttypes.ProjectTypeId = pProjectTypeId;

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NULL) AND (pProjectTypeId is NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and LanguageId = pLanguageId and ProjectTitle like CONCAT('%', pTitle,'%');


elseif ((pLanguageId is NULL) AND (pCountryId is NOT NULL) AND (pProjectTypeId is NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and CountryId = pCountryId and ProjectTitle like CONCAT('%', pTitle,'%');


elseif ((pLanguageId is NOT NULL) AND (pCountryId is NOT NULL) AND (pProjectTypeId is NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and CountryId = pCountryId and LanguageId = pLanguageId;


elseif ((pLanguageId is NOT NULL) AND (pCountryId is NULL) AND (pProjectTypeId is NOT NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and rs_projecttypes.ProjectTypeId = pProjectTypeId and LanguageId = pLanguageId;

elseif ((pLanguageId is NULL) AND (pCountryId is NOT NULL) AND (pProjectTypeId is NOT NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and CountryId = pCountryId and rs_projecttypes.ProjectTypeId = pProjectTypeId;

elseif ((pLanguageId is NULL) AND (pCountryId is NULL) AND (pProjectTypeId is NOT NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and rs_projecttypes.ProjectTypeId = pProjectTypeId and ProjectTitle like CONCAT('%', pTitle,'%');

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NOT NULL) AND (pProjectTypeId is NOT NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and LanguageId = pLanguageId and CountryId = pCountryId and rs_projecttypes.ProjectTypeId = pProjectTypeId;

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NOT NULL) AND (pProjectTypeId is NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and LanguageId = pLanguageId and CountryId = pCountryId and ProjectTitle like CONCAT('%', pTitle,'%');

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NULL) AND (pProjectTypeId is NOT NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and LanguageId = pLanguageId and rs_projecttypes.ProjectTypeId = pProjectTypeId and ProjectTitle like CONCAT('%', pTitle,'%');

elseif ((pLanguageId is NULL) AND (pCountryId is NOT NULL) AND (pProjectTypeId is NOT NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and CountryId = pCountryId and rs_projecttypes.ProjectTypeId = pProjectTypeId and ProjectTitle like CONCAT('%', pTitle,'%');

else
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_projecttypes.projecttype as ProjectType FROM rs_projects, rs_projectprojecttypes, rs_projecttypes WHERE 
        rs_projects.projectid = rs_projectprojecttypes.projectid and rs_projecttypes.projecttypeid = rs_projectprojecttypes.projecttypeid and ProjectTitle like CONCAT('%', pTitle,'%') and LanguageId = pLanguageId and CountryId = pCountryId and rs_projecttypes.ProjectTypeId = pProjectTypeId;

end if;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectFilter2
--

DROP PROCEDURE IF EXISTS `ProjectFilter2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectFilter2`(
   IN pLanguageId INT,
   IN pCountryId INT,
   IN pTargetGroupId INT,
   IN pTitle VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
if ((pLanguageId is NULL) AND (pCountryId is NULL) AND (pTargetGroupId is NULL) AND (pTitle is not NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and ProjectTitle like CONCAT('%', pTitle,'%');

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NULL) AND (pTargetGroupId is NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and LanguageId = pLanguageId;

elseif ((pLanguageId is NULL) AND (pCountryId is NOT NULL) AND (pTargetGroupId is NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and CountryId = pCountryId;

elseif ((pLanguageId is NULL) AND (pCountryId is NULL) AND (pTargetGroupId is NOT NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and rs_targetgroups.TargetGroupId = pTargetGroupId;

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NULL) AND (pTargetGroupId is NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and LanguageId = pLanguageId and ProjectTitle like CONCAT('%', pTitle,'%');


elseif ((pLanguageId is NULL) AND (pCountryId is NOT NULL) AND (pTargetGroupId is NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and CountryId = pCountryId and ProjectTitle like CONCAT('%', pTitle,'%');


elseif ((pLanguageId is NOT NULL) AND (pCountryId is NOT NULL) AND (pTargetGroupId is NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and CountryId = pCountryId and LanguageId = pLanguageId;


elseif ((pLanguageId is NOT NULL) AND (pCountryId is NULL) AND (pTargetGroupId is NOT NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and rs_targetgroups.TargetGroupId = pTargetGroupId and LanguageId = pLanguageId;

elseif ((pLanguageId is NULL) AND (pCountryId is NOT NULL) AND (pTargetGroupId is NOT NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and CountryId = pCountryId and rs_targetgroups.TargetGroupId = pTargetGroupId;

elseif ((pLanguageId is NULL) AND (pCountryId is NULL) AND (pTargetGroupId is NOT NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and rs_targetgroups.TargetGroupId = pTargetGroupId and ProjectTitle like CONCAT('%', pTitle,'%');

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NOT NULL) AND (pTargetGroupId is NOT NULL) AND (pTitle is NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and LanguageId = pLanguageId and CountryId = pCountryId and rs_targetgroups.TargetGroupId = pTargetGroupId;

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NOT NULL) AND (pTargetGroupId is NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.targetgroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and LanguageId = pLanguageId and CountryId = pCountryId and ProjectTitle like CONCAT('%', pTitle,'%');

elseif ((pLanguageId is NOT NULL) AND (pCountryId is NULL) AND (pTargetGroupId is NOT NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.TargetGroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and LanguageId = pLanguageId and rs_targetgroups.TargetGroupId = pTargetGroupId and ProjectTitle like CONCAT('%', pTitle,'%');

elseif ((pLanguageId is NULL) AND (pCountryId is NOT NULL) AND (pTargetGroupId is NOT NULL) AND (pTitle is NOT NULL)) then 
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.TargetGroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and CountryId = pCountryId and rs_targetgroups.TargetGroupId = pTargetGroupId and ProjectTitle like CONCAT('%', pTitle,'%');

else
SELECT rs_projects.ProjectId as ProjectId, ProjectTitle, GroupName, PplEstimated, Location, Objective, Means, StartDate, TimeFrameId, LanguageId, CountryId, ProjectStatusId,
        HoursSpent, PplParticipated, PplServed, Report, EndDate, rs_projects.InsertedBy as InsertedBy, rs_projects.InsertedOn as InsertedOn, 
        rs_targetgroups.TargetGroup as TargetGroup FROM rs_projects, rs_projecttargetgroups, rs_targetgroups WHERE 
        rs_projects.projectid = rs_projecttargetgroups.projectid and rs_targetgroups.TargetGroupId = rs_projecttargetgroups.TargetGroupId and ProjectTitle like CONCAT('%', pTitle,'%') and LanguageId = pLanguageId and CountryId = pCountryId and rs_targetgroups.TargetGroupId = pTargetGroupId;

end if;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectInsert
--

DROP PROCEDURE IF EXISTS `ProjectInsert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectInsert`(
	OUT pProjectId INT ,
	IN pProjectTitle VARCHAR (255) CHARACTER SET UTF8 ,
	IN pGroupName VARCHAR (255) CHARACTER SET UTF8 ,
    IN pPplEstimated INT,
    IN pLocation VARCHAR (255) CHARACTER SET UTF8 ,
    IN pObjective TEXT CHARACTER SET UTF8 ,
    IN pMeans TEXT CHARACTER SET UTF8 ,
    IN pStartDate DATE ,
    IN pTimeFrameId INT,
    IN pLanguageId INT ,
    IN pCountryId INT ,
    IN pProjectStatusId INT,
    IN pHoursSpent INT ,
    IN pPplParticipated INT,
    IN pPplServed INT,
    IN pReport TEXT CHARACTER SET UTF8 ,
	IN pEndDate DATE ,
	IN pInsertedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	INSERT INTO rs_projects
	(
		ProjectTitle,
	    GroupName, 
        PplEstimated,
        Location,
        Objective,
        Means,
        StartDate,
        TimeFrameId,
        LanguageId,
        CountryId,
        ProjectStatusId,
        HoursSpent,
        PplParticipated,
        PplServed,
        Report,
	    EndDate,
	    InsertedBy, 
		InsertedOn
	)
	VALUES
	(
		pProjectTitle,
	    pGroupName,
        pPplEstimated,
        pLocation,
        pObjective,
        pMeans,
        pStartDate,
        pTimeFrameId,
        pLanguageId,
        pCountryId,
        pProjectStatusId,
        pHoursSpent,
        pPplParticipated,
        pPplServed,
        pReport,
	    pEndDate,
	    pInsertedBy, 
		NOW()
	);
	SELECT LAST_INSERT_ID() INTO pProjectId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectMemberDelete
--

DROP PROCEDURE IF EXISTS `ProjectMemberDelete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectMemberDelete`(
	IN pId INT
)
BEGIN
DELETE FROM `rs_projectmembers`
WHERE ProjectMemberId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectMemberInsert
--

DROP PROCEDURE IF EXISTS `ProjectMemberInsert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectMemberInsert`(
	OUT pProjectMemberId INT ,
	IN pProjectId INT ,
	IN pMemberId INT ,
	IN pPending TINYINT(1),
	IN pInsertedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	INSERT INTO rs_projectmembers
	(
		ProjectId,
        MemberId,
		Pending,
        InsertedBy,
        InsertedOn
	)
	VALUES
	(
		pProjectId,
        pMemberId,
		pPending,
		pInsertedBy,
		NOW()
	);
	SELECT LAST_INSERT_ID() INTO pProjectMemberId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectMemberSelectAll
--

DROP PROCEDURE IF EXISTS `ProjectMemberSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectMemberSelectAll`(
	
)
BEGIN
select * FROM `rs_projectmembers`;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectMemberUpdate
--

DROP PROCEDURE IF EXISTS `ProjectMemberUpdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectMemberUpdate`(
	In pProjectMemberId INT ,
	IN pProjectId INT ,
	IN pMemberId INT ,
	IN pPending TINYINT(1),
	IN pModifiedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	UPDATE rs_projectmembers
	SET 
		ProjectId = pProjectId,
        MemberId = pMemberId,
		Pending = pPending,
        ModifiedBy = pModifiedBy,
        ModifiedOn = NOW()
	WHERE ProjectMemberId = pProjectMemberId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectProjectTypeDelete
--

DROP PROCEDURE IF EXISTS `ProjectProjectTypeDelete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectProjectTypeDelete`(
	IN pId INT
)
BEGIN
DELETE FROM `rs_projectprojecttypes`
WHERE ProjectProjectTypeId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectProjectTypeInsert
--

DROP PROCEDURE IF EXISTS `ProjectProjectTypeInsert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectProjectTypeInsert`(
	OUT pProjectProjectTypeId INT ,
	IN pProjectId INT ,
	IN pProjectTypeId INT ,
	IN pInsertedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	INSERT INTO rs_projectprojecttypes
	(
		ProjectId,
        ProjectTypeId,
        InsertedBy,
        InsertedOn
	)
	VALUES
	(
		pProjectId,
        pProjectTypeId,
		pInsertedBy,
		NOW()
	);
	SELECT LAST_INSERT_ID() INTO pProjectProjectTypeId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectProjectTypesSelectByProjectId
--

DROP PROCEDURE IF EXISTS `ProjectProjectTypesSelectByProjectId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectProjectTypesSelectByProjectId`(
    IN pProjectId INT 
)
BEGIN
	select * from rs_projectprojecttypes where projectid = pProjectId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectProjectTypeUpdate
--

DROP PROCEDURE IF EXISTS `ProjectProjectTypeUpdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectProjectTypeUpdate`(
	In pProjectProjectTypeId INT ,
	IN pProjectId INT ,
	IN pProjectTypeId INT ,
	IN pModifiedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	UPDATE 	rs_projectprojecttypes
	SET 
		ProjectId = pProjectId,
        ProjectTypeId = pProjectTypeId,
		ModifiedBy = pModifiedBy,
        ModifiedOn = NOW()
	WHERE ProjectProjectTypeId = pProjectProjectTypeId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectSelectAll
--

DROP PROCEDURE IF EXISTS `ProjectSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectSelectAll`(
)
BEGIN
	SELECT * FROM rs_projects;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectSelectByCountryId
--

DROP PROCEDURE IF EXISTS `ProjectSelectByCountryId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectSelectByCountryId`(
	IN pCountryId INT 
)
BEGIN
	SELECT * FROM rs_projects WHERE CountryId = pCountryId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectSelectById
--

DROP PROCEDURE IF EXISTS `ProjectSelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectSelectById`(
	IN pProjectId INT 
)
BEGIN
	SELECT * FROM rs_projects WHERE ProjectId = pProjectId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectSelectByKeyWord
--

DROP PROCEDURE IF EXISTS `ProjectSelectByKeyWord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectSelectByKeyWord`(
	IN pKeyWord VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
  SELECT ProjectTitle,
	    GroupName, 
        PplEstimated,
        Location,
        Objective,
        Means,
        StartDate,
        TimeFrameId,
        LanguageId,
        CountryId,
        ProjectStatusId,
        HoursSpent,
        PplParticipated,
        PplServed,
        Report,
	    EndDate,
	    rs_projects.InsertedBy as InsertedBy, 
		rs_projects.InsertedOn as InsertedOn
        FROM rs_projects WHERE ProjectTitle like CONCAT('%', pKeyWord,'%');
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectSelectByLanguageId
--

DROP PROCEDURE IF EXISTS `ProjectSelectByLanguageId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectSelectByLanguageId`(
	IN pLanguageId INT 
)
BEGIN
	SELECT * FROM rs_projects WHERE LanguageId = pLanguageId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectStatusSelectAll
--

DROP PROCEDURE IF EXISTS `ProjectStatusSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectStatusSelectAll`()
BEGIN
	SELECT * FROM rs_projectstatuses  order by ProjectStatusId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectStatusSelectById
--

DROP PROCEDURE IF EXISTS `ProjectStatusSelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectStatusSelectById`(
	IN pId INT
)
BEGIN
	SELECT * FROM rs_projectstatuses WHERE ProjectStatusId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectTargetGroupDelete
--

DROP PROCEDURE IF EXISTS `ProjectTargetGroupDelete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectTargetGroupDelete`(
	IN pId INT
)
BEGIN
DELETE FROM `rs_projecttargetgroups`
WHERE ProjectTargetGroupId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectTargetGroupInsert
--

DROP PROCEDURE IF EXISTS `ProjectTargetGroupInsert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectTargetGroupInsert`(
	OUT pProjectTargetGroupId INT ,
	IN pProjectId INT ,
	IN pTargetGroupId INT ,
	IN pInsertedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	INSERT INTO rs_projecttargetgroups
	(
		ProjectId,
        TargetGroupId,
        InsertedBy,
        InsertedOn
	)
	VALUES
	(
		pProjectId,
        pTargetGroupId,
		pInsertedBy,
		NOW()
	);
	SELECT LAST_INSERT_ID() INTO pProjectTargetGroupId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectTargetGroupsSelectByProjectId
--

DROP PROCEDURE IF EXISTS `ProjectTargetGroupsSelectByProjectId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectTargetGroupsSelectByProjectId`(
    IN pProjectId INT 
)
BEGIN
	select * from rs_projecttargetgroups where projectid = pProjectId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectTargetGroupUpdate
--

DROP PROCEDURE IF EXISTS `ProjectTargetGroupUpdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectTargetGroupUpdate`(
	In pProjectTargetGroupId INT ,
	IN pProjectId INT ,
	IN pTargetGroupId INT ,
	IN pModifiedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	UPDATE 	rs_projecttargetgroups
	SET 
		ProjectId = pProjectId,
        TargetGroupId = pTargetGroupId,
		ModifiedBy = pModifiedBy,
        ModifiedOn = NOW()
	WHERE ProjectTargetGroupId = pProjectTargetGroupId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectTypeDelete
--

DROP PROCEDURE IF EXISTS `ProjectTypeDelete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectTypeDelete`(
	IN pProjectTypeId INT
)
BEGIN
DELETE FROM rs_projecttypes
WHERE ProjectTypeId = pProjectTypeId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectTypeInsert
--

DROP PROCEDURE IF EXISTS `ProjectTypeInsert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectTypeInsert`(
	OUT pProjectTypeId INT ,
	IN pProjectType VARCHAR (255) CHARACTER SET UTF8,
    IN pProjectTypeInfo VARCHAR (255) CHARACTER SET UTF8
)
BEGIN
	INSERT INTO rs_projecttypes
	(
		ProjectType, ProjectTypeInfo
	)
	VALUES
	(
		pProjectType, pProjectTypeInfo
	);
	SELECT LAST_INSERT_ID() INTO pProjectTypeId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectTypeSelectAll
--

DROP PROCEDURE IF EXISTS `ProjectTypeSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectTypeSelectAll`(
)
BEGIN
	SELECT * FROM rs_projecttypes
;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectTypeSelectById
--

DROP PROCEDURE IF EXISTS `ProjectTypeSelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectTypeSelectById`(
	IN pProjectTypeId INT 
)
BEGIN
	SELECT * FROM rs_projecttypes WHERE ProjectTypeId = pProjectTypeId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectTypeUpdate
--

DROP PROCEDURE IF EXISTS `ProjectTypeUpdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectTypeUpdate`(
	IN pProjectTypeId INT ,
	IN pProjectType VARCHAR (255) CHARACTER SET UTF8,
    IN pProjectTypeInfo VARCHAR (255) CHARACTER SET UTF8  
)
BEGIN
UPDATE rs_projecttypes
SET
	ProjectType = pProjectType,
    ProjectTypeInfo = pProjectTypeInfo
WHERE ProjectTypeId = pProjectTypeId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for ProjectUpdate
--

DROP PROCEDURE IF EXISTS `ProjectUpdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `ProjectUpdate`(
	IN pProjectId INT ,
	IN pProjectTitle VARCHAR (255) CHARACTER SET UTF8 ,
	IN pGroupName VARCHAR (255) CHARACTER SET UTF8 ,
    IN pPplEstimated INT,
    IN pLocation VARCHAR (255) CHARACTER SET UTF8 ,
    IN pObjective TEXT CHARACTER SET UTF8 ,
    IN pMeans TEXT CHARACTER SET UTF8 ,
    IN pStartDate DATE ,
    IN pTimeFrameId INT,
    IN pLanguageId INT ,
    IN pCountryId INT ,
    IN pProjectStatusId INT,
    IN pHoursSpent INT ,
    IN pPplParticipated INT,
    IN pPplServed INT,
    IN pReport TEXT CHARACTER SET UTF8 ,
	IN pEndDate DATE ,
	IN pModifiedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
UPDATE `rs_projects`
SET
	ProjectTitle = pProjectTitle,
	GroupName = pGroupName, 
    PplEstimated = pPplEstimated,
    Location = pLocation,
    Objective = pObjective,
    Means = pMeans,
    StartDate = pStartDate,
    TimeFrameId = pTimeFrameId,
    LanguageId = pLanguageId,
    CountryId = pCountryId,
    ProjectStatusId = pProjectStatusId,
    HoursSpent = pHoursSpent,
    PplParticipated = pPplParticipated,
    PplServed = pPplServed,
    Report = pReport,
	EndDate = pEndDate,
	ModifiedBy = pModifiedBy, 
	ModifiedOn = NOW()
WHERE ProjectId = pProjectId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for RoleSelectAll
--

DROP PROCEDURE IF EXISTS `RoleSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `RoleSelectAll`()
BEGIN
	SELECT * FROM rs_roles;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for RoleSelectById
--

DROP PROCEDURE IF EXISTS `RoleSelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `RoleSelectById`(
	IN pId INT
)
BEGIN
	SELECT * FROM rs_roles WHERE RoleId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for SelectProjectsByMemberId
--

DROP PROCEDURE IF EXISTS `SelectProjectsByMemberId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `SelectProjectsByMemberId`(
	IN pMemberId INT 
)
BEGIN
	SELECT * FROM rs_projects, rs_projectmembers WHERE rs_projects.ProjectId = rs_projectmembers.ProjectId and projectmemberid = pMemberId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for SelectProjectsByProjectTypeId
--

DROP PROCEDURE IF EXISTS `SelectProjectsByProjectTypeId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `SelectProjectsByProjectTypeId`(
	IN pProjectTypeId INT 
)
BEGIN
	SELECT * FROM rs_projects, rs_projectprojecttypes WHERE rs_projects.ProjectId = rs_projectprojecttypes.ProjectId and projecttypeid = pProjectTypeId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for SelectTargetGroupsByProjectId
--

DROP PROCEDURE IF EXISTS `SelectTargetGroupsByProjectId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `SelectTargetGroupsByProjectId`(
    IN pProjectId INT 
)
BEGIN
	select rs_targetgroups.TargetGroup as TargetGroup from
    rs_projecttargetgroups, rs_targetgroups
    where rs_targetgroups.targetgroupid = rs_projecttargetgroups.targetgroupid and rs_projecttargetgroups.projectid = pProjectId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for StuffDelete
--

DROP PROCEDURE IF EXISTS `StuffDelete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `StuffDelete`(
	IN pId INT
)
BEGIN
DELETE FROM rs_stuffs
WHERE StuffId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for StuffInsert
--

DROP PROCEDURE IF EXISTS `StuffInsert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `StuffInsert`(
	OUT pStuffId INT ,
	IN pStuffTitle VARCHAR (255) CHARACTER SET UTF8 ,
	IN pProjectId INT ,
    IN pMemberId INT,
    IN pStuffTypeId INT,
	IN pInsertedBy VARCHAR (255) CHARACTER SET UTF8 
)
BEGIN
	INSERT INTO rs_stuffs
	(
		StuffTitle,
		ProjectId,
        MemberId,
        StuffTypeId,
		InsertedBy,
		InsertedOn
	)
	VALUES
	(
		pStuffTitle,
		pProjectId,
        pMemberId,
        pStuffTypeId,
		pInsertedBy,
		NOW()
	);
	SELECT LAST_INSERT_ID() INTO pStuffId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for StuffSelectAll
--

DROP PROCEDURE IF EXISTS `StuffSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `StuffSelectAll`(
)
BEGIN
	SELECT * FROM rs_stuffs
;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for StuffSelectById
--

DROP PROCEDURE IF EXISTS `StuffSelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `StuffSelectById`(
	IN pStuffId INT 
)
BEGIN
	SELECT * FROM rs_stuffs WHERE StuffId = pStuffId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for StuffSelectByMemberId
--

DROP PROCEDURE IF EXISTS `StuffSelectByMemberId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `StuffSelectByMemberId`(
	IN pMemberId INT 
)
BEGIN
	SELECT * FROM rs_stuffs WHERE MemberId = pMemberId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for StuffSelectByProjectId
--

DROP PROCEDURE IF EXISTS `StuffSelectByProjectId`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `StuffSelectByProjectId`(
	IN pProjectId INT 
)
BEGIN
	SELECT * FROM rs_stuffs WHERE ProjectId = pProjectId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for StuffTypesSelectAll
--

DROP PROCEDURE IF EXISTS `StuffTypesSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `StuffTypesSelectAll`()
BEGIN
	SELECT * FROM rs_stufftypes;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for StuffUpdate
--

DROP PROCEDURE IF EXISTS `StuffUpdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `StuffUpdate`(
	IN pStuffId INT ,
	IN pStuffTitle VARCHAR (255) CHARACTER SET UTF8 ,
	IN pProjectId INT ,
    IN pMemberId INT ,
    IN pStuffTypeId INT ,
	IN pModifiedBy VARCHAR (256) CHARACTER SET UTF8 
)
BEGIN
UPDATE rs_stuffs
SET
	StuffTitle = pStuffTitle,
	ProjectId = pProjectId,
    MemberId = pMemberId,
    StuffTypeId = pStuffTypeId,
	ModifiedBy = pModifiedBy,
	ModifiedOn = NOW()
WHERE StuffId = pStuffId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for TargetGroupSelectAll
--

DROP PROCEDURE IF EXISTS `TargetGroupSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `TargetGroupSelectAll`()
BEGIN
	SELECT * FROM rs_targetgroups;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for TargetGroupSelectById
--

DROP PROCEDURE IF EXISTS `TargetGroupSelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `TargetGroupSelectById`(
	IN pId INT
)
BEGIN
	SELECT * FROM rs_targetgroups
	WHERE TargetGroupId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for TimeFrameSelectAll
--

DROP PROCEDURE IF EXISTS `TimeFrameSelectAll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `TimeFrameSelectAll`()
BEGIN
	SELECT * FROM rs_timeframes;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Procedure structure for TimeFrameSelectById
--

DROP PROCEDURE IF EXISTS `TimeFrameSelectById`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE DEFINER=`rootsandvt4`@`%` PROCEDURE `TimeFrameSelectById`(
	IN pId INT
)
BEGIN
	SELECT * FROM rs_timeframes WHERE TimeFrameId = pId;
END;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Backup completed on 2017-06-01 11:21:39
